# 🔱 MxAgent — ZeroClaw × Byzantine Multi-Agent System

**The unbreakable agent.** Combines ZeroClaw's rich memory/identity system with Byzantine Fault-Tolerant multi-agent consensus for every tool-calling decision.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│  TIER 1: ZeroClaw Shell                                             │
│  Channels (CLI/Telegram) → Gateway (session lanes) → CoreEngine    │
│  Memory: SOUL.md | Facts | Summary | RAG | Daily Log | Self-Review │
│  Heartbeat: Proactive cron tasks | Hook bus                         │
└────────────────────────────┬────────────────────────────────────────┘
                             │  tool_call proposed by main LLM
                             ▼
              _requires_consensus(tool_name)?
              │                           │
         FAST PATH                   SAFE PATH
    (read/calculate/search)    (write/execute/command)
         direct exec              ▼
                        ┌─────────────────────────────────┐
                        │  TIER 2: Byzantine Engine        │
                        │  ┌───────┐ ┌───────┐ ┌───────┐ │
                        │  │Alpha  │ │Beta   │ │Gamma  │ │
                        │  │phi3   │ │gemma2 │ │qwen   │ │
                        │  └──┬────┘ └───┬───┘ └──┬────┘ │
                        │     └──────────┼─────────┘      │
                        │          Parallel Vote           │
                        │         (with ZeroClaw           │
                        │          memory context)         │
                        │               │                  │
                        │     Consensus Router             │
                        │   ↙     ↓        ↘              │
                        │ Execute Arbitrate Escalate       │
                        │    │      ↕ loop     │           │
                        │ HITL Gate          Report        │
                        └──────┬──────────────────────────┘
                               │  approved action
                               ▼
                     TIER 3: Hardened ToolExecutor
                     (AST sandbox | extension allowlist
                      | workspace boundary | calculate)
```

---

## Key Safety Properties

| Property | Implementation |
|---|---|
| **Byzantine fault tolerance** | 3 agents vote in parallel; 1 faulty agent cannot affect outcome |
| **Confidence-weighted consensus** | Sum of confidence ≥ 120 required (≈ 2 confident agents) |
| **Safety validator** | Agent-γ (Gamma) dedicated to blocking dangerous requests |
| **Circuit breaker** | Faulty agents auto-bypassed after 3 consecutive failures |
| **Human-in-the-loop** | Every execution pauses for human approval |
| **AST sandbox** | Python code analyzed before subprocess execution |
| **Input sanitization** | Prompt injection patterns detected and blocked |
| **Context-aware voting** | All 3 voters see ZeroClaw memory (SOUL + facts + summary) |
| **Loop-back re-voting** | Arbitration can trigger a fresh vote round (max 3) |
| **Escalation reports** | JSON reports written to workspace on failure |

---

## HITL Commands

During a conversation, use these commands to manage pending approvals:

```
/pending <thread_id>         — View pending action and all votes
/approve <thread_id>         — Approve and execute the action
/reject  <thread_id> <reason>— Reject with explanation
```

Thread IDs are in format `channel:user_id` (e.g. `cli:cli` for the CLI).

---

## Setup

### Quick Start (Windows)
```bat
setup.bat
```

### Manual
```bash
# 1. Install Python dependencies
pip install -r requirements.txt

# 2. Install Ollama voting models
ollama pull phi3:mini
ollama pull gemma2:2b
ollama pull qwen2.5:1.5b

# 3. Configure API keys
cp .env.example .env
# Edit .env: add GEMINI_API_KEY=...

# 4. Health check
python main.py doctor

# 5. Run
python main.py
```

---

## Configuration

Key config.toml sections:

```toml
[agent.byzantine]
enabled = true                # Toggle Byzantine consensus
hitl_enabled = true           # Human approval before execution

fast_path_tools = [           # These skip voting (low-risk)
  "read_file", "list_files",
  "calculate", "web_search"
]

require_consensus_for = [     # These require 3-agent vote
  "run_python", "write_file",
  "patch_file", "run_command", "spawn_agent"
]

[agent.byzantine.circuit_breaker]
failure_threshold = 3         # Open circuit after N failures
recovery_timeout  = 60        # Seconds before HALF_OPEN test
```

---

## File Structure

```
MxAgent/
├── main.py                          ← Entry point (interactive + doctor + --task)
├── config.toml                      ← Full configuration
├── requirements.txt
├── setup.bat                        ← Windows one-shot setup
├── .env.example
│
├── agent/
│   ├── engine.py                    ← CoreEngine with dual-path routing
│   ├── gateway.py                   ← Session lanes + HITL command handling
│   ├── security.py                  ← InputSanitizer, SecurityViolation
│   ├── hooks.py                     ← Event bus (before/after tool, agent_end)
│   ├── heartbeat.py                 ← Proactive cron scheduler
│   │
│   ├── byzantine/                   ← Byzantine consensus engine
│   │   ├── state.py                 ← TypedDict ByzantineState, Vote, reducers
│   │   ├── circuit_breaker.py       ← CLOSED/OPEN/HALF_OPEN circuit breaker
│   │   ├── agents.py                ← Alpha/Beta/Gamma nodes, JSON repair
│   │   ├── consensus.py             ← voting_node, consensus_router (READ-ONLY),
│   │   │                               select_winner_node, arbitration_node,
│   │   │                               arbitration_router (with loop-back)
│   │   ├── execution.py             ← ToolRegistry + AST sandbox (Kimi's)
│   │   ├── graph.py                 ← LangGraph assembly, AsyncSqliteSaver,
│   │   │                               HITL interrupt_before=["execution"]
│   │   ├── engine.py                ← ByzantineDecisionEngine wrapper
│   │   └── logging_config.py        ← Structured logging (structlog)
│   │
│   ├── tools/
│   │   ├── executor.py              ← Hardened ToolExecutor (AST sandbox)
│   │   └── web_search.py            ← Tavily/Serper web search
│   │
│   ├── memory/
│   │   ├── manager.py               ← 4-layer memory (facts/summary/raw/audit)
│   │   ├── vector_store.py          ← RAG with sqlite-vec embeddings
│   │   └── workspace.py             ← SOUL.md, MEMORY.md, daily log
│   │
│   ├── llm/
│   │   ├── router.py                ← Primary/fallback LLM chain + compaction
│   │   ├── gemini.py                ← Gemini provider
│   │   ├── ollama.py                ← Ollama provider
│   │   ├── openai.py                ← OpenAI provider
│   │   ├── cerebras.py              ← Cerebras provider
│   │   └── dummy.py                 ← Test/fallback provider
│   │
│   ├── channels/
│   │   ├── cli.py                   ← Interactive CLI
│   │   └── telegram.py              ← Telegram bot
│   │
│   ├── subagents/
│   │   └── orchestrator.py          ← spawn_agent tool (research/code/analysis)
│   │
│   ├── workflow/                    ← LangGraph-style workflow nodes
│   └── tracing/                     ← Execution tracing
│
├── workspace/
│   ├── SOUL.md                      ← Agent identity (self-modifiable)
│   ├── MEMORY.md                    ← Curated long-term learnings
│   └── cron/
│       └── daily.py                 ← Daily summary script
│
└── logs/
    └── agent.log
```

---

## What Was Fixed vs Source Implementations

### Kimi Byzantine (3 bugs fixed)
- `asyncio.run()` inside event loop in JSON repair layer → replaced with `await repair_json_async()`
- Hardcoded workspace path → configurable via `BYZANTINE_WORKSPACE` env var
- Flat-directory logging imports → standard `logging.getLogger()`

### BAgent ZeroClaw Byzantine layer (5 fatal bugs fixed)
- `state["winning_action"] = vote` inside router → SILENTLY DISCARDED by LangGraph → moved to `select_winner_node`
- `state["reflection_count"] += 1` inside node → direct mutation → fixed to `return {"reflection_count": state["reflection_count"] + 1}`
- `SqliteSaver` (synchronous, blocks event loop) → `AsyncSqliteSaver`
- No loop-back edge `arbitration → voting` → added `"re_vote": "voting"` in conditional edges
- No `interrupt_before` HITL → added `interrupt_before=["execution"]`

---

## License

MIT
