"""
LangSmith-style Tracing System for ZeroClaw Agent.

Provides:
- Trace logging for all operations
- Decision tracking
- Performance metrics
- Debug visualization
"""

from agent.tracing.trace import Tracer, Trace, TraceSpan, get_tracer, init_tracer

__all__ = [
    "Tracer",
    "Trace",
    "TraceSpan",
    "get_tracer",
    "init_tracer",
]
