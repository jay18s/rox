"""
LangSmith-style Tracing System for ZeroClaw Agent.

Provides:
- Trace logging for all operations
- Decision tracking
- Performance metrics
- Debug visualization
"""

from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Optional
from contextlib import contextmanager
import uuid

logger = logging.getLogger(__name__)


@dataclass
class TraceSpan:
    """A single span in a trace."""
    span_id: str
    name: str
    start_time: str
    end_time: str | None = None
    duration_ms: float | None = None
    status: str = "running"
    inputs: dict[str, Any] = field(default_factory=dict)
    outputs: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    parent_id: str | None = None
    children: list["TraceSpan"] = field(default_factory=list)
    
    def to_dict(self) -> dict[str, Any]:
        return {
            "span_id": self.span_id,
            "name": self.name,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_ms": self.duration_ms,
            "status": self.status,
            "inputs": self.inputs,
            "outputs": self.outputs,
            "metadata": self.metadata,
            "parent_id": self.parent_id,
        }


@dataclass
class Trace:
    """A complete trace for a request."""
    trace_id: str
    name: str
    user_id: str
    channel: str
    start_time: str
    end_time: str | None = None
    duration_ms: float | None = None
    status: str = "running"
    root_span: TraceSpan | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        return {
            "trace_id": self.trace_id,
            "name": self.name,
            "user_id": self.user_id,
            "channel": self.channel,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_ms": self.duration_ms,
            "status": self.status,
            "metadata": self.metadata,
        }


class Tracer:
    """
    LangSmith-style tracer for debugging and monitoring.
    
    Features:
    - Hierarchical span tracking
    - SQLite persistence
    - Performance metrics
    - Decision logging
    """
    
    def __init__(self, db_path: str = "traces.db"):
        self.db_path = Path(db_path)
        self._current_trace: Trace | None = None
        self._span_stack: list[TraceSpan] = []
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()
    
    def setup(self) -> None:
        """Initialize the tracer database."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS traces (
                trace_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                user_id TEXT NOT NULL,
                channel TEXT NOT NULL,
                start_time TEXT NOT NULL,
                end_time TEXT,
                duration_ms REAL,
                status TEXT DEFAULT 'running',
                metadata TEXT
            );
            
            CREATE TABLE IF NOT EXISTS spans (
                span_id TEXT PRIMARY KEY,
                trace_id TEXT NOT NULL,
                parent_id TEXT,
                name TEXT NOT NULL,
                start_time TEXT NOT NULL,
                end_time TEXT,
                duration_ms REAL,
                status TEXT DEFAULT 'running',
                inputs TEXT,
                outputs TEXT,
                metadata TEXT,
                FOREIGN KEY (trace_id) REFERENCES traces(trace_id)
            );
            
            CREATE TABLE IF NOT EXISTS decisions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trace_id TEXT NOT NULL,
                decision_point TEXT NOT NULL,
                outcome TEXT NOT NULL,
                reason TEXT,
                timestamp TEXT NOT NULL,
                FOREIGN KEY (trace_id) REFERENCES traces(trace_id)
            );
            
            CREATE INDEX IF NOT EXISTS idx_traces_user ON traces(user_id);
            CREATE INDEX IF NOT EXISTS idx_spans_trace ON spans(trace_id);
            CREATE INDEX IF NOT EXISTS idx_decisions_trace ON decisions(trace_id);
        """)
        self._conn.commit()
        logger.info("[TRACER] Database initialized at %s", self.db_path)
    
    def close(self) -> None:
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None
    
    @contextmanager
    def trace(self, name: str, user_id: str, channel: str, **metadata):
        """Context manager for tracing a request."""
        trace_id = str(uuid.uuid4())[:8]
        start_time = datetime.now()
        
        self._current_trace = Trace(
            trace_id=trace_id,
            name=name,
            user_id=user_id,
            channel=channel,
            start_time=start_time.isoformat(),
            metadata=metadata,
        )
        
        # Insert trace record
        if self._conn:
            self._conn.execute(
                "INSERT INTO traces (trace_id, name, user_id, channel, start_time, metadata) VALUES (?, ?, ?, ?, ?, ?)",
                (trace_id, name, user_id, channel, start_time.isoformat(), json.dumps(metadata))
            )
            self._conn.commit()
        
        logger.info("[TRACER] Started trace %s: %s (user: %s)", trace_id, name, user_id)
        
        try:
            yield self._current_trace
        finally:
            # Finalize trace
            end_time = datetime.now()
            duration_ms = (end_time - start_time).total_seconds() * 1000
            
            self._current_trace.end_time = end_time.isoformat()
            self._current_trace.duration_ms = duration_ms
            self._current_trace.status = "completed"
            
            if self._conn:
                self._conn.execute(
                    "UPDATE traces SET end_time=?, duration_ms=?, status=? WHERE trace_id=?",
                    (end_time.isoformat(), duration_ms, "completed", trace_id)
                )
                self._conn.commit()
            
            logger.info("[TRACER] Completed trace %s (%.1fms)", trace_id, duration_ms)
            self._current_trace = None
    
    @contextmanager
    def span(self, name: str, inputs: dict[str, Any] | None = None, **metadata):
        """Context manager for tracing a span."""
        span_id = str(uuid.uuid4())[:8]
        start_time = datetime.now()
        parent_id = self._span_stack[-1].span_id if self._span_stack else None
        
        span = TraceSpan(
            span_id=span_id,
            name=name,
            start_time=start_time.isoformat(),
            inputs=inputs or {},
            metadata=metadata,
            parent_id=parent_id,
        )
        
        self._span_stack.append(span)
        
        # Insert span record
        if self._conn and self._current_trace:
            self._conn.execute(
                "INSERT INTO spans (span_id, trace_id, parent_id, name, start_time, inputs, metadata) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (span_id, self._current_trace.trace_id, parent_id, name, start_time.isoformat(), json.dumps(inputs or {}), json.dumps(metadata))
            )
            self._conn.commit()
        
        logger.debug("[TRACER] Started span %s: %s", span_id, name)
        
        try:
            yield span
        finally:
            # Finalize span
            end_time = datetime.now()
            duration_ms = (end_time - start_time).total_seconds() * 1000
            
            span.end_time = end_time.isoformat()
            span.duration_ms = duration_ms
            span.status = "completed"
            
            self._span_stack.pop()
            
            if self._conn and self._current_trace:
                self._conn.execute(
                    "UPDATE spans SET end_time=?, duration_ms=?, status=? WHERE span_id=?",
                    (end_time.isoformat(), duration_ms, "completed", span_id)
                )
                self._conn.commit()
            
            logger.debug("[TRACER] Completed span %s (%.1fms)", span_id, duration_ms)
    
    def log_decision(self, decision_point: str, outcome: str, reason: str = "") -> None:
        """Log a decision point."""
        if not self._current_trace or not self._conn:
            return
        
        self._conn.execute(
            "INSERT INTO decisions (trace_id, decision_point, outcome, reason, timestamp) VALUES (?, ?, ?, ?, ?)",
            (self._current_trace.trace_id, decision_point, outcome, reason, datetime.now().isoformat())
        )
        self._conn.commit()
        
        logger.debug("[TRACER] Decision: %s → %s (%s)", decision_point, outcome, reason)
    
    def log_invocation(self, invocation_type: str, name: str, inputs: dict[str, Any], outputs: dict[str, Any]) -> None:
        """Log a tool/LLM invocation."""
        with self.span(f"{invocation_type}:{name}", inputs=inputs) as span:
            span.outputs = outputs
    
    async def trace_node_start(self, node_name: str, state: Any) -> None:
        """Called when a node starts execution."""
        if not self._current_trace:
            return
        
        self.log_decision(
            decision_point="node_start",
            outcome=node_name,
            reason=f"State: {len(state.visited_nodes)} nodes visited"
        )
    
    async def trace_node_end(self, node_name: str, result: Any, state: Any) -> None:
        """Called when a node finishes execution."""
        if not self._current_trace:
            return
        
        self.log_decision(
            decision_point="node_end",
            outcome=node_name,
            reason=f"Status: {result.status.value}"
        )
    
    def get_trace(self, trace_id: str) -> dict[str, Any] | None:
        """Get a trace by ID."""
        if not self._conn:
            return None
        
        row = self._conn.execute(
            "SELECT * FROM traces WHERE trace_id = ?",
            (trace_id,)
        ).fetchone()
        
        if not row:
            return None
        
        trace = dict(row)
        trace["metadata"] = json.loads(trace["metadata"] or "{}")
        
        # Get spans
        spans = self._conn.execute(
            "SELECT * FROM spans WHERE trace_id = ? ORDER BY start_time",
            (trace_id,)
        ).fetchall()
        
        trace["spans"] = [dict(s) for s in spans]
        for span in trace["spans"]:
            span["inputs"] = json.loads(span["inputs"] or "{}")
            span["outputs"] = json.loads(span["outputs"] or "{}")
            span["metadata"] = json.loads(span["metadata"] or "{}")
        
        # Get decisions
        decisions = self._conn.execute(
            "SELECT * FROM decisions WHERE trace_id = ? ORDER BY timestamp",
            (trace_id,)
        ).fetchall()
        
        trace["decisions"] = [dict(d) for d in decisions]
        
        return trace
    
    def get_user_traces(self, user_id: str, limit: int = 20) -> list[dict[str, Any]]:
        """Get recent traces for a user."""
        if not self._conn:
            return []
        
        rows = self._conn.execute(
            "SELECT * FROM traces WHERE user_id = ? ORDER BY start_time DESC LIMIT ?",
            (user_id, limit)
        ).fetchall()
        
        return [dict(r) for r in rows]
    
    def get_recent_traces(self, limit: int = 50) -> list[dict[str, Any]]:
        """Get recent traces."""
        if not self._conn:
            return []
        
        rows = self._conn.execute(
            "SELECT * FROM traces ORDER BY start_time DESC LIMIT ?",
            (limit,)
        ).fetchall()
        
        return [dict(r) for r in rows]
    
    def get_stats(self) -> dict[str, Any]:
        """Get tracer statistics."""
        if not self._conn:
            return {}
        
        total_traces = self._conn.execute("SELECT COUNT(*) FROM traces").fetchone()[0]
        total_spans = self._conn.execute("SELECT COUNT(*) FROM spans").fetchone()[0]
        total_decisions = self._conn.execute("SELECT COUNT(*) FROM decisions").fetchone()[0]
        
        avg_duration = self._conn.execute(
            "SELECT AVG(duration_ms) FROM traces WHERE duration_ms IS NOT NULL"
        ).fetchone()[0] or 0
        
        return {
            "total_traces": total_traces,
            "total_spans": total_spans,
            "total_decisions": total_decisions,
            "avg_duration_ms": round(avg_duration, 2),
        }
    
    def export_trace(self, trace_id: str) -> str:
        """Export a trace as JSON string."""
        trace = self.get_trace(trace_id)
        if trace:
            return json.dumps(trace, indent=2)
        return "{}"


# Global tracer instance
_global_tracer: Tracer | None = None


def get_tracer() -> Tracer:
    """Get the global tracer instance."""
    global _global_tracer
    if _global_tracer is None:
        _global_tracer = Tracer()
        _global_tracer.setup()
    return _global_tracer


def init_tracer(db_path: str = "traces.db") -> Tracer:
    """Initialize the global tracer."""
    global _global_tracer
    _global_tracer = Tracer(db_path)
    _global_tracer.setup()
    return _global_tracer
