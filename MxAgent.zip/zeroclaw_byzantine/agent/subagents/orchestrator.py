"""
Sub-agent Orchestrator — spawn specialized agents for complex tasks.

Enables the main agent to delegate work to specialized sub-agents:
  - Research agent: web search and information gathering
  - Code agent: code generation and debugging
  - Analysis agent: data analysis and reasoning

Each sub-agent runs in its own context with isolated memory,
then returns results to the main agent.

Usage via tool call:
  {"tool": "spawn_agent", "args": {"type": "research", "task": "Find info about X"}}

Config (config.toml):
  [agent.subagents]
  enabled = true
  max_concurrent = 3
  timeout_seconds = 120
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class AgentType(Enum):
    """Available sub-agent types."""
    RESEARCH = "research"      # Web search, information gathering
    CODE = "code"              # Code generation, debugging
    ANALYSIS = "analysis"      # Data analysis, reasoning
    GENERAL = "general"        # General-purpose


@dataclass
class SubAgentResult:
    """Result from a sub-agent execution."""
    agent_id: str
    agent_type: str
    task: str
    result: str
    success: bool
    duration_seconds: float
    tools_used: list[str] = field(default_factory=list)
    error: str | None = None


# ── Agent type prompts ─────────────────────────────────────────────────────────

_AGENT_PROMPTS = {
    AgentType.RESEARCH: """\
You are a research specialist agent. Your job is to gather information.

Guidelines:
- Use web_search extensively to find current information
- Cross-reference multiple sources when possible
- Cite your sources in the response
- Focus on accuracy over speed
- If you can't find something, say so clearly
""",

    AgentType.CODE: """\
You are a code specialist agent. Your job is to write, debug, and explain code.

Guidelines:
- Write clean, well-documented code
- Test your code when possible using run_python
- Handle edge cases and errors gracefully
- Explain your approach before writing code
- Use best practices for the language/framework
""",

    AgentType.ANALYSIS: """\
You are an analysis specialist agent. Your job is to analyze data and reason through problems.

Guidelines:
- Break down complex problems into steps
- Use run_python for calculations and data analysis
- Show your work and reasoning
- Consider multiple perspectives
- Provide actionable insights
""",

    AgentType.GENERAL: """\
You are a general-purpose agent ready to help with any task.
Complete the assigned task efficiently and report back with clear results.
""",
}


class SubAgentOrchestrator:
    """
    Manages spawning and coordination of sub-agents.
    """
    
    def __init__(self, config: dict[str, Any]):
        subagent_cfg = config.get("agent", {}).get("subagents", {})
        self.enabled = subagent_cfg.get("enabled", True)
        self.max_concurrent = subagent_cfg.get("max_concurrent", 3)
        self.timeout = subagent_cfg.get("timeout_seconds", 120)
        
        self._active_agents: dict[str, asyncio.Task] = {}
        self._results: dict[str, SubAgentResult] = {}
        self._semaphore = asyncio.Semaphore(self.max_concurrent)
        
        logger.info(
            "Sub-agent orchestrator: enabled=%s, max_concurrent=%d, timeout=%ds",
            self.enabled, self.max_concurrent, self.timeout
        )
    
    def get_spawn_tool_description(self) -> str:
        """Return the tool description for spawn_agent."""
        if not self.enabled:
            return ""
        
        return """
### spawn_agent
Spawn a specialized sub-agent to handle a specific task.
{"tool": "spawn_agent", "args": {"type": "research|code|analysis|general", "task": "description of task", "context": "optional background info"}}

Use this for:
- Complex research requiring multiple web searches
- Code generation/debugging tasks
- Data analysis tasks
- Any task that benefits from focused attention

The sub-agent will work independently and return results.
"""
    
    async def spawn_agent(
        self,
        agent_type: str,
        task: str,
        context: str = "",
        engine: Any = None,
    ) -> SubAgentResult:
        """
        Spawn a sub-agent to handle a task.
        
        Args:
            agent_type: Type of agent (research, code, analysis, general)
            task: The task description
            context: Optional background context
            engine: The main CoreEngine instance to clone
        
        Returns:
            SubAgentResult with the outcome
        """
        if not self.enabled:
            return SubAgentResult(
                agent_id="disabled",
                agent_type=agent_type,
                task=task,
                result="Sub-agents are disabled in configuration",
                success=False,
                duration_seconds=0,
                error="Sub-agents disabled"
            )
        
        # Parse agent type
        try:
            at = AgentType(agent_type.lower())
        except ValueError:
            at = AgentType.GENERAL
        
        agent_id = f"{at.value}_{uuid.uuid4().hex[:8]}"
        start_time = datetime.now()
        
        async with self._semaphore:
            try:
                # Run the sub-agent task
                result = await asyncio.wait_for(
                    self._run_subagent(agent_id, at, task, context, engine),
                    timeout=self.timeout
                )
                
                duration = (datetime.now() - start_time).total_seconds()
                result.duration_seconds = duration
                return result
                
            except asyncio.TimeoutError:
                duration = (datetime.now() - start_time).total_seconds()
                return SubAgentResult(
                    agent_id=agent_id,
                    agent_type=at.value,
                    task=task,
                    result="",
                    success=False,
                    duration_seconds=duration,
                    error=f"Sub-agent timed out after {self.timeout}s"
                )
            except Exception as e:
                duration = (datetime.now() - start_time).total_seconds()
                logger.error("Sub-agent %s failed: %s", agent_id, e)
                return SubAgentResult(
                    agent_id=agent_id,
                    agent_type=at.value,
                    task=task,
                    result="",
                    success=False,
                    duration_seconds=duration,
                    error=str(e)
                )
    
    async def _run_subagent(
        self,
        agent_id: str,
        agent_type: AgentType,
        task: str,
        context: str,
        engine: Any,
    ) -> SubAgentResult:
        """Execute a sub-agent task using a cloned engine context."""
        
        if engine is None:
            return SubAgentResult(
                agent_id=agent_id,
                agent_type=agent_type.value,
                task=task,
                result="No engine provided for sub-agent execution",
                success=False,
                duration_seconds=0,
                error="Missing engine"
            )
        
        # Build the sub-agent's system prompt
        system_prompt = _AGENT_PROMPTS[agent_type]
        
        # Build the full prompt with context
        full_prompt = f"{system_prompt}\n\n"
        if context:
            full_prompt += f"## CONTEXT\n{context}\n\n"
        full_prompt += f"## TASK\n{task}\n\nComplete this task and report your findings."
        
        tools_used: list[str] = []
        
        try:
            # Use the main engine's LLM but with isolated context
            response = await engine.llm.generate(
                prompt=full_prompt,
                history=[],  # Fresh history for sub-agent
                tools_description=engine.tool_executor.get_tools_description(),
                system_message=f"You are a {agent_type.value} specialist agent. ID: {agent_id}",
            )
            
            result_text = response.content
            tools_used = ["llm"]  # Track that we used the LLM
            
            # If the sub-agent makes a tool call, execute it
            iteration = 0
            max_iterations = 5  # Sub-agents have limited iterations
            
            while response.has_tool_call() and iteration < max_iterations:
                tool_call = response.tool_call
                tool_name = tool_call.get("tool", "?")
                tools_used.append(tool_name)
                
                # Execute the tool
                tool_result = await engine.tool_executor.execute(tool_call)
                
                # Continue the sub-agent
                follow_up = f"[Tool: {tool_name}]\nResult: {tool_result}\n\nContinue with your task."
                response = await engine.llm.generate(
                    prompt=follow_up,
                    history=[],
                    tools_description=engine.tool_executor.get_tools_description(),
                    system_message=f"You are a {agent_type.value} specialist agent. ID: {agent_id}",
                )
                result_text = response.content
                iteration += 1
            
            return SubAgentResult(
                agent_id=agent_id,
                agent_type=agent_type.value,
                task=task,
                result=result_text,
                success=True,
                duration_seconds=0,  # Set by caller
                tools_used=tools_used,
            )
            
        except Exception as e:
            return SubAgentResult(
                agent_id=agent_id,
                agent_type=agent_type.value,
                task=task,
                result="",
                success=False,
                duration_seconds=0,
                error=str(e),
                tools_used=tools_used,
            )
    
    def format_result(self, result: SubAgentResult) -> str:
        """Format a sub-agent result for display."""
        status = "✅ Success" if result.success else f"❌ Failed: {result.error}"
        return f"""\
### Sub-Agent Report
- **ID**: {result.agent_id}
- **Type**: {result.agent_type}
- **Task**: {result.task[:100]}
- **Status**: {status}
- **Duration**: {result.duration_seconds:.1f}s
- **Tools Used**: {', '.join(result.tools_used) or 'none'}

#### Result
{result.result[:1000]}
"""


# ── Tool integration ──────────────────────────────────────────────────────────

async def handle_spawn_agent(
    args: dict[str, Any],
    orchestrator: SubAgentOrchestrator,
    engine: Any,
) -> str:
    """Handle spawn_agent tool call."""
    agent_type = args.get("type", "general")
    task = args.get("task", "")
    context = args.get("context", "")
    
    if not task:
        return "[Error] 'task' is required for spawn_agent"
    
    result = await orchestrator.spawn_agent(
        agent_type=agent_type,
        task=task,
        context=context,
        engine=engine,
    )
    
    return orchestrator.format_result(result)
