"""Sub-agents package for specialized task delegation."""

from .orchestrator import (
    AgentType,
    SubAgentOrchestrator,
    SubAgentResult,
    handle_spawn_agent,
)

__all__ = [
    "AgentType",
    "SubAgentOrchestrator", 
    "SubAgentResult",
    "handle_spawn_agent",
]
