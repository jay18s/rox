"""
ByzantineDecisionEngine — clean async interface for ZeroClaw's CoreEngine.

CoreEngine calls decide() when it needs multi-agent consensus on a tool call.
The result contains: approved, winning_action, execution_result, or escalation_reason.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional, Any

from agent.byzantine.graph import run_task, get_pending_action, resume_task
from agent.byzantine.circuit_breaker import get_circuit_breaker

logger = logging.getLogger(__name__)


@dataclass
class DecisionResult:
    """Result from ByzantineDecisionEngine.decide()."""
    approved: bool
    winning_action: Optional[dict] = None
    risk_level: str = "medium"
    consensus_round: int = 0
    votes_summary: list = field(default_factory=list)
    execution_result: Optional[str] = None
    escalation_reason: Optional[str] = None
    thread_id: str = ""
    requires_human: bool = False


class ByzantineDecisionEngine:
    """
    Wraps the LangGraph Byzantine graph.
    Provides a clean async interface for CoreEngine to call.

    Usage in CoreEngine:
        result = await self.byzantine.decide(
            proposed_action={"tool": "run_python", "args": {"code": "..."}},
            user_input=text,
            memory_context=memory_block,
            thread_id=f"{channel}:{user_id}",
        )
        if result.approved:
            # result.execution_result has the tool output
        else:
            # result.escalation_reason explains why it was blocked
    """

    def __init__(self, config: dict[str, Any] = None):
        self.config = config or {}
        self._checkpoint_db = self.config.get("byzantine_checkpoints_db", None)

    async def decide(
        self,
        proposed_action: dict,
        user_input: str,
        memory_context: str = "",
        thread_id: str = "default",
    ) -> DecisionResult:
        """
        Run Byzantine consensus on a proposed tool action.

        Args:
            proposed_action: {"tool": tool_name, "args": params_dict}
            user_input:      Original user message
            memory_context:  ZeroClaw SOUL + facts + summary (injected into voter prompts)
            thread_id:       Session ID for checkpointing and HITL resume

        Returns:
            DecisionResult
        """
        proposed_tool   = proposed_action.get("tool", "")
        proposed_params = proposed_action.get("args", {})

        logger.info(
            "ByzantineEngine.decide: tool=%s thread=%s",
            proposed_tool, thread_id,
        )

        result = await run_task(
            input_text      = user_input,
            thread_id       = thread_id,
            proposed_tool   = proposed_tool,
            proposed_params = proposed_params,
            memory_context  = memory_context,
        )

        status = result.get("status", "escalated")

        if status == "awaiting_human":
            return DecisionResult(
                approved        = False,
                winning_action  = result.get("winning_action"),
                risk_level      = self._max_risk(result.get("votes_summary", [])),
                consensus_round = result.get("consensus_rounds", 0),
                votes_summary   = result.get("votes_summary", []),
                execution_result= None,
                escalation_reason = "Awaiting human approval — call resume() to continue",
                thread_id       = thread_id,
                requires_human  = True,
            )

        if status == "complete":
            return DecisionResult(
                approved        = True,
                winning_action  = result.get("winning_action"),
                risk_level      = self._max_risk(result.get("votes_summary", [])),
                consensus_round = result.get("consensus_rounds", 0),
                votes_summary   = result.get("votes_summary", []),
                execution_result= result.get("result"),
                thread_id       = thread_id,
                requires_human  = False,
            )

        # escalated
        return DecisionResult(
            approved          = False,
            risk_level        = self._max_risk(result.get("votes_summary", [])),
            consensus_round   = result.get("consensus_rounds", 0),
            votes_summary     = result.get("votes_summary", []),
            execution_result  = None,
            escalation_reason = result.get("result", "Action blocked by Byzantine consensus"),
            thread_id         = thread_id,
            requires_human    = False,
        )

    async def get_pending(self, thread_id: str) -> dict:
        """Get pending action details for a paused thread."""
        return await get_pending_action(thread_id)

    async def resume(self, thread_id: str, approved: bool, note: str = "") -> DecisionResult:
        """Resume a paused graph after human decision."""
        result = await resume_task(thread_id, approved, note)
        status = result.get("status", "escalated")
        return DecisionResult(
            approved         = (status == "complete"),
            execution_result = result.get("result"),
            escalation_reason= result.get("result") if not approved else None,
            thread_id        = thread_id,
        )

    def circuit_health(self) -> dict:
        return get_circuit_breaker().get_health_report()

    @staticmethod
    def _max_risk(votes_summary: list) -> str:
        order = {"critical": 3, "high": 2, "medium": 1, "low": 0}
        max_r = "low"
        for v in votes_summary:
            r = v.get("risk", "low")
            if order.get(r, 0) > order.get(max_r, 0):
                max_r = r
        return max_r
