"""
Byzantine Fault-Tolerant Agent System - Tool Registry and Sandbox Execution

This module provides:
- ToolRegistry for registering and discovering tools
- Sandboxed execution for Python code with AST-based security
- Safe file operations with extension allowlisting
- Restricted mathematical expression evaluator
"""

import ast
import hashlib
import os
import re
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import logging
logger = logging.getLogger(__name__)

def log_security_violation(lgr, vtype, details, tid): lgr.critical("SECURITY_VIOLATION type=%s details=%s thread=%s", vtype, details, tid)
def log_execution_start(lgr, tool, params_hash, tid): lgr.info("EXECUTION_START tool=%s hash=%s thread=%s", tool, params_hash, tid)
def log_execution_end(lgr, rlen, dur, tid): lgr.info("EXECUTION_END result_len=%d duration_ms=%d thread=%s", rlen, dur, tid)



# Workspace directory for sandbox operations
WORKSPACE_DIR = Path(os.environ.get("BYZANTINE_WORKSPACE", str(Path(__file__).parent.parent.parent / "workspace")))
WORKSPACE_DIR.mkdir(exist_ok=True)

# Allowed file extensions for write operations
ALLOWED_EXTENSIONS = {'.txt', '.json', '.csv', '.md', '.log'}

# Maximum content size for file writes (100KB)
MAX_FILE_SIZE = 100 * 1024


class SecurityViolation(Exception):
    """Raised when sandbox security checks fail."""
    pass


def _hash_params(params: dict) -> str:
    """Create a hash of parameters for logging."""
    param_str = str(sorted(params.items()))
    return hashlib.sha256(param_str.encode()).hexdigest()[:16]


def sandbox_python(params: dict) -> str:
    """
    Execute Python code in a sandboxed subprocess with AST-based security analysis.
    
    Security measures:
    1. AST analysis to block dangerous imports and calls
    2. String-level checks for obfuscation attempts
    3. Subprocess isolation with empty environment
    4. Timeout enforcement
    5. Output limits
    """
    code = params.get("code", "")
    
    if not code.strip():
        return "ERROR: Empty code provided"
    
    # Layer 1: AST-based security analysis
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return f"SYNTAX_ERROR: {e}"
    
    # Walk AST and check for blocked nodes
    blocked_nodes = (
        ast.Import, ast.ImportFrom, ast.Call
    )
    
    blocked_calls = {
        "eval", "exec", "compile", "open", "input", "__import__",
        "exit", "quit", "breakpoint", "help"
    }
    
    for node in ast.walk(tree):
        # Block import statements
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            return "SECURITY_VIOLATION: Blocked AST node detected (Import/ImportFrom)"
        
        # Block dangerous function calls
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                if node.func.id in blocked_calls:
                    return f"SECURITY_VIOLATION: Blocked function call '{node.func.id}'"
            
            # Block attribute access to dangerous functions
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Attribute):
                    if node.func.attr in blocked_calls:
                        return f"SECURITY_VIOLATION: Blocked method call '{node.func.attr}'"
    
    # Layer 2: String-level checks for obfuscation
    forbidden_strings = [
        "base64", "codecs", "decode", "encode", "chr(", "ord(",
        "ctypes", "socket", "urllib", "requests", "pickle", "marshal",
        "subprocess", "os.system", "os.popen", "os.spawn", "os.fork",
        "sys.modules", "__builtins__", "__import__", "importlib",
        "getattr", "setattr", "delattr", "hasattr",
        "compile(", "exec(", "eval("
    ]
    
    code_lower = code.lower()
    for forbidden in forbidden_strings:
        if forbidden in code_lower:
            return f"SECURITY_VIOLATION: Forbidden pattern detected '{forbidden}'"
    
    # Layer 3: Execute in isolated subprocess
    temp_file = None
    try:
        # Create temp file in workspace
        temp_fd, temp_path = tempfile.mkstemp(
            suffix=".py",
            dir=WORKSPACE_DIR,
            prefix="sandbox_"
        )
        temp_file = temp_path
        
        # Write code to temp file
        with os.fdopen(temp_fd, 'w') as f:
            f.write(code)
        
        # Execute with subprocess using sys.executable for portability
        result = subprocess.run(
            [sys.executable, temp_file],
            capture_output=True,
            text=True,
            timeout=15,
            env={},  # Empty environment
            cwd=WORKSPACE_DIR,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0,
        )
        
        # Capture output (with limits)
        stdout = result.stdout[:2000] if result.stdout else ""
        stderr = result.stderr[:500] if result.stderr else ""
        
        if result.returncode != 0:
            return f"EXECUTION_ERROR (exit {result.returncode}):\n{stderr}\n{stdout}".strip()
        
        return stdout if stdout else "(no output)"
        
    except subprocess.TimeoutExpired:
        return "TIMEOUT_ERROR: Code execution exceeded 15 second limit"
    except Exception as e:
        return f"EXECUTION_ERROR: {type(e).__name__}: {e}"
    finally:
        # Always cleanup temp file
        if temp_file and os.path.exists(temp_file):
            try:
                os.remove(temp_file)
            except:
                pass


def sandbox_write(params: dict) -> str:
    """
    Write content to a file in the workspace with security checks.
    
    Security measures:
    1. Extension allowlist validation
    2. Path traversal prevention
    3. Content size limits
    4. Atomic write via temp file
    5. Workspace boundary verification
    """
    filename = params.get("filename", "")
    content = params.get("content", "")
    
    # Validate filename
    if not filename:
        return "ERROR: No filename provided"
    
    # Check for path traversal attempts
    if ".." in filename or "/" in filename or "\\" in filename:
        return "ERROR: Path traversal detected"
    
    # Extract basename and validate extension
    basename = os.path.basename(filename)
    _, ext = os.path.splitext(basename)
    
    if ext.lower() not in ALLOWED_EXTENSIONS:
        return f"ERROR: Extension '{ext}' not allowed. Allowed: {', '.join(ALLOWED_EXTENSIONS)}"
    
    # Check content size
    content_bytes = content.encode('utf-8')
    if len(content_bytes) > MAX_FILE_SIZE:
        return f"ERROR: Content size ({len(content_bytes)} bytes) exceeds limit ({MAX_FILE_SIZE} bytes)"
    
    # Build target path
    target_path = WORKSPACE_DIR / basename
    
    # Verify the resolved path is within workspace
    try:
        resolved_path = target_path.resolve()
        resolved_workspace = WORKSPACE_DIR.resolve()
        if not str(resolved_path).startswith(str(resolved_workspace)):
            return "ERROR: File path escapes workspace boundary"
    except Exception as e:
        return f"ERROR: Path resolution failed: {e}"
    
    # Atomic write via temp file
    temp_path = None
    try:
        temp_fd, temp_path = tempfile.mkstemp(
            dir=WORKSPACE_DIR,
            prefix=".tmp_write_"
        )
        
        with os.fdopen(temp_fd, 'w', encoding='utf-8') as f:
            f.write(content)
        
        # Atomic replace
        os.replace(temp_path, target_path)
        
        return f"SUCCESS: Wrote {len(content_bytes)} bytes to {basename}"
        
    except Exception as e:
        return f"ERROR: Write failed: {type(e).__name__}: {e}"
    finally:
        if temp_path and os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass


def sandbox_read(params: dict) -> str:
    """
    Read a file from the workspace with security checks.
    
    Security measures:
    1. Path traversal prevention
    2. Workspace boundary verification
    3. File size limits
    """
    filename = params.get("filename", "")
    
    if not filename:
        return "ERROR: No filename provided"
    
    # Check for path traversal
    if ".." in filename or "/" in filename or "\\" in filename:
        return "ERROR: Path traversal detected"
    
    # Build target path
    basename = os.path.basename(filename)
    target_path = WORKSPACE_DIR / basename
    
    # Verify within workspace
    try:
        resolved_path = target_path.resolve()
        resolved_workspace = WORKSPACE_DIR.resolve()
        if not str(resolved_path).startswith(str(resolved_workspace)):
            return "ERROR: File path escapes workspace boundary"
    except Exception as e:
        return f"ERROR: Path resolution failed: {e}"
    
    # Check file exists
    if not target_path.exists():
        return f"ERROR: File '{basename}' not found"
    
    # Check file size before reading
    file_size = target_path.stat().st_size
    if file_size > MAX_FILE_SIZE:
        return f"ERROR: File size ({file_size} bytes) exceeds limit ({MAX_FILE_SIZE} bytes)"
    
    try:
        with open(target_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return content
    except Exception as e:
        return f"ERROR: Read failed: {type(e).__name__}: {e}"


class SafeMathEvaluator(ast.NodeVisitor):
    """AST visitor for safely evaluating mathematical expressions."""
    
    ALLOWED_NODES = (
        ast.Expression, ast.BinOp, ast.UnaryOp, ast.Num, ast.Constant,
        ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.Mod, ast.FloorDiv,
        ast.USub, ast.UAdd
    )
    
    def __init__(self):
        self.safe = True
    
    def visit(self, node):
        if not isinstance(node, self.ALLOWED_NODES):
            self.safe = False
        return self.generic_visit(node)


def sandbox_calculate(params: dict) -> str:
    """
    Evaluate a mathematical expression safely using AST.
    
    Only allows: numbers, +, -, *, /, **, %, //
    """
    expression = params.get("expression", "").strip()
    
    if not expression:
        return "ERROR: Empty expression"
    
    if len(expression) > 200:
        return "ERROR: Expression too long (max 200 chars)"
    
    try:
        # Parse the expression
        tree = ast.parse(expression, mode='eval')
        
        # Validate AST nodes
        evaluator = SafeMathEvaluator()
        evaluator.visit(tree)
        
        if not evaluator.safe:
            return "SECURITY_VIOLATION: Expression contains disallowed operations"
        
        # Evaluate safely
        result = eval(compile(tree, '<string>', 'eval'), {"__builtins__": {}}, {})
        return str(result)
        
    except SyntaxError as e:
        return f"SYNTAX_ERROR: {e}"
    except ZeroDivisionError:
        return "ERROR: Division by zero"
    except OverflowError:
        return "ERROR: Numeric overflow"
    except Exception as e:
        return f"ERROR: {type(e).__name__}: {e}"


@dataclass
class Tool:
    """Definition of a tool that can be executed by the agent system."""
    name: str
    description: str
    params_schema: dict
    handler: Callable
    max_risk: str  # maximum risk_level allowed to execute this tool


class ToolRegistry:
    """Registry for managing available tools in the system."""
    
    def __init__(self):
        self._tools: dict[str, Tool] = {}
        self._register_builtin_tools()
    
    def register(self, tool: Tool) -> None:
        """Register a new tool."""
        self._tools[tool.name] = tool
        logger.debug(f"Registered tool: {tool.name}")
    
    def get(self, name: str) -> Optional[Tool]:
        """Get a tool by name."""
        return self._tools.get(name)
    
    def list_tools(self) -> list[dict]:
        """List all registered tools with their metadata."""
        return [
            {
                "name": tool.name,
                "description": tool.description,
                "params_schema": tool.params_schema,
                "max_risk": tool.max_risk,
            }
            for tool in self._tools.values()
        ]
    
    def _register_builtin_tools(self) -> None:
        """Register the built-in tools."""
        # Python REPL tool
        self.register(Tool(
            name="python_repl",
            description="Execute Python code in a sandboxed subprocess with AST security analysis",
            params_schema={
                "type": "object",
                "properties": {
                    "code": {
                        "type": "string",
                        "description": "Python code to execute"
                    }
                },
                "required": ["code"]
            },
            handler=sandbox_python,
            max_risk="medium"
        ))
        
        # File write tool
        self.register(Tool(
            name="file_write",
            description="Write text content to a file in the workspace (.txt/.json/.csv/.md/.log only)",
            params_schema={
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string",
                        "description": "Filename with allowed extension"
                    },
                    "content": {
                        "type": "string",
                        "description": "Content to write"
                    }
                },
                "required": ["filename", "content"]
            },
            handler=sandbox_write,
            max_risk="low"
        ))
        
        # File read tool
        self.register(Tool(
            name="file_read",
            description="Read a text file from the workspace",
            params_schema={
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string",
                        "description": "Filename to read"
                    }
                },
                "required": ["filename"]
            },
            handler=sandbox_read,
            max_risk="low"
        ))
        
        # Calculate tool
        self.register(Tool(
            name="calculate",
            description="Evaluate a safe mathematical expression",
            params_schema={
                "type": "object",
                "properties": {
                    "expression": {
                        "type": "string",
                        "description": "Mathematical expression to evaluate"
                    }
                },
                "required": ["expression"]
            },
            handler=sandbox_calculate,
            max_risk="low"
        ))
        
        # Reject tool
        self.register(Tool(
            name="reject",
            description="Reject unsafe or invalid user request",
            params_schema={
                "type": "object",
                "properties": {
                    "reason": {
                        "type": "string",
                        "description": "Reason for rejection"
                    }
                },
                "required": ["reason"]
            },
            handler=lambda params: f"Request rejected: {params.get('reason', 'Safety violation')}",
            max_risk="critical"  # Always allowed
        ))


# Global registry instance - initialized after all functions are defined
_registry = None


def get_registry() -> ToolRegistry:
    """Get the global tool registry (lazy initialization)."""
    global _registry
    if _registry is None:
        _registry = ToolRegistry()
    return _registry


def execution_node(state: dict) -> dict:
    """
    Execute the winning action using the tool registry.
    
    This is a LangGraph node that returns state updates.
    """
    thread_id = state.get("thread_id", "unknown")
    winning_action = state.get("winning_action")
    
    if not winning_action:
        return {
            "execution_result": "ERROR: No winning action to execute",
            "status": "escalated"
        }
    
    tool_name = winning_action.get("proposed_action")
    action_params = winning_action.get("action_params", {})
    risk_level = winning_action.get("risk_level", "medium")
    
    # Look up tool
    registry = get_registry()
    tool = registry.get(tool_name)
    
    if not tool:
        return {
            "execution_result": f"ERROR: Unknown tool: {tool_name}",
            "status": "escalated"
        }
    
    # Risk level checks
    if risk_level == "high":
        return {
            "execution_result": "BLOCKED: High risk action blocked by execution policy",
            "status": "escalated"
        }
    
    if risk_level == "critical" and tool.name != "reject":
        return {
            "execution_result": "BLOCKED: Critical risk action escalated",
            "status": "escalated"
        }
    
    # Log execution start
    params_hash = _hash_params(action_params)
    log_execution_start(logger, tool_name, params_hash, thread_id)
    
    # Execute tool
    import time
    start_time = time.time()
    
    try:
        result = tool.handler(action_params)
        duration_ms = int((time.time() - start_time) * 1000)
        
        log_execution_end(logger, len(result), duration_ms, thread_id)
        
        return {
            "execution_result": result,
            "status": "complete"
        }
        
    except Exception as e:
        duration_ms = int((time.time() - start_time) * 1000)
        error_msg = f"Execution error: {type(e).__name__}: {e}"
        
        logger.error(
            "EXECUTION_FAILED",
            tool=tool_name,
            error=error_msg,
            duration_ms=duration_ms,
            thread_id=thread_id
        )
        
        return {
            "execution_result": error_msg,
            "status": "escalated",
            "error_log": [{
                "timestamp": __import__('datetime').datetime.utcnow().isoformat() + "Z",
                "event": "EXECUTION_FAILED",
                "tool": tool_name,
                "error": error_msg,
            }]
        }
