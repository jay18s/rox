"""
Byzantine Fault-Tolerant Agent System - Structured Logging Configuration

Uses structlog for JSON-formatted structured logging with both
console (colored) and file (rotating) outputs.
"""

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

import structlog


# Log directory setup
LOG_DIR = Path(__file__).parent / "logs"
LOG_DIR.mkdir(exist_ok=True)
LOG_FILE = LOG_DIR / "agent.log"


def configure_logging():
    """Configure structured logging for the application."""
    
    # Standard library logging setup
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=logging.DEBUG,
    )
    
    # Rotating file handler (max 10MB, keep 3 backups)
    file_handler = RotatingFileHandler(
        LOG_FILE,
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    
    # Configure structlog
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer() if _is_file_logging() else structlog.dev.ConsoleRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )
    
    # Get root logger and add handlers
    root_logger = logging.getLogger()
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)
    
    return structlog.get_logger()


def _is_file_logging() -> bool:
    """Check if we're in a context that needs JSON formatting."""
    # For file output, we use JSON; for console, we use pretty printing
    return False


def get_logger(name: str = None):
    """Get a structured logger instance."""
    if name:
        return structlog.get_logger(name)
    return structlog.get_logger()


# Event type constants for consistent logging
class LogEvent:
    """Standardized event types for logging."""
    
    # Agent lifecycle
    AGENT_CALL_START = "AGENT_CALL_START"
    AGENT_CALL_END = "AGENT_CALL_END"
    AGENT_CALL_FAILED = "AGENT_CALL_FAILED"
    AGENT_CIRCUIT_OPEN = "AGENT_CIRCUIT_OPEN"
    AGENT_CIRCUIT_CLOSED = "AGENT_CIRCUIT_CLOSED"
    
    # Consensus
    CONSENSUS_REACHED = "CONSENSUS_REACHED"
    CONSENSUS_FAILED = "CONSENSUS_FAILED"
    VOTE_CAST = "VOTE_CAST"
    
    # Arbitration
    ARBITRATION = "ARBITRATION"
    ARBITRATION_BLOCKED = "ARBITRATION_BLOCKED"
    
    # Execution
    EXECUTION_START = "EXECUTION_START"
    EXECUTION_END = "EXECUTION_END"
    EXECUTION_BLOCKED = "EXECUTION_BLOCKED"
    
    # Escalation
    ESCALATION = "ESCALATION"
    
    # Security
    SECURITY_VIOLATION = "SECURITY_VIOLATION"
    PROMPT_INJECTION_DETECTED = "PROMPT_INJECTION_DETECTED"
    
    # System
    TASK_STARTED = "TASK_STARTED"
    TASK_COMPLETED = "TASK_COMPLETED"
    HITL_INTERRUPT = "HITL_INTERRUPT"
    HITL_RESUME = "HITL_RESUME"


def log_agent_call_start(logger, agent_id: str, model: str, round_id: int, thread_id: str):
    """Log agent call start event."""
    logger.info(
        LogEvent.AGENT_CALL_START,
        agent_id=agent_id,
        model=model,
        round_id=round_id,
        thread_id=thread_id,
    )


def log_agent_call_end(logger, agent_id: str, duration_ms: int, vote_cast: dict, thread_id: str):
    """Log agent call end event."""
    logger.info(
        LogEvent.AGENT_CALL_END,
        agent_id=agent_id,
        duration_ms=duration_ms,
        vote_cast=vote_cast,
        thread_id=thread_id,
    )


def log_agent_call_failed(logger, agent_id: str, error: str, circuit_state: str, thread_id: str):
    """Log agent call failure event."""
    logger.error(
        LogEvent.AGENT_CALL_FAILED,
        agent_id=agent_id,
        error=error,
        circuit_state=circuit_state,
        thread_id=thread_id,
    )


def log_consensus_reached(logger, action: str, confidence_score: int, round_id: int, thread_id: str):
    """Log consensus reached event."""
    logger.info(
        LogEvent.CONSENSUS_REACHED,
        action=action,
        confidence_score=confidence_score,
        round_id=round_id,
        thread_id=thread_id,
    )


def log_arbitration(logger, winner: dict, score: float, reflection_count: int, thread_id: str):
    """Log arbitration event."""
    logger.warning(
        LogEvent.ARBITRATION,
        winner=winner,
        score=score,
        reflection_count=reflection_count,
        thread_id=thread_id,
    )


def log_execution_start(logger, tool: str, params_hash: str, thread_id: str):
    """Log execution start event."""
    logger.info(
        LogEvent.EXECUTION_START,
        tool=tool,
        params_hash=params_hash,
        thread_id=thread_id,
    )


def log_execution_end(logger, result_length: int, duration_ms: int, thread_id: str):
    """Log execution end event."""
    logger.info(
        LogEvent.EXECUTION_END,
        result_length=result_length,
        duration_ms=duration_ms,
        thread_id=thread_id,
    )


def log_escalation(logger, reason: str, all_votes_summary: list, thread_id: str):
    """Log escalation event."""
    logger.critical(
        LogEvent.ESCALATION,
        reason=reason,
        all_votes_summary=all_votes_summary,
        thread_id=thread_id,
    )


def log_security_violation(logger, violation_type: str, details: str, thread_id: str):
    """Log security violation event."""
    logger.critical(
        LogEvent.SECURITY_VIOLATION,
        violation_type=violation_type,
        details=details,
        thread_id=thread_id,
    )


# Initialize logging on module import
logger = configure_logging()
