"""
Circuit Breaker — per-agent fault tolerance.

States: CLOSED (healthy) | OPEN (failing, skip) | HALF_OPEN (testing recovery)

Usage:
    circuit = get_circuit_breaker()
    if circuit.can_execute("alpha"):
        # call agent
        circuit.record_success("alpha")
    else:
        # return abstain vote
"""

import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

logger = logging.getLogger(__name__)

FAILURE_THRESHOLD = 3     # consecutive failures before OPEN
COOLDOWN_SECONDS  = 60    # seconds in OPEN before testing HALF_OPEN
HALF_OPEN_SUCCESSES = 2   # successes in HALF_OPEN before returning CLOSED


class CircuitBreaker:
    """Thread-safe (asyncio) circuit breaker for agent calls."""

    def __init__(self):
        self._states: dict[str, dict] = {}

    def _get(self, agent_id: str) -> dict:
        if agent_id not in self._states:
            self._states[agent_id] = {
                "failures": 0,
                "status": "closed",
                "last_failure": None,
                "consecutive_successes": 0,
                "total_calls": 0,
                "total_failures": 0,
            }
        return self._states[agent_id]

    def can_execute(self, agent_id: str) -> bool:
        state = self._get(agent_id)
        state["total_calls"] += 1

        if state["status"] == "closed":
            return True

        if state["status"] == "open":
            if state["last_failure"]:
                last_fail = datetime.fromisoformat(
                    state["last_failure"].replace("Z", "+00:00")
                )
                if datetime.now(timezone.utc) - last_fail > timedelta(seconds=COOLDOWN_SECONDS):
                    state["status"] = "half_open"
                    state["consecutive_successes"] = 0
                    logger.info("Circuit %s → HALF_OPEN (cooldown elapsed)", agent_id)
                    return True
            return False

        # half_open
        return True

    def record_success(self, agent_id: str) -> None:
        state = self._get(agent_id)
        state["failures"] = 0
        state["consecutive_successes"] += 1
        if state["status"] == "half_open" and state["consecutive_successes"] >= HALF_OPEN_SUCCESSES:
            state["status"] = "closed"
            logger.info("Circuit %s → CLOSED (recovery confirmed)", agent_id)

    def record_failure(self, agent_id: str) -> None:
        state = self._get(agent_id)
        state["failures"] += 1
        state["total_failures"] += 1
        state["consecutive_successes"] = 0
        state["last_failure"] = datetime.now(timezone.utc).isoformat()

        if state["status"] == "half_open":
            state["status"] = "open"
            logger.warning("Circuit %s → OPEN (failure in HALF_OPEN)", agent_id)
        elif state["failures"] >= FAILURE_THRESHOLD:
            state["status"] = "open"
            logger.warning(
                "Circuit %s → OPEN (%d consecutive failures)", agent_id, state["failures"]
            )

    def get_health_report(self) -> dict[str, str]:
        return {aid: s["status"] for aid, s in self._states.items()}

    def get_full_report(self) -> dict[str, dict]:
        return {
            aid: {
                "status": s["status"],
                "failures": s["failures"],
                "total_calls": s["total_calls"],
                "total_failures": s["total_failures"],
                "last_failure": s["last_failure"],
            }
            for aid, s in self._states.items()
        }


# Module-level singleton
_circuit_breaker: Optional[CircuitBreaker] = None


def get_circuit_breaker() -> CircuitBreaker:
    global _circuit_breaker
    if _circuit_breaker is None:
        _circuit_breaker = CircuitBreaker()
    return _circuit_breaker
