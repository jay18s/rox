"""
Byzantine Fault-Tolerant Agent System - Consensus and Arbitration

This module provides:
- Voting node for parallel agent execution
- Consensus router for determining next steps
- Select winner node for choosing the winning action
- Arbitration node for handling disagreements
- Arbitration router for loop-back logic
"""

import asyncio
import json
from typing import Literal

from agent.byzantine.agents import node_alpha, node_beta, node_gamma, get_circuit_breaker
from agent.byzantine.state import Vote, create_timestamp
import logging
logger = logging.getLogger(__name__)

def log_consensus_reached(lgr, action, score, round_id, thread_id): lgr.info("CONSENSUS_REACHED action=%s score=%d round=%d thread=%s", action, score, round_id, thread_id)
def log_arbitration(lgr, winner, score, refl, thread_id): lgr.warning("ARBITRATION winner=%s score=%.1f refl=%d thread=%s", winner, score, refl, thread_id)




async def voting_node(state: dict) -> dict:
    """
    Execute all three agents in parallel and collect their votes.
    
    This node:
    1. Increments the current_round counter
    2. Runs all three agents via asyncio.gather
    3. Filters and validates results
    4. Returns new votes for this round
    """
    thread_id = state.get("thread_id", "unknown")
    new_round = state.get("current_round", 0) + 1
    
    logger.info(
        "VOTING_START",
        thread_id=thread_id,
        new_round=new_round,
    )
    
    # Run all agents in parallel with exception handling
    results = await asyncio.gather(
        node_alpha(state),
        node_beta(state),
        node_gamma(state),
        return_exceptions=True,
    )
    
    # Collect votes from results
    all_votes = []
    errors = []
    
    for i, result in enumerate(results):
        agent_names = ["alpha", "beta", "gamma"]
        agent_id = agent_names[i]
        
        if isinstance(result, Exception):
            # Agent raised an exception
            logger.error(
                "AGENT_EXCEPTION",
                agent_id=agent_id,
                error=str(result),
                thread_id=thread_id,
            )
            errors.append({
                "timestamp": create_timestamp(),
                "agent_id": agent_id,
                "error": f"Exception: {type(result).__name__}: {str(result)}",
            })
            # Create fault vote
            fault_vote = Vote(
                agent_id=agent_id,
                round_id=new_round,
                proposed_action="BYZANTINE_FAULT",
                action_params={},
                reasoning=f"Exception: {type(result).__name__}",
                confidence=0,
                risk_level="critical",
                raw_output=str(result)[:300],
                timestamp=create_timestamp(),
            )
            all_votes.append(fault_vote)
        elif isinstance(result, dict) and "votes" in result:
            # Valid result with votes
            votes = result.get("votes", [])
            all_votes.extend(votes)
            
            # Collect any errors
            if "error_log" in result:
                errors.extend(result["error_log"])
        else:
            # Unexpected result format
            logger.warning(
                "UNEXPECTED_RESULT",
                agent_id=agent_id,
                result_type=type(result).__name__,
                thread_id=thread_id,
            )
    
    # Ensure all votes have the correct round_id
    for vote in all_votes:
        vote["round_id"] = new_round
    
    logger.info(
        "VOTING_COMPLETE",
        thread_id=thread_id,
        round=new_round,
        vote_count=len(all_votes),
    )
    
    return {
        "current_round": new_round,
        "votes": all_votes,
        "status": "voting",
        "error_log": errors,
    }


def _normalize_params(action: str, params: dict) -> str:
    """
    Normalize action parameters for consensus comparison.
    
    For python_repl: normalize whitespace in code
    For other actions: use sorted JSON
    """
    if action == "python_repl" and "code" in params:
        # Normalize Python code by stripping extra whitespace
        code = params["code"]
        # Simple normalization: strip leading/trailing whitespace from each line
        lines = [line.strip() for line in code.split('\n')]
        normalized = '\n'.join(line for line in lines if line)
        return json.dumps({"code": normalized}, sort_keys=True)
    else:
        return json.dumps(params, sort_keys=True)


def consensus_router(state: dict) -> Literal["execute", "arbitrate", "escalate"]:
    """
    Pure function router that determines next step based on votes.
    
    CRITICAL: This function NEVER mutates state. It only reads and returns routing string.
    
    Algorithm:
    1. Filter votes to current round only
    2. If ANY vote has risk_level == "critical": escalate
    3. Build confidence-weighted score per action
    4. If max weighted score >= 120: execute
    5. If reflection_count >= 3: escalate
    6. Else: arbitrate
    """
    thread_id = state.get("thread_id", "unknown")
    current_round = state.get("current_round", 0)
    reflection_count = state.get("reflection_count", 0)
    
    # Filter votes to current round only
    current_votes = [
        v for v in state.get("votes", [])
        if v.get("round_id") == current_round
    ]
    
    if not current_votes:
        logger.warning(
            "NO_VOTES",
            thread_id=thread_id,
            round=current_round,
        )
        return "escalate"
    
    # Check for critical risk votes
    critical_votes = [v for v in current_votes if v.get("risk_level") == "critical"]
    if critical_votes:
        logger.warning(
            "CRITICAL_RISK_DETECTED",
            thread_id=thread_id,
            agents=[v["agent_id"] for v in critical_votes],
        )
        return "escalate"
    
    # Build confidence-weighted scores
    weighted_scores: dict[tuple[str, str], int] = {}
    
    for vote in current_votes:
        action = vote.get("proposed_action", "")
        params = vote.get("action_params", {})
        confidence = vote.get("confidence", 0)
        
        # Skip fault votes
        if action in ("BYZANTINE_FAULT", ""):
            continue
        
        # Normalize params for comparison
        params_key = _normalize_params(action, params)
        key = (action, params_key)
        
        weighted_scores[key] = weighted_scores.get(key, 0) + confidence
    
    if not weighted_scores:
        logger.warning(
            "NO_VALID_VOTES",
            thread_id=thread_id,
            round=current_round,
        )
        return "arbitrate"
    
    # Find max weighted score
    max_score = max(weighted_scores.values())
    
    logger.debug(
        "CONSENSUS_SCORES",
        thread_id=thread_id,
        scores=weighted_scores,
        max_score=max_score,
    )
    
    # Check for sufficient consensus (>= 120 ~= 2 confident agents)
    if max_score >= 120:
        return "execute"
    
    # Check reflection limit
    if reflection_count >= 3:
        logger.warning(
            "REFLECTION_LIMIT_REACHED",
            thread_id=thread_id,
            reflection_count=reflection_count,
        )
        return "escalate"
    
    # Need arbitration
    return "arbitrate"


def select_winner_node(state: dict) -> dict:
    """
    Select the winning action when consensus is reached.
    
    Runs BEFORE execution when consensus_router returns "execute".
    """
    thread_id = state.get("thread_id", "unknown")
    current_round = state.get("current_round", 0)
    
    # Filter to current round votes
    current_votes = [
        v for v in state.get("votes", [])
        if v.get("round_id") == current_round
    ]
    
    # Build weighted scores
    weighted_scores: dict[tuple[str, str], int] = {}
    vote_map: dict[tuple[str, str], list[Vote]] = {}
    
    for vote in current_votes:
        action = vote.get("proposed_action", "")
        params = vote.get("action_params", {})
        confidence = vote.get("confidence", 0)
        
        if action in ("BYZANTINE_FAULT", ""):
            continue
        
        params_key = _normalize_params(action, params)
        key = (action, params_key)
        
        weighted_scores[key] = weighted_scores.get(key, 0) + confidence
        
        if key not in vote_map:
            vote_map[key] = []
        vote_map[key].append(vote)
    
    # Find action with highest weighted score
    if not weighted_scores:
        return {
            "winning_action": None,
            "consensus_reached": False,
            "status": "escalated",
        }
    
    best_key = max(weighted_scores.keys(), key=lambda k: weighted_scores[k])
    best_votes = vote_map[best_key]
    
    # Among votes for best action, pick highest confidence
    best_vote = max(best_votes, key=lambda v: v.get("confidence", 0))
    
    log_consensus_reached(
        logger,
        best_vote["proposed_action"],
        weighted_scores[best_key],
        current_round,
        thread_id,
    )
    
    return {
        "winning_action": best_vote,
        "consensus_reached": True,
        "status": "executing",
    }


def arbitration_node(state: dict) -> dict:
    """
    Handle voting disagreements by selecting the best vote.
    
    CRITICAL: Returns state delta dict - NEVER mutates state directly.
    """
    thread_id = state.get("thread_id", "unknown")
    current_round = state.get("current_round", 0)
    reflection_count = state.get("reflection_count", 0)
    
    # Filter current-round valid votes
    current_votes = [
        v for v in state.get("votes", [])
        if v.get("round_id") == current_round
        and v.get("proposed_action") not in ("BYZANTINE_FAULT", "", "reject")
    ]
    
    if not current_votes:
        logger.warning(
            "ARBITRATION_NO_VALID_VOTES",
            thread_id=thread_id,
            round=current_round,
        )
        return {
            "status": "escalated",
            "reflection_count": reflection_count + 1,
        }
    
    # Risk weights
    risk_weights = {
        "low": 1.0,
        "medium": 0.8,
        "high": 0.3,
        "critical": 0.0,
    }
    
    # Agent priority weights (gamma is safety-tuned)
    agent_weights = {
        "alpha": 1.0,
        "beta": 0.9,
        "gamma": 1.1,
    }
    
    def score_vote(vote: Vote) -> float:
        confidence = vote.get("confidence", 0)
        risk = vote.get("risk_level", "medium")
        agent = vote.get("agent_id", "")
        
        risk_weight = risk_weights.get(risk, 0.5)
        agent_weight = agent_weights.get(agent, 1.0)
        
        return confidence * risk_weight * agent_weight
    
    # Find best vote
    best_vote = max(current_votes, key=score_vote)
    best_score = score_vote(best_vote)
    
    log_arbitration(
        logger,
        {
            "agent": best_vote["agent_id"],
            "action": best_vote["proposed_action"],
            "confidence": best_vote["confidence"],
        },
        best_score,
        reflection_count + 1,
        thread_id,
    )
    
    # Check if best vote is too risky
    if best_vote.get("risk_level") == "high" and best_vote.get("confidence", 0) < 80:
        return {
            "status": "escalated",
            "execution_result": "Arbitration blocked: high risk, low confidence",
            "reflection_count": reflection_count + 1,
        }
    
    # Return best vote as winner
    return {
        "winning_action": best_vote,
        "reflection_count": reflection_count + 1,
        "status": "arbitrating",
    }


def arbitration_router(state: dict) -> Literal["execute", "re_vote", "escalate"]:
    """
    Router from arbitration node to determine next step.
    
    This enables the loop-back for re-voting.
    """
    status = state.get("status")
    winning_action = state.get("winning_action")
    reflection_count = state.get("reflection_count", 0)
    
    # If escalated during arbitration
    if status == "escalated":
        return "escalate"
    
    # If we have a winning action, execute
    if winning_action is not None:
        return "execute"
    
    # If under reflection limit, try re-voting
    if reflection_count < 3:
        return "re_vote"
    
    # Max reflections reached
    return "escalate"
