"""
Byzantine State Schema — ZeroClaw-Byzantine Integration.

Extended from Kimi's excellent state.py with:
- memory_context field (ZeroClaw SOUL + facts + summary injected here)
- proposed_tool / proposed_params (from main agent's proposed action)
- trim reducers to prevent OOM on long sessions
"""

from typing import TypedDict, Annotated, Optional, Literal
from datetime import datetime
import operator


# ── Custom reducers ────────────────────────────────────────────────────────────

def trim_reducer(existing: list, new: list, max_size: int = 20) -> list:
    """Combine and trim list to max_size entries."""
    combined = existing + new
    return combined[-max_size:]


def trim_messages_reducer(existing: list, new: list) -> list:
    return trim_reducer(existing, new, max_size=20)


def trim_errors_reducer(existing: list, new: list) -> list:
    return trim_reducer(existing, new, max_size=50)


def trim_votes_reducer(existing: list, new: list) -> list:
    return trim_reducer(existing, new, max_size=50)


# ── Vote TypedDict ─────────────────────────────────────────────────────────────

class Vote(TypedDict):
    """A single agent's vote on how to handle a task."""
    agent_id: str
    round_id: int                    # CRITICAL: tags vote to a specific round
    proposed_action: str
    action_params: dict
    reasoning: str
    confidence: int
    risk_level: Literal["low", "medium", "high", "critical"]
    raw_output: str
    timestamp: str


class AgentHealth(TypedDict):
    failures: int
    status: Literal["closed", "open", "half_open"]
    last_failure: Optional[str]
    consecutive_successes: int


# ── Main State ─────────────────────────────────────────────────────────────────

class ByzantineState(TypedDict):
    """
    Complete state for the Byzantine fault-tolerant agent system.

    Integration fields:
      memory_context  — ZeroClaw SOUL.md + user facts + summary (injected before voting)
      proposed_tool   — Tool name proposed by ZeroClaw's main LLM
      proposed_params — Params proposed by ZeroClaw's main LLM

    All state updates MUST be via return dicts — never direct mutation.
    """
    # ZeroClaw integration fields
    memory_context: str              # Injected ZeroClaw context (SOUL + facts + summary)
    proposed_tool: str               # Original tool proposed by main agent
    proposed_params: dict            # Original params proposed by main agent

    # Core input
    user_input: str
    messages: Annotated[list[dict], trim_messages_reducer]

    # Voting system — round_id on each vote is MANDATORY
    votes: Annotated[list[Vote], trim_votes_reducer]
    current_round: int

    # Consensus and execution
    consensus_reached: bool
    winning_action: Optional[Vote]
    execution_result: Optional[str]

    # Reflection / retry tracking
    reflection_count: int

    # Status tracking
    status: Literal[
        "voting", "arbitrating", "executing", "complete",
        "escalated", "awaiting_human"
    ]

    # Error and health tracking
    error_log: Annotated[list[dict], trim_errors_reducer]
    agent_health: dict

    # Human-in-the-loop
    human_decision: Optional[str]
    thread_id: str


# ── State factories ────────────────────────────────────────────────────────────

def create_default_state(
    thread_id: str = "default",
    user_input: str = "",
    proposed_tool: str = "",
    proposed_params: dict = None,
    memory_context: str = "",
) -> ByzantineState:
    """Create a fresh state with default values."""
    return {
        "memory_context": memory_context,
        "proposed_tool": proposed_tool,
        "proposed_params": proposed_params or {},
        "user_input": user_input,
        "messages": [{"role": "user", "content": user_input}] if user_input else [],
        "votes": [],
        "current_round": 0,
        "consensus_reached": False,
        "winning_action": None,
        "execution_result": None,
        "reflection_count": 0,
        "status": "voting",
        "error_log": [],
        "agent_health": {
            "alpha": {"failures": 0, "status": "closed", "last_failure": None, "consecutive_successes": 0},
            "beta":  {"failures": 0, "status": "closed", "last_failure": None, "consecutive_successes": 0},
            "gamma": {"failures": 0, "status": "closed", "last_failure": None, "consecutive_successes": 0},
        },
        "human_decision": None,
        "thread_id": thread_id,
    }


def create_timestamp() -> str:
    return datetime.utcnow().isoformat() + "Z"


def create_vote(
    agent_id: str,
    round_id: int,
    proposed_action: str,
    action_params: dict,
    reasoning: str,
    confidence: int,
    risk_level: Literal["low", "medium", "high", "critical"],
    raw_output: str,
) -> Vote:
    """Factory function to create a properly timestamped Vote."""
    return {
        "agent_id": agent_id,
        "round_id": round_id,
        "proposed_action": proposed_action,
        "action_params": action_params,
        "reasoning": reasoning[:300],
        "confidence": max(0, min(100, int(confidence))),
        "risk_level": risk_level if risk_level in ("low", "medium", "high", "critical") else "medium",
        "raw_output": raw_output[:300],
        "timestamp": create_timestamp(),
    }


# Sentinel votes
BYZANTINE_FAULT_VOTE: Vote = {
    "agent_id": "fault", "round_id": -1,
    "proposed_action": "BYZANTINE_FAULT", "action_params": {},
    "reasoning": "Agent failed to produce valid output",
    "confidence": 0, "risk_level": "critical",
    "raw_output": "", "timestamp": "",
}

ABSTAIN_VOTE: Vote = {
    "agent_id": "abstain", "round_id": -1,
    "proposed_action": "reject",
    "action_params": {"reason": "Circuit breaker open — agent abstaining"},
    "reasoning": "Circuit breaker prevented agent execution",
    "confidence": 0, "risk_level": "medium",
    "raw_output": "", "timestamp": "",
}
