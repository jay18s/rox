"""
Workflow-based Engine using LangGraph-style architecture.

This engine replaces the loop-based approach with a graph-based workflow:
- Nodes represent steps (LLM call, tool execution, routing)
- Edges define flow between nodes
- Conditional routing based on state
- Built-in tracing and debugging
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

from agent.workflow.graph import WorkflowGraph, CompiledGraph, Node, NodeResult, NodeStatus
from agent.workflow.state import WorkflowState
from agent.workflow.nodes import (
    LLMNode, ToolNode, RouterNode, PromptNode,
    RetrievalNode, OutputNode, ContextLoaderNode, FactExtractionNode, ErrorNode
)
from agent.tracing import Tracer, get_tracer

logger = logging.getLogger(__name__)


class WorkflowEngine:
    """
    LangGraph-style workflow engine for ZeroClaw Agent.
    
    Architecture (mirrors the screenshot):
    
    ┌─────────────────────────────────────────────────────────┐
    │                    ENTRY POINT                          │
    │                      (start)                            │
    └─────────────────────┬───────────────────────────────────┘
                          │
                          ▼
    ┌─────────────────────────────────────────────────────────┐
    │                 CONTEXT LOADER                          │
    │     Load facts, summary, history from memory           │
    └─────────────────────┬───────────────────────────────────┘
                          │
                          ▼
    ┌─────────────────────────────────────────────────────────┐
    │                 EXECUTION ROUTER                        │
    │    Determine what type of request this is              │
    └─────────┬───────────────────────────────────┬───────────┘
              │                                   │
              ▼                                   ▼
    ┌─────────────────┐                 ┌─────────────────────┐
    │   SIMPLE LLM    │                 │   AGENTIC LOOP      │
    │     NODE        │                 │   (ReAct pattern)   │
    └────────┬────────┘                 └──────────┬──────────┘
             │                                     │
             │                          ┌──────────┴──────────┐
             │                          ▼                     ▼
             │                  ┌─────────────┐      ┌──────────────┐
             │                  │  LLM NODE   │◄────►│  TOOL NODE   │
             │                  └──────┬──────┘      └──────────────┘
             │                         │
             └────────────┬────────────┘
                          │
                          ▼
    ┌─────────────────────────────────────────────────────────┐
    │                   OUTPUT NODE                           │
    │         Format and return final response               │
    └─────────────────────────────────────────────────────────┘
                          │
                          ▼
    ┌─────────────────────────────────────────────────────────┐
    │                    TRACING                              │
    │    LangSmith-style trace logging and decisions         │
    └─────────────────────────────────────────────────────────┘
    """
    
    def __init__(
        self,
        llm: Any,
        memory: Any,
        tool_executor: Any,
        workspace_memory: Any,
        config: dict[str, Any],
    ):
        self.llm = llm
        self.memory = memory
        self.tool_executor = tool_executor
        self.ws_memory = workspace_memory
        self.config = config
        
        # Settings
        self.max_iterations = int(config.get("tool_loop_max", 10))
        self.enable_react = config.get("enable_react", True)
        self.enable_tracing = config.get("enable_tracing", True)
        
        # Initialize tracer
        if self.enable_tracing:
            self.tracer = get_tracer()
        else:
            self.tracer = None
        
        # Build the workflow graph
        self.graph = self._build_workflow_graph()
        self.compiled_graph = self.graph.compile()
        
        logger.info("[WORKFLOW_ENGINE] Initialized with %d nodes", len(self.graph.nodes))
    
    def _build_workflow_graph(self) -> WorkflowGraph:
        """Build the workflow graph based on LangGraph pattern."""
        graph = WorkflowGraph(name="zeroclaw_agent")
        
        # Get tools description
        tools_desc = self.tool_executor.get_tools_description()
        
        # ═══════════════════════════════════════════════════════════════
        # CREATE NODES
        # ═══════════════════════════════════════════════════════════════
        
        # Node A: Context Loader
        context_node = ContextLoaderNode("load_context", self.memory)
        graph.add_node(context_node)
        
        # Node B: Fact Extraction
        fact_node = FactExtractionNode("extract_facts", self.memory)
        graph.add_node(fact_node)
        
        # Node C: LLM (for reasoning and generation)
        llm_node = LLMNode(
            name="llm_generate",
            llm=self.llm,
            tools_description=tools_desc,
        )
        graph.add_node(llm_node)
        
        # Node D: Tool Execution
        tool_node = ToolNode("execute_tool", self.tool_executor)
        graph.add_node(tool_node)
        
        # Node E: Router (decides what to do next)
        def router_logic(state: WorkflowState) -> str:
            """Determine the next step based on state."""
            # Check if we have a tool call pending
            if state.tool_calls and len(state.tool_results) < len(state.tool_calls):
                return "execute_tool"
            
            # Check if LLM response has a tool call
            last_tool_calls = state.tool_calls
            last_tool_results = state.tool_results
            if len(last_tool_calls) > len(last_tool_results):
                return "execute_tool"
            
            # Check if we have a final response
            if state.llm_response and not state.tool_calls:
                return "output"
            
            # Check iteration limit
            if len(state.visited_nodes) > self.max_iterations * 3:
                return "output"
            
            # Continue with LLM
            return "llm"
        
        router_node = RouterNode(
            name="router",
            router_func=router_logic,
            routes={
                "execute_tool": "execute_tool",
                "output": "output",
                "llm": "llm_generate",
            }
        )
        graph.add_node(router_node)
        
        # Node F: Output
        output_node = OutputNode("output")
        graph.add_node(output_node)
        
        # Node G: Error Handler
        error_node = ErrorNode("handle_error")
        graph.add_node(error_node)
        
        # ═══════════════════════════════════════════════════════════════
        # CREATE EDGES (flow between nodes)
        # ═══════════════════════════════════════════════════════════════
        
        # Entry → Context Loader
        graph.set_entry_point("load_context")
        
        # Context → Fact Extraction
        graph.add_edge("load_context", "extract_facts")
        
        # Facts → LLM
        graph.add_edge("extract_facts", "llm_generate")
        
        # LLM → Router (conditional)
        def llm_next(state: WorkflowState) -> str:
            """Determine next step after LLM."""
            # Check for tool call
            if state.tool_calls and len(state.tool_results) < len(state.tool_calls):
                return "execute_tool"
            # Otherwise, go to output
            return "output"
        
        graph.add_conditional_edges(
            source="llm_generate",
            condition=llm_next,
            routes={
                "execute_tool": "execute_tool",
                "output": "output",
            }
        )
        
        # Tool → LLM (continue the loop)
        graph.add_edge("execute_tool", "llm_generate")
        
        # Output is a finish point
        graph.set_finish_point("output")
        
        # Set tracer
        if self.tracer:
            graph.set_tracer(self.tracer)
        
        return graph
    
    async def process(
        self,
        message: dict[str, Any],
        session_history: list[dict[str, str]],
        user_id: str,
        channel: str,
    ) -> str:
        """
        Process a message through the workflow graph.
        
        This replaces the loop-based process() method with graph execution.
        """
        # Create initial state
        state = WorkflowState.create_for_request(
            user_input=message["text"],
            user_id=user_id,
            channel=channel,
            history=session_history,
        )
        
        # Add workspace memory context
        state.context["workspace"] = self.ws_memory.build_context_block()
        
        logger.info("[WORKFLOW_ENGINE] Starting workflow for %s/%s: %r", 
                    channel, user_id, message["text"][:50])
        
        # Execute with tracing
        if self.tracer:
            with self.tracer.trace(
                name="agent_request",
                user_id=user_id,
                channel=channel,
                input=message["text"],
            ) as trace:
                # Run the workflow
                final_state = await self.compiled_graph(state)
                
                # Log final result
                self.tracer.log_decision(
                    "workflow_complete",
                    "success" if not final_state.has_errors() else "error",
                    f"Visited {len(final_state.visited_nodes)} nodes"
                )
        else:
            # Run without tracing
            final_state = await self.compiled_graph(state)
        
        # Get final response
        response = final_state.final_response or final_state.llm_response
        
        if not response:
            response = "I apologize, but I couldn't generate a response. Please try again."
        
        # Persist to memory
        try:
            await self.memory.store_conversation(user_id, "user", message["text"])
            await self.memory.store_conversation(user_id, "assistant", response)
        except Exception as e:
            logger.warning("Failed to persist conversation: %s", e)
        
        # Log to daily file
        self.ws_memory.append_daily_log(
            f"**User ({user_id}):** {message['text'][:120]}\n"
            f"**Agent:** {response[:200]}"
        )
        
        logger.info("[WORKFLOW_ENGINE] Completed workflow. Path: %s", 
                    " → ".join(final_state.visited_nodes))
        
        return response
    
    def get_graph_info(self) -> dict[str, Any]:
        """Get information about the workflow graph."""
        return self.compiled_graph.get_graph_info()
    
    def get_trace(self, trace_id: str) -> dict[str, Any] | None:
        """Get a trace by ID."""
        if self.tracer:
            return self.tracer.get_trace(trace_id)
        return None
    
    def get_user_traces(self, user_id: str, limit: int = 20) -> list[dict[str, Any]]:
        """Get recent traces for a user."""
        if self.tracer:
            return self.tracer.get_user_traces(user_id, limit)
        return []


# ═══════════════════════════════════════════════════════════════════════════════
# LEGACY ENGINE (for backward compatibility)
# ═══════════════════════════════════════════════════════════════════════════════

class CoreEngine(WorkflowEngine):
    """
    Backward-compatible engine that uses the workflow graph internally.
    
    This class provides the same interface as the original CoreEngine
    but uses the LangGraph-style workflow internally.
    """
    
    def __init__(
        self,
        llm: Any,
        memory: Any,
        tool_executor: Any,
        workspace_memory: Any,
        config: dict[str, Any],
    ) -> None:
        # Copy original config defaults
        config.setdefault("tool_loop_max", 10)
        config.setdefault("summarise_every_turns", 6)
        config.setdefault("self_review", True)
        config.setdefault("enable_react", True)
        config.setdefault("llm_fact_extraction", False)
        config.setdefault("enable_tracing", True)
        
        super().__init__(llm, memory, tool_executor, workspace_memory, config)
        
        # For backward compatibility
        self.max_iterations = self.max_iterations
        self.summarise_every = config["summarise_every_turns"]
        self.enable_review = config["self_review"]
        self.enable_react = config["enable_react"]
        self.llm_fact_extract = config["llm_fact_extraction"]
