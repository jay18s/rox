"""Base channel abstract class."""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class BaseChannel(ABC):
    """Abstract base class for all channel adapters."""

    def __init__(self, config: dict[str, Any], queue: asyncio.Queue) -> None:
        self.config = config
        self.queue = queue
        self.name: str = "base"

    @abstractmethod
    async def start(self) -> None:
        """Start listening for incoming messages."""
        ...

    @abstractmethod
    async def stop(self) -> None:
        """Gracefully stop the channel."""
        ...

    @abstractmethod
    async def send_message(self, text: str, user_id: str, chat_id: str | None = None) -> None:
        """Send a message back to the user."""
        ...
