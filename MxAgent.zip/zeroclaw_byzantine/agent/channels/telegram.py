"""Telegram channel adapter using python-telegram-bot v20+."""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Any

from agent.channels.base import BaseChannel

logger = logging.getLogger(__name__)


class TelegramChannel(BaseChannel):
    """Telegram bot channel using polling."""

    def __init__(self, config: dict[str, Any], queue: asyncio.Queue) -> None:
        super().__init__(config, queue)
        self.name = "telegram"
        self._application: Any = None

    async def start(self) -> None:
        """Initialize and start the Telegram bot."""
        token = os.environ.get("TELEGRAM_BOT_TOKEN")
        if not token:
            raise RuntimeError(
                "TELEGRAM_BOT_TOKEN environment variable is not set. "
                "Set it before starting the Telegram channel."
            )

        try:
            from telegram import Update
            from telegram.ext import Application, MessageHandler, filters
        except ImportError:
            raise RuntimeError(
                "python-telegram-bot is not installed. "
                "Run: pip install 'python-telegram-bot[job-queue]>=20.0'"
            )

        queue_ref = self.queue
        channel_name = self.name

        async def handle_message(update: Update, context: Any) -> None:
            if update.message and update.message.text:
                msg = {
                    "channel": channel_name,
                    "user_id": str(update.message.from_user.id),
                    "chat_id": str(update.message.chat_id),
                    "text": update.message.text,
                }
                logger.debug("Telegram message from %s: %s", msg["user_id"], msg["text"])
                await queue_ref.put(msg)

        self._application = (
            Application.builder()
            .token(token)
            .build()
        )

        self._application.add_handler(
            MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message)
        )

        logger.info("Telegram channel starting (polling)...")
        await self._application.initialize()
        await self._application.start()
        await self._application.updater.start_polling(drop_pending_updates=True)
        logger.info("Telegram polling started.")

    async def stop(self) -> None:
        """Stop the Telegram bot gracefully."""
        if self._application:
            logger.info("Stopping Telegram channel...")
            await self._application.updater.stop()
            await self._application.stop()
            await self._application.shutdown()

    async def send_message(self, text: str, user_id: str, chat_id: str | None = None) -> None:
        """Send a message to a Telegram chat."""
        if not self._application:
            logger.error("[TELEGRAM] Application not initialized.")
            return
        target_chat = chat_id or user_id
        try:
            # Try sending with Markdown first
            await self._application.bot.send_message(
                chat_id=int(target_chat),
                text=text,
                parse_mode="Markdown",
            )
            logger.info("[TELEGRAM] Message sent to %s (%d chars)", target_chat, len(text))
        except Exception as exc:
            # If Markdown fails, try without parsing
            logger.warning("[TELEGRAM] Markdown parse failed, sending plain text: %s", exc)
            try:
                await self._application.bot.send_message(
                    chat_id=int(target_chat),
                    text=text,
                )
                logger.info("[TELEGRAM] Plain text message sent to %s", target_chat)
            except Exception as exc2:
                logger.error("[TELEGRAM] Failed to send message to %s: %s", target_chat, exc2)
