"""
Web Search Tool — Tavily (primary) + Serper (fallback).

The agent calls this exactly like any other tool:
  {"tool": "web_search", "args": {"query": "NSE FII DII activity today"}}

Keys are read from .env:
  TAVILY_API_KEY=...
  SERPER_API_KEY=...
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import Any

logger = logging.getLogger(__name__)


# ── Tavily ────────────────────────────────────────────────────────────────────

async def _search_tavily(query: str, max_results: int = 5) -> list[dict[str, Any]]:
    """Search via Tavily API. Returns list of result dicts."""
    import urllib.request, urllib.error

    api_key = os.environ.get("TAVILY_API_KEY", "")
    if not api_key:
        raise RuntimeError("TAVILY_API_KEY not set in .env")

    payload = json.dumps({
        "api_key": api_key,
        "query":   query,
        "max_results": max_results,
        "search_depth": "basic",
        "include_answer": True,
    }).encode()

    req = urllib.request.Request(
        "https://api.tavily.com/search",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    loop = asyncio.get_event_loop()
    raw  = await loop.run_in_executor(None, _http_call, req)
    data = json.loads(raw)

    results = []
    # Tavily top-level answer (if available)
    if data.get("answer"):
        results.append({"title": "Tavily Answer", "snippet": data["answer"], "url": ""})
    for r in data.get("results", [])[:max_results]:
        results.append({
            "title":   r.get("title", ""),
            "snippet": r.get("content", ""),
            "url":     r.get("url", ""),
        })
    return results


# ── Serper ────────────────────────────────────────────────────────────────────

async def _search_serper(query: str, max_results: int = 5) -> list[dict[str, Any]]:
    """Search via Serper.dev API. Returns list of result dicts."""
    import urllib.request

    api_key = os.environ.get("SERPER_API_KEY", "")
    if not api_key:
        raise RuntimeError("SERPER_API_KEY not set in .env")

    payload = json.dumps({"q": query, "num": max_results}).encode()
    req = urllib.request.Request(
        "https://google.serper.dev/search",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "X-API-KEY": api_key,
        },
        method="POST",
    )

    loop = asyncio.get_event_loop()
    raw  = await loop.run_in_executor(None, _http_call, req)
    data = json.loads(raw)

    results = []
    # Answer box
    if data.get("answerBox", {}).get("answer"):
        results.append({
            "title":   data["answerBox"].get("title", "Answer"),
            "snippet": data["answerBox"]["answer"],
            "url":     "",
        })
    for r in data.get("organic", [])[:max_results]:
        results.append({
            "title":   r.get("title", ""),
            "snippet": r.get("snippet", ""),
            "url":     r.get("link", ""),
        })
    return results


# ── Sync HTTP helper (runs in executor) ───────────────────────────────────────

def _http_call(req: Any) -> str:
    import urllib.request, urllib.error
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code}: {body[:300]}")


# ── Public search function (Tavily → Serper fallback) ─────────────────────────

async def web_search(query: str, max_results: int = 5) -> str:
    """
    Search the web. Tries Tavily first, falls back to Serper.
    Returns a formatted string ready to be sent to the LLM.
    """
    logger.info("Web search: %r", query)
    results: list[dict[str, Any]] = []
    provider_used = ""
    error_log: list[str] = []

    # --- Primary: Tavily ---
    if os.environ.get("TAVILY_API_KEY"):
        try:
            results = await _search_tavily(query, max_results)
            provider_used = "Tavily"
            logger.info("Tavily returned %d results", len(results))
        except Exception as exc:
            logger.warning("Tavily failed: %s — trying Serper", exc)
            error_log.append(f"Tavily: {exc}")

    # --- Fallback: Serper ---
    if not results and os.environ.get("SERPER_API_KEY"):
        try:
            results = await _search_serper(query, max_results)
            provider_used = "Serper"
            logger.info("Serper returned %d results", len(results))
        except Exception as exc:
            logger.error("Serper also failed: %s", exc)
            error_log.append(f"Serper: {exc}")

    if not results:
        keys_missing = []
        if not os.environ.get("TAVILY_API_KEY"):
            keys_missing.append("TAVILY_API_KEY")
        if not os.environ.get("SERPER_API_KEY"):
            keys_missing.append("SERPER_API_KEY")
        if keys_missing:
            return (
                f"[Web Search Error] No API keys set. "
                f"Add to .env: {', '.join(keys_missing)}\n"
                f"Get Tavily key free at https://app.tavily.com\n"
                f"Get Serper key free at https://serper.dev"
            )
        return f"[Web Search Error] Both providers failed:\n" + "\n".join(error_log)

    # Format results for LLM consumption
    lines = [f"=== Web Search Results ({provider_used}): {query!r} ===\n"]
    for i, r in enumerate(results, 1):
        lines.append(f"{i}. {r['title']}")
        if r["snippet"]:
            lines.append(f"   {r['snippet']}")
        if r["url"]:
            lines.append(f"   {r['url']}")
        lines.append("")

    return "\n".join(lines)
