"""
Tool Executor — ZeroClaw ToolExecutor with hardened sandbox for run_python.

Replaces the naive subprocess.run(code) with AST-checked execution.
All other tools (web_search, read_file, list_files, etc.) are unchanged.

Security additions:
  - run_python: AST analysis + string obfuscation check before subprocess
  - write_file: extension allowlist + 100KB size limit + workspace boundary
  - calculate: AST-restricted evaluator (no eval on raw strings)
  - spawn_agent: unchanged, goes through Byzantine if enabled
"""

from __future__ import annotations

import ast
import asyncio
import json
import logging
import os
import platform
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_DANGEROUS_CHARS = set("&|;<>`$\n\r")

ALLOWED_WRITE_EXTENSIONS = {".txt", ".json", ".csv", ".md", ".log", ".py"}
MAX_FILE_SIZE = 100 * 1024  # 100KB

TOOLS_DESCRIPTION = """\
You have access to the following tools. Call ONE tool per response using this exact JSON:

### run_command
Run an allowlisted shell command inside the workspace.
{{"tool": "run_command", "args": {{"command": "<cmd>", "args": ["<arg1>"]}}}}
Allowed: {allowed_commands}

### run_python
Write Python code to a file and execute it in a sandboxed subprocess.
{{"tool": "run_python", "args": {{"filename": "script.py", "code": "<full python source>", "args": []}}}}

### write_file
Create or overwrite a file with given content (.txt/.json/.csv/.md/.log only).
{{"tool": "write_file", "args": {{"filename": "notes.txt", "content": "<text content>"}}}}

### read_file
Read a file from the workspace.
{{"tool": "read_file", "args": {{"filename": "notes.txt"}}}}

### list_files
List files in the workspace (or a subfolder).
{{"tool": "list_files", "args": {{"path": "."}}}}

### patch_file
Replace an exact string in a file.
{{"tool": "patch_file", "args": {{"filename": "script.py", "old": "bad code", "new": "fixed code"}}}}

### calculate
Evaluate a safe mathematical expression (no imports, pure math only).
{{"tool": "calculate", "args": {{"expression": "2 ** 10 + 5"}}}}

### web_search
Search the internet for current information.
{{"tool": "web_search", "args": {{"query": "<search query>", "max_results": 5}}}}

RULES:
- Always use relative paths (no ../ path traversal).
- For multi-step tasks: plan first, then call tools one at a time.
- If a tool returns an error, fix it in the next call.
- Only output the JSON — no surrounding text when calling a tool.
"""


# ── AST-based Python sandbox ──────────────────────────────────────────────────

def _ast_safe_check(code: str) -> str | None:
    """
    Return error string if code is unsafe, None if safe.
    Checks: Import/ImportFrom nodes, blocked built-in calls.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return f"SYNTAX_ERROR: {e}"

    BLOCKED_CALLS = {
        "eval", "exec", "compile", "open", "input", "__import__",
        "exit", "quit", "breakpoint", "help", "globals", "locals",
        "vars", "dir", "getattr", "setattr", "delattr",
    }

    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            return "SECURITY_VIOLATION: import statements are blocked"
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in BLOCKED_CALLS:
                return f"SECURITY_VIOLATION: call to {node.func.id}() is blocked"
            if isinstance(node.func, ast.Attribute) and node.func.attr in {
                "system", "popen", "spawn", "fork", "exec", "call", "run",
            }:
                return f"SECURITY_VIOLATION: .{node.func.attr}() is blocked"

    FORBIDDEN_STRINGS = [
        "base64", "codecs", "decode", "encode", "__builtins__", "__import__",
        "ctypes", "socket", "urllib", "requests", "pickle", "marshal",
        "subprocess", "os.system", "os.popen", "sys.modules", "importlib",
        "compile(", "exec(", "eval(",
    ]
    code_lower = code.lower()
    for pattern in FORBIDDEN_STRINGS:
        if pattern in code_lower:
            return f"SECURITY_VIOLATION: forbidden pattern '{pattern}'"

    return None


class ToolExecutor:
    """Sandboxed tool executor for the ZeroClaw-Byzantine agent."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.enabled: bool = config.get("enabled", True)
        self.workspace = Path(config.get("workspace", "workspace")).resolve()
        self.allowed_commands: list[str] = [
            c.lower() for c in config.get("allowed_commands", ["dir", "echo", "python"])
        ]
        self.timeout: int      = int(config.get("command_timeout", 30))
        self._is_windows       = platform.system() == "Windows"
        self._engine           = None
        self._orchestrator     = None

    def setup(self) -> None:
        self.workspace.mkdir(parents=True, exist_ok=True)
        logger.info("Workspace ready: %s", self.workspace)

    def get_tools_description(self) -> str:
        if not self.enabled:
            return ""
        base = TOOLS_DESCRIPTION.format(
            allowed_commands=", ".join(self.allowed_commands)
        )
        if self._orchestrator:
            base += self._orchestrator.get_spawn_tool_description()
        return base

    # ── Router ─────────────────────────────────────────────────────────────────

    async def execute(self, tool_call: dict[str, Any]) -> str:
        if not self.enabled:
            return "[Tool execution disabled in config]"
        tool = tool_call.get("tool", "")
        args = tool_call.get("args", {})
        dispatch = {
            "run_command":  self._run_command,
            "run_python":   self._run_python,
            "write_file":   self._write_file,
            "read_file":    self._read_file,
            "list_files":   self._list_files,
            "patch_file":   self._patch_file,
            "calculate":    self._calculate,
            "web_search":   self._web_search,
            "spawn_agent":  self._spawn_agent,
        }
        handler = dispatch.get(tool)
        if handler is None:
            return f"[Error] Unknown tool: '{tool}'. Available: {', '.join(dispatch)}"
        try:
            return await handler(args)
        except Exception as exc:
            logger.error("Tool '%s' raised: %s", tool, exc)
            return f"[Tool Error] {tool}: {exc}"

    # ── run_command ─────────────────────────────────────────────────────────────

    async def _run_command(self, args: dict[str, Any]) -> str:
        command: str       = args.get("command", "")
        cmd_args: list[str] = args.get("args", [])
        cmd_lower = Path(command).name.lower().removesuffix(".exe")
        if cmd_lower not in self.allowed_commands:
            return f"[Error] '{command}' not in allowlist. Allowed: {', '.join(self.allowed_commands)}"
        safe_args = []
        for a in cmd_args:
            a = str(a)
            if any(ch in a for ch in _DANGEROUS_CHARS):
                return f"[Error] Dangerous character in arg: {a!r}"
            safe_args.append(a)
        return await self._exec([command] + safe_args)

    # ── run_python (AST-hardened) ──────────────────────────────────────────────

    async def _run_python(self, args: dict[str, Any]) -> str:
        filename: str       = args.get("filename", "agent_script.py")
        code: str           = args.get("code", "")
        extra_args: list[str] = args.get("args", [])

        if not code.strip():
            return "[Error] No code provided."

        # AST safety check before writing or running
        violation = _ast_safe_check(code)
        if violation:
            logger.warning("SANDBOX BLOCKED: %s", violation)
            return violation

        # Write to workspace temp file
        script_path = self._resolve(filename)
        if script_path is None:
            return "[Error] Path escapes workspace."

        try:
            Path(script_path).write_text(code, encoding="utf-8")
        except OSError as exc:
            return f"[Error] Could not write {filename}: {exc}"

        # Execute with minimal environment
        env = {}
        if self._is_windows:
            env["SYSTEMROOT"] = os.environ.get("SYSTEMROOT", "C:\\Windows")
            env["TEMP"]       = os.environ.get("TEMP", "C:\\Windows\\Temp")

        try:
            proc = await asyncio.wait_for(
                asyncio.create_subprocess_exec(
                    sys.executable, script_path,
                    *[str(a) for a in extra_args],
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(self.workspace),
                    env=env,
                ),
                timeout=self.timeout,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=self.timeout)
            out = stdout.decode("utf-8", errors="replace")[:2000]
            err = stderr.decode("utf-8", errors="replace")[:500]
            if proc.returncode != 0:
                return f"Script error (exit {proc.returncode}):\n{err}\n{out}".strip()
            return f"Script: {filename}\n{out}" if out else f"Script: {filename}\n(no output)"
        except asyncio.TimeoutError:
            return f"[Error] Script timed out after {self.timeout}s"

    # ── write_file (hardened) ──────────────────────────────────────────────────

    async def _write_file(self, args: dict[str, Any]) -> str:
        filename: str = args.get("filename", "")
        content: str  = args.get("content", "")
        if not filename:
            return "[Error] No filename provided."
        path = self._resolve(filename)
        if path is None:
            return "[Error] Path escapes workspace."
        ext = Path(filename).suffix.lower()
        if ext not in ALLOWED_WRITE_EXTENSIONS:
            return f"[Error] Extension '{ext}' not allowed. Use: {', '.join(ALLOWED_WRITE_EXTENSIONS)}"
        content_bytes = content.encode("utf-8")
        if len(content_bytes) > MAX_FILE_SIZE:
            return f"[Error] Content size ({len(content_bytes)} bytes) exceeds 100KB limit."
        tmp = None
        try:
            fd, tmp = tempfile.mkstemp(dir=str(self.workspace), prefix=".tmp_write_")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(content)
            os.replace(tmp, path)
            return f"✅ Written: {filename} ({len(content)} chars)"
        except OSError as exc:
            return f"[Error] Write failed: {exc}"
        finally:
            if tmp and os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except Exception:
                    pass

    # ── read_file ──────────────────────────────────────────────────────────────

    async def _read_file(self, args: dict[str, Any]) -> str:
        filename: str = args.get("filename", "")
        path = self._resolve(filename)
        if path is None:
            return "[Error] Path escapes workspace."
        try:
            content = Path(path).read_text(encoding="utf-8", errors="replace")
            return f"=== {filename} ===\n{content}"
        except FileNotFoundError:
            return f"[Error] File not found: {filename}"
        except OSError as exc:
            return f"[Error] Read failed: {exc}"

    # ── list_files ─────────────────────────────────────────────────────────────

    async def _list_files(self, args: dict[str, Any]) -> str:
        subfolder = args.get("path", ".")
        base = self._resolve(subfolder)
        if base is None:
            return "[Error] Path escapes workspace."
        try:
            p = Path(base)
            if not p.exists():
                return f"[Error] Path not found: {subfolder}"
            entries = sorted(p.iterdir(), key=lambda x: (x.is_file(), x.name))
            lines   = []
            for entry in entries[:100]:
                prefix = "📄 " if entry.is_file() else "📁 "
                size   = f" ({entry.stat().st_size} bytes)" if entry.is_file() else ""
                lines.append(f"{prefix}{entry.name}{size}")
            header = f"=== {subfolder} ({len(lines)} items) ==="
            return header + "\n" + "\n".join(lines)
        except OSError as exc:
            return f"[Error] List failed: {exc}"

    # ── patch_file ─────────────────────────────────────────────────────────────

    async def _patch_file(self, args: dict[str, Any]) -> str:
        filename: str = args.get("filename", "")
        old: str      = args.get("old", "")
        new: str      = args.get("new", "")
        if not filename or not old:
            return "[Error] filename and old are required."
        path = self._resolve(filename)
        if path is None:
            return "[Error] Path escapes workspace."
        try:
            content = Path(path).read_text(encoding="utf-8")
            if old not in content:
                return f"[Error] Pattern not found in {filename}"
            patched = content.replace(old, new, 1)
            Path(path).write_text(patched, encoding="utf-8")
            return f"✅ Patched {filename}"
        except FileNotFoundError:
            return f"[Error] File not found: {filename}"
        except OSError as exc:
            return f"[Error] Patch failed: {exc}"

    # ── calculate (AST-safe) ───────────────────────────────────────────────────

    async def _calculate(self, args: dict[str, Any]) -> str:
        expression: str = args.get("expression", "").strip()
        if not expression:
            return "[Error] Empty expression."
        if len(expression) > 200:
            return "[Error] Expression too long (max 200 chars)."
        ALLOWED_NODES = (
            ast.Expression, ast.BinOp, ast.UnaryOp,
            ast.Constant, ast.Num,                        # Num for Python < 3.8
            ast.Add, ast.Sub, ast.Mult, ast.Div,
            ast.Pow, ast.Mod, ast.FloorDiv,
            ast.USub, ast.UAdd,
        )
        try:
            tree = ast.parse(expression, mode="eval")
            for node in ast.walk(tree):
                if not isinstance(node, ALLOWED_NODES):
                    return f"[Error] Disallowed operation in expression: {type(node).__name__}"
            result = eval(compile(tree, "<expr>", "eval"), {"__builtins__": {}}, {})
            return str(result)
        except SyntaxError as exc:
            return f"[Error] Syntax error: {exc}"
        except ZeroDivisionError:
            return "[Error] Division by zero."
        except OverflowError:
            return "[Error] Numeric overflow."
        except Exception as exc:
            return f"[Error] {type(exc).__name__}: {exc}"

    # ── web_search ─────────────────────────────────────────────────────────────

    async def _web_search(self, args: dict[str, Any]) -> str:
        from agent.tools.web_search import WebSearchTool
        query       = args.get("query", "")
        max_results = int(args.get("max_results", 5))
        if not query:
            return "[Error] No query provided."
        try:
            ws = WebSearchTool()
            return await ws.search(query, max_results=max_results)
        except Exception as exc:
            return f"[Error] Web search failed: {exc}"

    # ── spawn_agent ─────────────────────────────────────────────────────────────

    async def _spawn_agent(self, args: dict[str, Any]) -> str:
        if self._orchestrator is None or self._engine is None:
            return "[Error] Sub-agent orchestrator not initialized."
        from agent.subagents.orchestrator import handle_spawn_agent
        return await handle_spawn_agent(args, self._orchestrator, self._engine)

    # ── Helpers ─────────────────────────────────────────────────────────────────

    def _resolve(self, path: str) -> str | None:
        """Resolve a relative path inside workspace. Returns None if outside."""
        if not path:
            return None
        try:
            resolved = (self.workspace / path).resolve()
            if str(resolved).startswith(str(self.workspace)):
                return str(resolved)
            return None
        except Exception:
            return None

    async def _exec(self, cmd: list[str]) -> str:
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self.workspace),
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=self.timeout)
            out = stdout.decode("utf-8", errors="replace")[:3000]
            err = stderr.decode("utf-8", errors="replace")[:500]
            if proc.returncode != 0:
                return f"Exit {proc.returncode}:\n{err}\n{out}".strip()
            return out or "(no output)"
        except asyncio.TimeoutError:
            return f"[Error] Command timed out after {self.timeout}s"
