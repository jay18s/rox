"""
Security — input sanitization and prompt injection detection.
"""
from __future__ import annotations
import logging
import re

logger = logging.getLogger(__name__)


class SecurityViolation(Exception):
    pass


INJECTION_PATTERNS = [
    r"ignore\s+(previous|prior|above|all)\s+instructions",
    r"new\s+(system\s+)?prompt",
    r"you\s+are\s+now\s+\w+",
    r"disregard\s+(all\s+)?previous",
    r"act\s+as\s+(if\s+you\s+are|a\s+)",
    r"override\s+(your\s+)?(previous\s+)?(instructions|rules|guidelines)",
    r"jailbreak",
    r"dan\s+mode",
    r"developer\s+mode",
    r"forget\s+(everything|all|previous)",
    r"your\s+new\s+(role|instructions?)",
]

MAX_INPUT_LENGTH = 512


class InputSanitizer:
    def sanitize(self, text: str) -> str:
        if not text:
            return ""
        text = text.strip()
        if len(text) > MAX_INPUT_LENGTH:
            raise SecurityViolation(
                f"Input exceeds {MAX_INPUT_LENGTH} chars ({len(text)})"
            )
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                logger.critical("PROMPT_INJECTION_DETECTED pattern=%s input=%s", pattern, text[:50])
                raise SecurityViolation("Prompt injection pattern detected in input")
        if "{" in text and "}" in text and len(text) > 50:
            logger.warning("Input contains JSON-like structure (possible injection): %s", text[:50])
        return text


# Module-level singleton
_sanitizer: InputSanitizer | None = None


def get_sanitizer() -> InputSanitizer:
    global _sanitizer
    if _sanitizer is None:
        _sanitizer = InputSanitizer()
    return _sanitizer
