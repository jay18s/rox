"""
Memory Manager — layered storage for ZeroClaw agent.

Layers (mirrors what md-file frameworks call skills/sessions/heartbeat):

  Layer 1 — facts (SQLite key-value)
      Permanent user facts extracted from conversation.
      e.g. name, preferences, context.
      → Injected into EVERY system prompt.

  Layer 2 — conversation_summary (SQLite)
      A rolling LLM-generated summary of older turns that were trimmed.
      Rebuilt whenever the gateway triggers summarisation.
      → Injected into system prompt so trimmed history is never lost.

  Layer 3 — raw turns (in-memory deque, managed by gateway)
      The last N raw messages for natural conversation flow.
      → Sent as the actual message history to the LLM.

  Layer 4 — full conversation log (SQLite conversations table)
      Append-only audit log. Not sent to LLM directly.
      Used for summarisation and future RAG.
"""

from __future__ import annotations

import asyncio
import logging
import sqlite3
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ── DDL ───────────────────────────────────────────────────────────────────────

_CREATE_FACTS = """
CREATE TABLE IF NOT EXISTS facts (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id   TEXT    NOT NULL,
    key       TEXT    NOT NULL,
    value     TEXT    NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, key) ON CONFLICT REPLACE
);
"""

_CREATE_CONVERSATIONS = """
CREATE TABLE IF NOT EXISTS conversations (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id   TEXT    NOT NULL,
    role      TEXT    NOT NULL,
    content   TEXT    NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);
"""

# One rolling summary per (user_id, channel) — updated in-place
_CREATE_SUMMARIES = """
CREATE TABLE IF NOT EXISTS conversation_summaries (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      TEXT    NOT NULL,
    channel      TEXT    NOT NULL DEFAULT 'default',
    summary      TEXT    NOT NULL,
    turn_count   INTEGER NOT NULL DEFAULT 0,
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, channel) ON CONFLICT REPLACE
);
"""


class MemoryManager:
    """Manages all persistence layers for the agent."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.db_path = Path(config.get("db_path", "memory.db"))
        self.store_conversations: bool = config.get("store_conversations", True)
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()
        
        # Vector store for RAG (lazy-loaded)
        self._vector_store = None
        self._vector_config = config.get("vector", {})

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    def setup(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL;")
        self._conn.execute(_CREATE_FACTS)
        self._conn.execute(_CREATE_CONVERSATIONS)
        self._conn.execute(_CREATE_SUMMARIES)
        self._conn.commit()
        logger.info("Memory DB ready at: %s", self.db_path)
        
        # Initialize vector store if enabled
        if self._vector_config.get("enabled", False):
            try:
                from agent.memory.vector_store import VectorMemoryStore
                self._vector_store = VectorMemoryStore(
                    {"vector": self._vector_config}, 
                    self.db_path
                )
                self._vector_store.setup(self._conn)
                logger.info("Vector RAG enabled")
            except ImportError as e:
                logger.warning("Vector store not available: %s", e)

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def health_check(self) -> bool:
        try:
            assert self._conn is not None
            self._conn.execute("SELECT 1;")
            return True
        except Exception:
            return False

    # ── Layer 1: Facts (permanent key-value) ──────────────────────────────────

    async def store_fact(self, user_id: str, key: str, value: str) -> None:
        async with self._lock:
            await asyncio.get_event_loop().run_in_executor(
                None, self._store_fact_sync, user_id, key, value
            )

    def _store_fact_sync(self, user_id: str, key: str, value: str) -> None:
        assert self._conn
        self._conn.execute(
            "INSERT OR REPLACE INTO facts(user_id, key, value) VALUES (?, ?, ?)",
            (user_id, key, value),
        )
        self._conn.commit()
        logger.debug("Stored fact [%s] %s=%s", user_id, key, value)

    async def get_fact(self, user_id: str, key: str) -> str | None:
        async with self._lock:
            return await asyncio.get_event_loop().run_in_executor(
                None, self._get_fact_sync, user_id, key
            )

    def _get_fact_sync(self, user_id: str, key: str) -> str | None:
        assert self._conn
        row = self._conn.execute(
            "SELECT value FROM facts WHERE user_id=? AND key=?", (user_id, key)
        ).fetchone()
        return row["value"] if row else None

    async def get_all_facts(self, user_id: str) -> dict[str, str]:
        async with self._lock:
            return await asyncio.get_event_loop().run_in_executor(
                None, self._get_all_facts_sync, user_id
            )

    def _get_all_facts_sync(self, user_id: str) -> dict[str, str]:
        assert self._conn
        rows = self._conn.execute(
            "SELECT key, value FROM facts WHERE user_id=?", (user_id,)
        ).fetchall()
        return {r["key"]: r["value"] for r in rows}

    # ── Layer 2: Conversation Summary (rolling digest) ─────────────────────────

    async def get_summary(self, user_id: str, channel: str = "default") -> str | None:
        """Return the current rolling summary for this user+channel, or None."""
        async with self._lock:
            return await asyncio.get_event_loop().run_in_executor(
                None, self._get_summary_sync, user_id, channel
            )

    def _get_summary_sync(self, user_id: str, channel: str) -> str | None:
        assert self._conn
        row = self._conn.execute(
            "SELECT summary FROM conversation_summaries WHERE user_id=? AND channel=?",
            (user_id, channel),
        ).fetchone()
        return row["summary"] if row else None

    async def store_summary(
        self, user_id: str, channel: str, summary: str, turn_count: int
    ) -> None:
        """Upsert a new rolling summary."""
        async with self._lock:
            await asyncio.get_event_loop().run_in_executor(
                None, self._store_summary_sync, user_id, channel, summary, turn_count
            )

    def _store_summary_sync(
        self, user_id: str, channel: str, summary: str, turn_count: int
    ) -> None:
        assert self._conn
        self._conn.execute(
            """
            INSERT OR REPLACE INTO conversation_summaries
                (user_id, channel, summary, turn_count, last_updated)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            """,
            (user_id, channel, summary, turn_count),
        )
        self._conn.commit()
        logger.info("Summary updated for %s/%s (%d total turns)", user_id, channel, turn_count)

    # ── Layer 3: Full conversation log (audit / RAG source) ───────────────────

    async def store_conversation(self, user_id: str, role: str, content: str) -> int:
        """
        Store a conversation turn and return the row ID.
        If vector store is enabled, also embed the content.
        """
        if not self.store_conversations:
            return -1
        
        async with self._lock:
            conv_id = await asyncio.get_event_loop().run_in_executor(
                None, self._store_conv_sync, user_id, role, content
            )
        
        # Store embedding for RAG if vector store is enabled
        if self._vector_store and conv_id > 0:
            try:
                await self._vector_store.store_embedding(
                    conv_id, user_id, role, content
                )
            except Exception as e:
                logger.warning("Failed to store embedding: %s", e)
        
        return conv_id

    def _store_conv_sync(self, user_id: str, role: str, content: str) -> int:
        assert self._conn
        cursor = self._conn.execute(
            "INSERT INTO conversations(user_id, role, content) VALUES (?, ?, ?)",
            (user_id, role, content),
        )
        self._conn.commit()
        return cursor.lastrowid or -1

    async def get_recent_conversations(
        self, user_id: str, limit: int = 20
    ) -> list[dict[str, str]]:
        """Fetch recent conversation rows (used for building summaries)."""
        async with self._lock:
            return await asyncio.get_event_loop().run_in_executor(
                None, self._get_recent_conv_sync, user_id, limit
            )

    def _get_recent_conv_sync(self, user_id: str, limit: int) -> list[dict[str, str]]:
        assert self._conn
        rows = self._conn.execute(
            """
            SELECT role, content FROM conversations
            WHERE user_id=?
            ORDER BY timestamp DESC
            LIMIT ?
            """,
            (user_id, limit),
        ).fetchall()
        return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]

    async def get_conversation_turn_count(self, user_id: str) -> int:
        """Total number of stored conversation rows for this user."""
        async with self._lock:
            return await asyncio.get_event_loop().run_in_executor(
                None, self._get_turn_count_sync, user_id
            )

    def _get_turn_count_sync(self, user_id: str) -> int:
        assert self._conn
        row = self._conn.execute(
            "SELECT COUNT(*) as cnt FROM conversations WHERE user_id=?", (user_id,)
        ).fetchone()
        return row["cnt"] if row else 0

    # ── Layer 5: Vector RAG (semantic search over conversations) ────────────────

    async def get_rag_context(
        self, 
        user_id: str, 
        query: str, 
        max_results: int = 5
    ) -> str:
        """
        Get relevant past context using semantic search.
        Returns formatted string for injection into system prompt.
        """
        if not self._vector_store:
            return ""
        
        try:
            return await self._vector_store.get_context_for_query(
                user_id, query, max_results
            )
        except Exception as e:
            logger.warning("RAG context retrieval failed: %s", e)
            return ""

    async def search_similar_conversations(
        self, 
        user_id: str, 
        query: str, 
        limit: int = 5
    ) -> list[dict[str, Any]]:
        """
        Search for semantically similar past conversation turns.
        Returns list of {role, content, similarity, timestamp} dicts.
        """
        if not self._vector_store:
            return []
        
        try:
            return await self._vector_store.search_similar(user_id, query, limit)
        except Exception as e:
            logger.warning("Vector search failed: %s", e)
            return []
