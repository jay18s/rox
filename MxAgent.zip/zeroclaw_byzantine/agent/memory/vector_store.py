"""
Vector Memory Store — semantic search over conversation history.

Uses sqlite-vec for vector storage (no external dependencies).
Provides RAG (Retrieval Augmented Generation) capabilities by:
  1. Embedding each conversation turn when stored
  2. Retrieving semantically similar past turns for context

Requirements:
  - sqlite-vec: pip install sqlite-vec
  - Optional: sentence-transformers for local embeddings
  - Or: OpenAI embeddings API

Config (config.toml):
  [agent.memory.vector]
  enabled = true
  provider = "local"  # "local" (sentence-transformers) or "openai"
  model = "all-MiniLM-L6-v2"  # for local
  dimensions = 384
"""

from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ── DDL for vector storage ─────────────────────────────────────────────────────

_CREATE_EMBEDDINGS = """
CREATE TABLE IF NOT EXISTS conversation_embeddings (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    conv_id      INTEGER NOT NULL,
    user_id      TEXT    NOT NULL,
    role         TEXT    NOT NULL,
    content      TEXT    NOT NULL,
    embedding    BLOB    NOT NULL,
    timestamp    DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conv_id) REFERENCES conversations(id)
);
"""

_CREATE_VECTOR_INDEX = """
CREATE INDEX IF NOT EXISTS idx_embeddings_user 
ON conversation_embeddings(user_id);
"""


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors."""
    import math
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


class EmbeddingProvider:
    """Base class for embedding providers."""
    
    def __init__(self, config: dict[str, Any]):
        self.config = config
        self.dimensions = config.get("dimensions", 384)
    
    async def embed(self, text: str) -> list[float]:
        """Generate embedding for text."""
        raise NotImplementedError


class LocalEmbeddingProvider(EmbeddingProvider):
    """
    Local embedding using sentence-transformers.
    Falls back to a simple TF-IDF like approach if not available.
    """
    
    def __init__(self, config: dict[str, Any]):
        super().__init__(config)
        self.model_name = config.get("model", "all-MiniLM-L6-v2")
        self._model = None
        self._dimension_cache: dict[str, list[float]] = {}
    
    def _get_model(self):
        """Lazy-load the sentence-transformers model."""
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer
                self._model = SentenceTransformer(self.model_name)
                self.dimensions = self._model.get_sentence_embedding_dimension()
                logger.info("Loaded embedding model: %s (dim=%d)", self.model_name, self.dimensions)
            except ImportError:
                logger.warning(
                    "sentence-transformers not installed. "
                    "Using simple hash-based embeddings (not semantic). "
                    "Run: pip install sentence-transformers"
                )
                self._model = "fallback"
        return self._model
    
    async def embed(self, text: str) -> list[float]:
        """Generate embedding for text."""
        model = self._get_model()
        
        if model == "fallback":
            # Simple fallback: hash-based pseudo-embedding
            return self._fallback_embed(text)
        
        # Use sentence-transformers
        loop = asyncio.get_event_loop()
        embedding = await loop.run_in_executor(
            None, 
            lambda: model.encode(text, convert_to_numpy=True).tolist()
        )
        return embedding
    
    def _fallback_embed(self, text: str) -> list[float]:
        """
        Simple hash-based embedding for when sentence-transformers isn't available.
        NOT semantic, but provides consistent vectors for testing.
        """
        import hashlib
        
        # Create a deterministic embedding from text hash
        text_hash = hashlib.sha256(text.encode()).hexdigest()
        
        # Convert hash to vector (pad/truncate to dimensions)
        values = []
        for i in range(0, min(len(text_hash), self.dimensions * 2), 2):
            val = int(text_hash[i:i+2], 16) / 255.0 - 0.5
            values.append(val)
        
        # Pad to dimensions
        while len(values) < self.dimensions:
            values.append(0.0)
        
        return values[:self.dimensions]


class OpenAIEmbeddingProvider(EmbeddingProvider):
    """OpenAI embeddings API provider."""
    
    def __init__(self, config: dict[str, Any]):
        super().__init__(config)
        self.model = config.get("model", "text-embedding-3-small")
        self.dimensions = config.get("dimensions", 1536)
        self._client = None
    
    def _get_client(self):
        """Lazy-load OpenAI client."""
        if self._client is None:
            import os
            from openai import OpenAI
            api_key = os.environ.get("OPENAI_API_KEY")
            if not api_key:
                raise ValueError("OPENAI_API_KEY not set")
            self._client = OpenAI(api_key=api_key)
        return self._client
    
    async def embed(self, text: str) -> list[float]:
        """Generate embedding using OpenAI API."""
        client = self._get_client()
        
        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(
            None,
            lambda: client.embeddings.create(
                model=self.model,
                input=text[:8000],  # OpenAI token limit
            )
        )
        return response.data[0].embedding


class VectorMemoryStore:
    """
    Vector-based memory store for semantic search over conversations.
    """
    
    def __init__(self, config: dict[str, Any], db_path: Path):
        self.enabled = config.get("vector", {}).get("enabled", False)
        self.db_path = db_path
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()
        
        # Embedding provider
        provider = config.get("vector", {}).get("provider", "local")
        if provider == "openai":
            self.embedder = OpenAIEmbeddingProvider(config.get("vector", {}))
        else:
            self.embedder = LocalEmbeddingProvider(config.get("vector", {}))
        
        self.dimensions = self.embedder.dimensions
    
    def setup(self, conn: sqlite3.Connection) -> None:
        """Initialize vector tables in existing connection."""
        if not self.enabled:
            logger.info("Vector memory disabled.")
            return
        
        self._conn = conn
        self._conn.execute(_CREATE_EMBEDDINGS)
        self._conn.execute(_CREATE_VECTOR_INDEX)
        self._conn.commit()
        logger.info("Vector memory store initialized (dim=%d)", self.dimensions)
    
    async def store_embedding(
        self, 
        conv_id: int, 
        user_id: str, 
        role: str, 
        content: str
    ) -> None:
        """Store embedding for a conversation turn."""
        if not self.enabled or not self._conn:
            return
        
        try:
            embedding = await self.embedder.embed(content)
            
            async with self._lock:
                await asyncio.get_event_loop().run_in_executor(
                    None,
                    self._store_embedding_sync,
                    conv_id, user_id, role, content, embedding
                )
        except Exception as e:
            logger.warning("Failed to store embedding: %s", e)
    
    def _store_embedding_sync(
        self, 
        conv_id: int, 
        user_id: str, 
        role: str, 
        content: str, 
        embedding: list[float]
    ) -> None:
        """Synchronous embedding storage."""
        assert self._conn
        import struct
        
        # Convert embedding to binary blob
        blob = struct.pack(f'{len(embedding)}f', *embedding)
        
        self._conn.execute(
            """INSERT INTO conversation_embeddings 
               (conv_id, user_id, role, content, embedding)
               VALUES (?, ?, ?, ?, ?)""",
            (conv_id, user_id, role, content, blob)
        )
        self._conn.commit()
    
    async def search_similar(
        self, 
        user_id: str, 
        query: str, 
        limit: int = 5,
        threshold: float = 0.5
    ) -> list[dict[str, Any]]:
        """
        Search for semantically similar past conversation turns.
        
        Returns list of {role, content, similarity, timestamp} dicts.
        """
        if not self.enabled or not self._conn:
            return []
        
        try:
            query_embedding = await self.embedder.embed(query)
            
            async with self._lock:
                return await asyncio.get_event_loop().run_in_executor(
                    None,
                    self._search_similar_sync,
                    user_id, query_embedding, limit, threshold
                )
        except Exception as e:
            logger.warning("Vector search failed: %s", e)
            return []
    
    def _search_similar_sync(
        self, 
        user_id: str, 
        query_embedding: list[float],
        limit: int,
        threshold: float
    ) -> list[dict[str, Any]]:
        """Synchronous similarity search."""
        assert self._conn
        import struct
        
        # Fetch all embeddings for this user
        rows = self._conn.execute(
            """SELECT id, role, content, embedding, timestamp 
               FROM conversation_embeddings 
               WHERE user_id = ?
               ORDER BY timestamp DESC
               LIMIT 100""",
            (user_id,)
        ).fetchall()
        
        results = []
        for row in rows:
            # Deserialize embedding
            embedding = list(struct.unpack(f'{self.dimensions}f', row["embedding"]))
            
            # Compute similarity
            similarity = _cosine_similarity(query_embedding, embedding)
            
            if similarity >= threshold:
                results.append({
                    "role": row["role"],
                    "content": row["content"],
                    "similarity": similarity,
                    "timestamp": row["timestamp"],
                })
        
        # Sort by similarity and return top results
        results.sort(key=lambda x: x["similarity"], reverse=True)
        return results[:limit]
    
    async def get_context_for_query(
        self, 
        user_id: str, 
        query: str,
        max_results: int = 5
    ) -> str:
        """
        Get relevant context for a query as a formatted string.
        Used for RAG injection into system prompt.
        """
        if not self.enabled:
            return ""
        
        similar = await self.search_similar(user_id, query, limit=max_results)
        
        if not similar:
            return ""
        
        lines = ["## RELEVANT PAST CONTEXT (semantic search)"]
        for item in similar:
            role = "User" if item["role"] == "user" else "Assistant"
            lines.append(f"**{role}** (similarity: {item['similarity']:.2f}):")
            lines.append(f"  {item['content'][:200]}...")
        
        return "\n".join(lines)
