"""
Message Gateway — per-session lane serialization + input sanitization.

Adds to ZeroClaw original:
  - InputSanitizer applied before every message hits the engine
  - HITL commands: /approve, /reject, /pending routed to Byzantine engine
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections import deque
from typing import Any

from agent.channels.base import BaseChannel
from agent.engine import CoreEngine
from agent.security import get_sanitizer, SecurityViolation

logger = logging.getLogger(__name__)


class SessionLane:
    def __init__(self, session_key: str, max_history: int) -> None:
        self.session_key = session_key
        self.history: deque = deque(maxlen=max_history)
        self.queue: asyncio.Queue = asyncio.Queue()
        self._task: asyncio.Task | None = None
        self.last_active = time.monotonic()

    def start(self, handler) -> None:
        self._task = asyncio.create_task(
            self._run(handler), name=f"lane-{self.session_key}"
        )

    async def _run(self, handler) -> None:
        while True:
            try:
                item = await asyncio.wait_for(self.queue.get(), timeout=300)
                self.last_active = time.monotonic()
                await handler(item, self)
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error("Lane %s error: %s", self.session_key, exc)

    def cancel(self) -> None:
        if self._task:
            self._task.cancel()


class MessageGateway:
    """Routes messages through per-session lanes with LLM concurrency cap."""

    def __init__(
        self,
        queue: asyncio.Queue,
        engine: CoreEngine,
        channels: dict[str, BaseChannel],
        config: dict[str, Any],
    ) -> None:
        self.queue    = queue
        self.engine   = engine
        self.channels = channels

        self.max_history: int       = int(config.get("session_max_length", 40))
        self.max_history_turns: int = int(config.get("max_history_turns", 6))
        self.min_gap: float         = float(config.get("min_reply_gap_seconds", 1.0))
        concurrency: int            = int(config.get("llm_concurrency", 1))

        self._llm_sem = asyncio.Semaphore(concurrency)
        self._lanes: dict[str, SessionLane] = {}
        self._running = False
        self._sanitizer = get_sanitizer()

        logger.info(
            "Gateway: max_history=%d sent_turns=%d concurrency=%d gap=%.1fs",
            self.max_history, self.max_history_turns, concurrency, self.min_gap,
        )

    async def run(self) -> None:
        self._running = True
        logger.info("Message gateway running.")
        while self._running:
            try:
                msg: dict[str, Any] = await asyncio.wait_for(self.queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            lane = self._get_or_create_lane(msg["channel"], msg["user_id"])
            await lane.queue.put(msg)

    def _get_or_create_lane(self, channel: str, user_id: str) -> SessionLane:
        key = f"{channel}:{user_id}"
        if key not in self._lanes:
            lane = SessionLane(key, self.max_history * 2)
            lane.start(self._process_in_lane)
            self._lanes[key] = lane
            logger.info("New session lane: %s", key)
        return self._lanes[key]

    async def _process_in_lane(self, msg: dict[str, Any], lane: SessionLane) -> None:
        channel_name = msg["channel"]
        user_id      = msg["user_id"]
        chat_id      = msg.get("chat_id", user_id)
        text         = msg["text"]
        thread_id    = f"{channel_name}:{user_id}"

        # ── HITL commands ──────────────────────────────────────────────────
        hitl_response = await self._handle_hitl_command(text, thread_id)
        if hitl_response is not None:
            ch = self.channels.get(channel_name)
            if ch:
                await ch.send_message(hitl_response, user_id=user_id, chat_id=chat_id)
            return

        # ── Input sanitization ─────────────────────────────────────────────
        try:
            sanitized_text = self._sanitizer.sanitize(text)
        except SecurityViolation as exc:
            logger.warning("Security violation from %s: %s", user_id, exc)
            ch = self.channels.get(channel_name)
            if ch:
                await ch.send_message(
                    f"⚠️ Input rejected: {exc}\nPlease rephrase your request.",
                    user_id=user_id, chat_id=chat_id,
                )
            return

        logger.info("[%s/%s] → %r", channel_name, user_id, sanitized_text[:80])

        msg = dict(msg)
        msg["text"] = sanitized_text
        lane.history.append({"role": "user", "content": sanitized_text})
        history_snap = self._trim(list(lane.history))

        gap = time.monotonic() - lane.last_active
        if gap < self.min_gap:
            await asyncio.sleep(self.min_gap - gap)

        async with self._llm_sem:
            try:
                response = await self.engine.process(
                    message=msg,
                    session_history=history_snap,
                    user_id=user_id,
                    channel=channel_name,
                )
            except Exception as exc:
                logger.exception("Engine error %s/%s: %s", channel_name, user_id, exc)
                response = "Sorry, an internal error occurred. Please try again."

        lane.history.append({"role": "assistant", "content": response})

        ch = self.channels.get(channel_name)
        if ch:
            await ch.send_message(response, user_id=user_id, chat_id=chat_id)
        else:
            logger.error("No channel handler: %s", channel_name)

    async def _handle_hitl_command(self, text: str, thread_id: str) -> str | None:
        """Handle /approve /reject /pending HITL commands. Returns response or None."""
        t = text.strip()
        byzantine = self.engine.byzantine
        if byzantine is None:
            return None

        if t.startswith("/approve"):
            parts = t.split(maxsplit=1)
            tid   = parts[1].strip() if len(parts) > 1 else thread_id
            try:
                result = await byzantine.resume(tid, approved=True)
                if result.approved:
                    return f"✅ Action approved and executed.\nResult: {result.execution_result}"
                return f"⚠️ Execution failed: {result.escalation_reason}"
            except Exception as exc:
                return f"❌ Approval error: {exc}"

        if t.startswith("/reject"):
            parts = t.split(maxsplit=2)
            tid   = parts[1].strip() if len(parts) > 1 else thread_id
            note  = parts[2].strip() if len(parts) > 2 else "User rejected"
            try:
                await byzantine.resume(tid, approved=False, note=note)
                return f"🚫 Action rejected: {note}"
            except Exception as exc:
                return f"❌ Rejection error: {exc}"

        if t.startswith("/pending"):
            parts = t.split(maxsplit=1)
            tid   = parts[1].strip() if len(parts) > 1 else thread_id
            try:
                pending = await byzantine.get_pending(tid)
                if "error" in pending:
                    return f"No pending action for {tid}"
                wa = pending.get("winning_action", {})
                votes = pending.get("all_votes", [])
                votes_str = "\n".join(
                    f"  {v.get('agent_id','?'):6} → {v.get('proposed_action','?'):15} "
                    f"conf={v.get('confidence',0)}% risk={v.get('risk_level','?')}"
                    for v in votes[-3:]
                )
                return (
                    f"⏸ Pending action for {tid}:\n"
                    f"Tool: {wa.get('proposed_action', '?')}\n"
                    f"Params: {wa.get('action_params', {})}\n\n"
                    f"Votes:\n{votes_str}\n\n"
                    f"Use /approve {tid} or /reject {tid} <reason>"
                )
            except Exception as exc:
                return f"❌ Error fetching pending: {exc}"

        return None

    def _trim(self, history: list[dict]) -> list[dict]:
        n       = self.max_history_turns
        trimmed = history[-n:] if len(history) > n else history
        chars   = sum(len(m["content"]) for m in trimmed)
        logger.debug("Context: %d/%d turns (%d chars)", len(trimmed), len(history), chars)
        return trimmed

    def stop(self) -> None:
        self._running = False
        for lane in self._lanes.values():
            lane.cancel()
