"""
Hook system — lightweight event bus mirroring OpenClaw's lifecycle hooks.

Hooks fire at key points in the agent loop:
  before_tool_call   — can inspect / block a tool call
  after_tool_call    — sees result, can log or transform
  agent_end          — fires after final answer is produced
  before_compaction  — fires before summary rebuild
  session_start      — fires when a new session key is first seen
  memory_flush       — fires before compaction to save important info

Usage:
    hooks = HookBus()

    @hooks.on("after_tool_call")
    async def log_tool(ctx):
        print(ctx["tool"], ctx["result"][:80])

    await hooks.fire("after_tool_call", {"tool": "run_python", "result": "..."})
"""

from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

Handler = Callable[[dict[str, Any]], Awaitable[None]]

VALID_HOOKS = {
    "before_tool_call",
    "after_tool_call",
    "agent_end",
    "before_compaction",
    "after_compaction",
    "memory_flush",
    "session_start",
}


class HookBus:
    """Simple async event bus for agent lifecycle hooks."""

    def __init__(self) -> None:
        self._handlers: dict[str, list[Handler]] = defaultdict(list)

    def on(self, event: str) -> Callable:
        """Decorator to register a hook handler."""
        def decorator(fn: Handler) -> Handler:
            self.register(event, fn)
            return fn
        return decorator

    def register(self, event: str, handler: Handler) -> None:
        if event not in VALID_HOOKS:
            logger.warning("Unknown hook event: %r (valid: %s)", event, VALID_HOOKS)
        self._handlers[event].append(handler)
        logger.debug("Hook registered: %s → %s", event, handler.__name__)

    async def fire(self, event: str, ctx: dict[str, Any]) -> None:
        """Fire all handlers for an event. Errors are logged but don't crash the loop."""
        handlers = self._handlers.get(event, [])
        for handler in handlers:
            try:
                await handler(ctx)
            except Exception as exc:
                logger.error("Hook error [%s / %s]: %s", event, handler.__name__, exc)


# ── Global hook bus (shared across the app) ───────────────────────────────────
bus = HookBus()
