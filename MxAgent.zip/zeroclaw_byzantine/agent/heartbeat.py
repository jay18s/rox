"""
Heartbeat Scheduler — proactive agent pulse mirroring OpenClaw's cron/heartbeat.

Runs a lightweight "tick" every N minutes. On each tick the agent can:
  - Check for pending tasks stored in MEMORY.md
  - Run scheduled scripts in workspace/cron/
  - Push a proactive message to a user via Telegram

Config (config.toml):
  [agent.heartbeat]
  enabled        = true
  interval_minutes = 30
  notify_user_id   = ""      # telegram user_id to push proactive messages to
  notify_channel   = "telegram"
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class HeartbeatScheduler:
    """Runs periodic agent ticks for proactive behaviour."""

    def __init__(
        self,
        config: dict[str, Any],
        engine: Any,            # CoreEngine — avoid circular import
        channels: dict[str, Any],
    ) -> None:
        hb_cfg = config.get("agent", {}).get("heartbeat", {})
        self.enabled           = hb_cfg.get("enabled", False)
        self.interval_seconds  = int(hb_cfg.get("interval_minutes", 30)) * 60
        self.notify_user_id    = str(hb_cfg.get("notify_user_id", ""))
        self.notify_channel    = hb_cfg.get("notify_channel", "telegram")
        self.engine    = engine
        self.channels  = channels
        self._running  = False
        # Track last run times for daily/weekly scripts (to run once per period)
        self._last_daily_run: str | None = None   # "YYYY-MM-DD" of last daily run
        self._last_weekly_run: dict[str, str] = {}  # weekday -> "YYYY-MM-DD"

    async def run(self) -> None:
        if not self.enabled:
            logger.info("Heartbeat disabled (set agent.heartbeat.enabled=true to enable).")
            return

        logger.info(
            "Heartbeat started — tick every %dm, notify=%s/%s",
            self.interval_seconds // 60,
            self.notify_channel, self.notify_user_id or "none",
        )
        self._running = True
        while self._running:
            await asyncio.sleep(self.interval_seconds)
            if not self._running:
                break
            await self._tick()

    async def _tick(self) -> None:
        """One heartbeat cycle."""
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        logger.info("Heartbeat tick at %s", now)

        # Run any scripts in workspace/cron/ that are named for the current time
        await self._run_cron_scripts()

        # If a notify user is configured, send a proactive check
        if self.notify_user_id:
            await self._proactive_check()

    async def _run_cron_scripts(self) -> None:
        """
        Execute any .py files in workspace/cron/ whose filename matches
        the current day/hour, e.g. daily.py, monday.py, 09:00.py
        
        Scripts named 'daily.py' run once per day (on first tick after midnight).
        Scripts named after weekdays (e.g. 'monday.py') run once on that day.
        Scripts named after hours (e.g. '09:00.py') run during that hour.
        Scripts named after dates (e.g. '2026-02-19.py') run on that date.
        """
        from agent.tools.executor import ToolExecutor
        workspace = Path(
            self.engine.tool_executor.workspace if hasattr(self.engine, "tool_executor")
            else "workspace"
        )
        cron_dir = workspace / "cron"
        if not cron_dir.exists():
            return

        now = datetime.now()
        today_str = now.strftime("%Y-%m-%d")
        current_hour = now.strftime("%H:00")
        weekday = now.strftime("%A").lower()  # "monday", "tuesday" ...
        
        for script in cron_dir.glob("*.py"):
            stem = script.stem.lower()
            should_run = False
            
            # Daily scripts: run once per day
            if stem == "daily":
                if self._last_daily_run != today_str:
                    should_run = True
                    self._last_daily_run = today_str
                    logger.info("Heartbeat: triggering daily script %s", script.name)
            
            # Weekday scripts: run once per weekday occurrence
            elif stem in ("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"):
                if stem == weekday:
                    if self._last_weekly_run.get(stem) != today_str:
                        should_run = True
                        self._last_weekly_run[stem] = today_str
                        logger.info("Heartbeat: triggering weekly script %s", script.name)
            
            # Hour scripts: run during that hour
            elif stem == current_hour:
                should_run = True
                logger.info("Heartbeat: triggering hourly script %s", script.name)
            
            # Date-specific scripts: run on that date
            elif stem == today_str:
                should_run = True
                logger.info("Heartbeat: triggering date-specific script %s", script.name)
            
            if should_run:
                try:
                    result = await self.engine.tool_executor.execute({
                        "tool": "run_python",
                        "args": {"filename": f"cron/{script.name}", "code": script.read_text()}
                    })
                    logger.info("Cron %s result: %s", script.name, result[:200])
                except Exception as exc:
                    logger.error("Cron script %s failed: %s", script.name, exc)

    async def _proactive_check(self) -> None:
        """Ask the agent if there's anything proactive to do, push result if non-trivial."""
        prompt = (
            "This is your scheduled heartbeat check. "
            "Review your MEMORY.md and today's log. "
            "Is there anything pending, overdue, or worth flagging to the user right now? "
            "If yes, reply with a short message to send them. "
            "If nothing is pending, reply with exactly: NOTHING_TO_DO"
        )
        try:
            from collections import deque
            response = await self.engine.process(
                message={"text": prompt},
                session_history=[],
                user_id="heartbeat",
                channel="system",
            )
            if response and "NOTHING_TO_DO" not in response:
                channel = self.channels.get(self.notify_channel)
                if channel:
                    await channel.send_message(
                        f"🔔 *Heartbeat check*\n{response}",
                        user_id=self.notify_user_id,
                        chat_id=self.notify_user_id,
                    )
                    logger.info("Heartbeat pushed proactive message to %s", self.notify_user_id)
        except Exception as exc:
            logger.error("Heartbeat proactive check failed: %s", exc)

    def stop(self) -> None:
        self._running = False
