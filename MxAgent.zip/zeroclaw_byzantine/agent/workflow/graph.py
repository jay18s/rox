"""
LangGraph-style Workflow Graph Engine.

Provides:
- Node-based workflow execution
- Conditional routing between nodes
- Cycle detection and handling
- State management across nodes
- Tracing integration
"""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Awaitable

from agent.workflow.state import WorkflowState

logger = logging.getLogger(__name__)


class NodeStatus(Enum):
    """Status of a node execution."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class NodeResult:
    """Result from node execution."""
    status: NodeStatus
    next_node: str | None = None
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class Node(ABC):
    """
    Abstract base class for workflow nodes.
    
    Each node represents a step in the workflow and can:
    - Read/write to the shared state
    - Decide which node to route to next
    - Report status and errors
    """
    
    def __init__(self, name: str):
        self.name = name
        self._status = NodeStatus.PENDING
        self._execution_count = 0
    
    @property
    def status(self) -> NodeStatus:
        return self._status
    
    @abstractmethod
    async def execute(self, state: WorkflowState) -> NodeResult:
        """
        Execute the node's logic.
        
        Args:
            state: Current workflow state
            
        Returns:
            NodeResult with status and optional next node
        """
        ...
    
    async def __call__(self, state: WorkflowState) -> NodeResult:
        """Execute node with logging and error handling."""
        self._execution_count += 1
        self._status = NodeStatus.RUNNING
        state.visit_node(self.name)
        
        logger.info("[NODE] %s: executing (attempt #%d)", self.name, self._execution_count)
        
        try:
            result = await self.execute(state)
            self._status = result.status
            logger.info("[NODE] %s: %s → %s", self.name, result.status.value, result.next_node or "END")
            return result
        except Exception as e:
            self._status = NodeStatus.FAILED
            logger.error("[NODE] %s: failed - %s", self.name, e)
            state.add_error(str(e), node=self.name)
            return NodeResult(
                status=NodeStatus.FAILED,
                error=str(e),
            )


class Edge:
    """
    Edge in the workflow graph.
    
    Edges can be:
    - Direct: always routes to target node
    - Conditional: routes based on a condition function
    """
    
    def __init__(
        self,
        source: str,
        target: str,
        condition: Callable[[WorkflowState], bool] | None = None,
        label: str = "",
    ):
        self.source = source
        self.target = target
        self.condition = condition
        self.label = label or f"{source}→{target}"
    
    def should_take(self, state: WorkflowState) -> bool:
        """Check if this edge should be taken."""
        if self.condition is None:
            return True
        return self.condition(state)


class ConditionalEdge(Edge):
    """Edge with conditional routing."""
    
    def __init__(
        self,
        source: str,
        condition: Callable[[WorkflowState], str],
        routes: dict[str, str],
    ):
        """
        Args:
            source: Source node name
            condition: Function that returns the route key
            routes: Dict mapping route keys to target node names
        """
        super().__init__(source, "")
        self.condition_func = condition
        self.routes = routes
    
    def get_target(self, state: WorkflowState) -> str | None:
        """Get the target node based on condition."""
        route_key = self.condition_func(state)
        return self.routes.get(route_key)


class WorkflowGraph:
    """
    LangGraph-style workflow graph.
    
    Manages nodes and edges, handles execution flow,
    and tracks state throughout the workflow.
    """
    
    def __init__(self, name: str = "workflow"):
        self.name = name
        self.nodes: dict[str, Node] = {}
        self.edges: list[Edge] = []
        self.conditional_edges: list[ConditionalEdge] = []
        self.entry_point: str | None = None
        self.finish_nodes: set[str] = set()
        
        # Tracer integration
        self._tracer: Any = None
        
        # Max iterations to prevent infinite loops
        self.max_iterations = 50
    
    def add_node(self, node: Node) -> "WorkflowGraph":
        """Add a node to the graph."""
        self.nodes[node.name] = node
        logger.debug("[GRAPH] Added node: %s", node.name)
        return self
    
    def add_edge(
        self,
        source: str,
        target: str,
        condition: Callable[[WorkflowState], bool] | None = None,
    ) -> "WorkflowGraph":
        """Add an edge between nodes."""
        if source not in self.nodes:
            raise ValueError(f"Source node '{source}' not found")
        if target not in self.nodes and target != "END":
            raise ValueError(f"Target node '{target}' not found")
        
        edge = Edge(source, target, condition)
        self.edges.append(edge)
        logger.debug("[GRAPH] Added edge: %s → %s", source, target)
        return self
    
    def add_conditional_edges(
        self,
        source: str,
        condition: Callable[[WorkflowState], str],
        routes: dict[str, str],
    ) -> "WorkflowGraph":
        """Add conditional routing from a node."""
        if source not in self.nodes:
            raise ValueError(f"Source node '{source}' not found")
        
        for route_key, target in routes.items():
            if target not in self.nodes and target != "END":
                raise ValueError(f"Target node '{target}' for route '{route_key}' not found")
        
        edge = ConditionalEdge(source, condition, routes)
        self.conditional_edges.append(edge)
        logger.debug("[GRAPH] Added conditional edges from %s: %s", source, routes)
        return self
    
    def set_entry_point(self, node_name: str) -> "WorkflowGraph":
        """Set the entry point for the graph."""
        if node_name not in self.nodes:
            raise ValueError(f"Node '{node_name}' not found")
        self.entry_point = node_name
        logger.debug("[GRAPH] Entry point: %s", node_name)
        return self
    
    def set_finish_point(self, node_name: str) -> "WorkflowGraph":
        """Mark a node as a finish point."""
        if node_name not in self.nodes:
            raise ValueError(f"Node '{node_name}' not found")
        self.finish_nodes.add(node_name)
        logger.debug("[GRAPH] Finish point: %s", node_name)
        return self
    
    def set_tracer(self, tracer: Any) -> "WorkflowGraph":
        """Set a tracer for debugging/logging."""
        self._tracer = tracer
        return self
    
    def _get_next_node(self, current: str, state: WorkflowState) -> str | None:
        """Determine the next node to execute."""
        # Check conditional edges first
        for cond_edge in self.conditional_edges:
            if cond_edge.source == current:
                target = cond_edge.get_target(state)
                if target and target != "END":
                    state.add_decision(
                        decision_point=f"conditional_edge:{current}",
                        outcome=target,
                        reason=f"Route selected by condition",
                    )
                    return target
                elif target == "END":
                    return None
        
        # Check regular edges
        candidates = []
        for edge in self.edges:
            if edge.source == current:
                if edge.should_take(state):
                    candidates.append(edge.target)
        
        if not candidates:
            return None
        
        if len(candidates) == 1:
            return candidates[0]
        
        # Multiple edges - take the first one
        # (In LangGraph, this would be parallel execution)
        logger.warning(
            "[GRAPH] Multiple edges from %s, taking first: %s",
            current, candidates[0]
        )
        return candidates[0]
    
    async def execute(self, state: WorkflowState) -> WorkflowState:
        """
        Execute the workflow graph.
        
        Args:
            state: Initial workflow state
            
        Returns:
            Final workflow state
        """
        if not self.entry_point:
            raise ValueError("No entry point set")
        
        logger.info("[GRAPH] Starting workflow: %s (entry: %s)", self.name, self.entry_point)
        
        current_node = self.entry_point
        iteration = 0
        
        while current_node and iteration < self.max_iterations:
            iteration += 1
            
            # Check if we're at a finish node
            if current_node in self.finish_nodes:
                logger.info("[GRAPH] Reached finish node: %s", current_node)
            
            # Get the node
            node = self.nodes.get(current_node)
            if not node:
                logger.error("[GRAPH] Node not found: %s", current_node)
                state.add_error(f"Node '{current_node}' not found", recoverable=False)
                break
            
            # Trace node start
            if self._tracer:
                await self._tracer.trace_node_start(current_node, state)
            
            # Execute node
            result = await node(state)
            
            # Trace node end
            if self._tracer:
                await self._tracer.trace_node_end(current_node, result, state)
            
            # Handle result
            if result.status == NodeStatus.FAILED:
                logger.error("[GRAPH] Node %s failed: %s", current_node, result.error)
                if result.metadata.get("retry", False):
                    continue  # Retry the same node
                break
            
            # Determine next node
            if result.next_node:
                next_node = result.next_node
            else:
                next_node = self._get_next_node(current_node, state)
            
            if not next_node:
                logger.info("[GRAPH] Workflow complete at node: %s", current_node)
                break
            
            current_node = next_node
        
        if iteration >= self.max_iterations:
            logger.warning("[GRAPH] Max iterations reached (%d)", self.max_iterations)
            state.add_error("Max iterations reached", recoverable=True)
        
        logger.info("[GRAPH] Workflow finished. Path: %s", " → ".join(state.visited_nodes))
        
        return state
    
    def compile(self) -> "CompiledGraph":
        """
        Compile the graph for execution.
        
        Returns a CompiledGraph that can be executed multiple times
        with different states.
        """
        return CompiledGraph(self)


class CompiledGraph:
    """
    Compiled workflow graph ready for execution.
    
    Similar to LangGraph's compiled graph, this is the
    executable version of the workflow.
    """
    
    def __init__(self, graph: WorkflowGraph):
        self.graph = graph
        self._validate()
    
    def _validate(self):
        """Validate the graph structure."""
        if not self.graph.entry_point:
            raise ValueError("Graph must have an entry point")
        
        if not self.graph.nodes:
            raise ValueError("Graph must have at least one node")
        
        # Check all edges reference valid nodes
        for edge in self.graph.edges:
            if edge.source not in self.graph.nodes:
                raise ValueError(f"Edge source '{edge.source}' not in nodes")
            if edge.target not in self.graph.nodes and edge.target != "END":
                raise ValueError(f"Edge target '{edge.target}' not in nodes")
    
    async def __call__(self, state: WorkflowState) -> WorkflowState:
        """Execute the compiled graph."""
        return await self.graph.execute(state)
    
    async def invoke(self, state: WorkflowState) -> WorkflowState:
        """Invoke the graph (alias for __call__)."""
        return await self(state)
    
    def get_graph_info(self) -> dict[str, Any]:
        """Get information about the graph structure."""
        return {
            "name": self.graph.name,
            "entry_point": self.graph.entry_point,
            "finish_nodes": list(self.graph.finish_nodes),
            "nodes": list(self.graph.nodes.keys()),
            "edges": [
                {"source": e.source, "target": e.target, "label": e.label}
                for e in self.graph.edges
            ],
            "conditional_edges": [
                {"source": e.source, "routes": e.routes}
                for e in self.graph.conditional_edges
            ],
        }


# Helper functions for creating common patterns

def create_linear_workflow(
    nodes: list[Node],
    name: str = "linear_workflow",
) -> WorkflowGraph:
    """Create a simple linear workflow from a list of nodes."""
    graph = WorkflowGraph(name)
    
    for node in nodes:
        graph.add_node(node)
    
    for i in range(len(nodes) - 1):
        graph.add_edge(nodes[i].name, nodes[i + 1].name)
    
    if nodes:
        graph.set_entry_point(nodes[0].name)
        graph.set_finish_point(nodes[-1].name)
    
    return graph
