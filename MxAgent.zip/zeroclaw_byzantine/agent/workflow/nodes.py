"""
Pre-built Node Types for Workflow Graph.

Provides ready-to-use nodes:
- LLMNode: Call LLM for generation
- ToolNode: Execute tools
- RouterNode: Route based on conditions
- PromptNode: Build prompts
- RetrievalNode: Retrieve context (RAG)
- OutputNode: Format and return output
"""

from __future__ import annotations

import json
import logging
import asyncio
from typing import Any, Callable, Awaitable

from agent.workflow.graph import Node, NodeResult, NodeStatus
from agent.workflow.state import WorkflowState

logger = logging.getLogger(__name__)


class LLMNode(Node):
    """
    Node that calls an LLM for generation.
    
    Handles:
    - Building the prompt from state
    - Calling the LLM
    - Parsing the response
    - Detecting tool calls
    """
    
    def __init__(
        self,
        name: str,
        llm: Any,
        prompt_template: str | None = None,
        system_message: str | None = None,
        tools_description: str = "",
        extract_tool_calls: bool = True,
    ):
        super().__init__(name)
        self.llm = llm
        self.prompt_template = prompt_template
        self.system_message = system_message
        self.tools_description = tools_description
        self.extract_tool_calls = extract_tool_calls
    
    async def execute(self, state: WorkflowState) -> NodeResult:
        """Execute LLM call."""
        try:
            # Build prompt
            if self.prompt_template:
                prompt = self.prompt_template.format(**state.to_dict())
            else:
                prompt = state.current_prompt
            
            # Get history
            history = state.get_conversation_history()
            
            # Build system message
            system = self.system_message or self._build_system_message(state)
            
            # Call LLM
            logger.info("[LLM_NODE] %s: calling LLM with %d history turns", self.name, len(history))
            
            response = await asyncio.wait_for(
                self.llm.generate(
                    prompt=prompt,
                    history=history,
                    tools_description=self.tools_description,
                    system_message=system,
                ),
                timeout=120.0
            )
            
            # Store response
            state.set("llm_response", response.content)
            
            # Check for tool calls
            if response.has_tool_call():
                state.add_tool_call(
                    response.tool_call.get("tool", ""),
                    response.tool_call.get("args", {})
                )
                state.add_decision(
                    decision_point="llm_response_type",
                    outcome="tool_call",
                    reason=f"Tool: {response.tool_call.get('tool')}"
                )
            else:
                state.add_decision(
                    decision_point="llm_response_type",
                    outcome="text_response",
                    reason=f"Response length: {len(response.content)}"
                )
            
            return NodeResult(
                status=NodeStatus.COMPLETED,
                metadata={"has_tool_call": response.has_tool_call()}
            )
            
        except asyncio.TimeoutError:
            logger.error("[LLM_NODE] %s: timeout", self.name)
            state.add_error("LLM call timed out", node=self.name)
            return NodeResult(
                status=NodeStatus.FAILED,
                error="LLM call timed out"
            )
        except Exception as e:
            logger.error("[LLM_NODE] %s: error - %s", self.name, e)
            state.add_error(str(e), node=self.name)
            return NodeResult(
                status=NodeStatus.FAILED,
                error=str(e)
            )
    
    def _build_system_message(self, state: WorkflowState) -> str:
        """Build system message from state."""
        parts = []
        
        if state.facts:
            parts.append("## FACTS")
            parts.append("\n".join(f"- {k}: {v}" for k, v in state.facts.items()))
        
        if state.summary:
            parts.append("## SUMMARY")
            parts.append(state.summary)
        
        if state.rag_context:
            parts.append("## RELEVANT CONTEXT")
            parts.append(state.rag_context)
        
        return "\n\n".join(parts) if parts else "You are a helpful assistant."


class ToolNode(Node):
    """
    Node that executes tools.
    
    Handles:
    - Getting tool calls from state
    - Executing tools
    - Storing results
    """
    
    def __init__(
        self,
        name: str,
        tool_executor: Any,
        max_retries: int = 2,
    ):
        super().__init__(name)
        self.tool_executor = tool_executor
        self.max_retries = max_retries
    
    async def execute(self, state: WorkflowState) -> NodeResult:
        """Execute pending tool calls."""
        if not state.tool_calls:
            logger.info("[TOOL_NODE] %s: no tool calls to execute", self.name)
            return NodeResult(status=NodeStatus.COMPLETED)
        
        try:
            # Get last tool call
            tool_call = state.tool_calls[-1]
            tool_name = tool_call.get("tool", "")
            tool_args = tool_call.get("args", {})
            
            logger.info("[TOOL_NODE] %s: executing tool %s", self.name, tool_name)
            
            # Execute tool
            result = await asyncio.wait_for(
                self.tool_executor.execute(tool_call),
                timeout=60.0
            )
            
            # Store result
            state.add_tool_result(tool_name, result, success=True)
            
            # Update prompt for next iteration
            state.set("current_prompt", "")
            state.add_message("assistant", f"[Tool: {tool_name}]")
            state.add_message("user", f"[Result: {tool_name}]\n{result}")
            
            return NodeResult(
                status=NodeStatus.COMPLETED,
                metadata={"tool_name": tool_name, "result_length": len(result)}
            )
            
        except asyncio.TimeoutError:
            logger.error("[TOOL_NODE] %s: tool execution timed out", self.name)
            state.add_error("Tool execution timed out", node=self.name)
            return NodeResult(
                status=NodeStatus.FAILED,
                error="Tool execution timed out"
            )
        except Exception as e:
            logger.error("[TOOL_NODE] %s: error - %s", self.name, e)
            state.add_error(str(e), node=self.name)
            state.add_tool_result(
                state.tool_calls[-1].get("tool", "unknown"),
                str(e),
                success=False
            )
            return NodeResult(
                status=NodeStatus.FAILED,
                error=str(e)
            )


class RouterNode(Node):
    """
    Node that routes to different paths based on conditions.
    
    Similar to LangGraph's conditional edges but as a node.
    """
    
    def __init__(
        self,
        name: str,
        router_func: Callable[[WorkflowState], str],
        routes: dict[str, str],
    ):
        super().__init__(name)
        self.router_func = router_func
        self.routes = routes
    
    async def execute(self, state: WorkflowState) -> NodeResult:
        """Determine next node based on routing logic."""
        try:
            route_key = self.router_func(state)
            next_node = self.routes.get(route_key)
            
            state.add_decision(
                decision_point=self.name,
                outcome=route_key,
                reason=f"Routed to {next_node}"
            )
            
            logger.info("[ROUTER_NODE] %s: route '%s' → %s", self.name, route_key, next_node)
            
            return NodeResult(
                status=NodeStatus.COMPLETED,
                next_node=next_node
            )
            
        except Exception as e:
            logger.error("[ROUTER_NODE] %s: error - %s", self.name, e)
            state.add_error(str(e), node=self.name)
            return NodeResult(
                status=NodeStatus.FAILED,
                error=str(e)
            )


class PromptNode(Node):
    """
    Node that builds/transforms prompts.
    
    Useful for:
    - Initial prompt processing
    - Context injection
    - Prompt templating
    """
    
    def __init__(
        self,
        name: str,
        prompt_builder: Callable[[WorkflowState], str] | str,
    ):
        super().__init__(name)
        if isinstance(prompt_builder, str):
            self.template = prompt_builder
            self.builder = None
        else:
            self.template = None
            self.builder = prompt_builder
    
    async def execute(self, state: WorkflowState) -> NodeResult:
        """Build the prompt."""
        try:
            if self.builder:
                prompt = self.builder(state)
            else:
                prompt = self.template.format(**state.to_dict())
            
            state.set("current_prompt", prompt, use_reducer=False)
            
            logger.info("[PROMPT_NODE] %s: built prompt (%d chars)", self.name, len(prompt))
            
            return NodeResult(
                status=NodeStatus.COMPLETED,
                metadata={"prompt_length": len(prompt)}
            )
            
        except Exception as e:
            logger.error("[PROMPT_NODE] %s: error - %s", self.name, e)
            state.add_error(str(e), node=self.name)
            return NodeResult(
                status=NodeStatus.FAILED,
                error=str(e)
            )


class RetrievalNode(Node):
    """
    Node that retrieves context (RAG).
    
    Handles:
    - Vector similarity search
    - Context retrieval
    - Memory lookups
    """
    
    def __init__(
        self,
        name: str,
        retriever: Any,
        query_key: str = "current_prompt",
        max_results: int = 5,
    ):
        super().__init__(name)
        self.retriever = retriever
        self.query_key = query_key
        self.max_results = max_results
    
    async def execute(self, state: WorkflowState) -> NodeResult:
        """Retrieve relevant context."""
        try:
            query = state.get(self.query_key, state.user_input)
            
            logger.info("[RETRIEVAL_NODE] %s: searching for '%s'", self.name, query[:50])
            
            # Perform retrieval
            if hasattr(self.retriever, 'search_similar'):
                results = await self.retriever.search_similar(
                    state.user_id,
                    query,
                    limit=self.max_results
                )
            elif hasattr(self.retriever, 'get_rag_context'):
                context = await self.retriever.get_rag_context(
                    state.user_id,
                    query,
                    max_results=self.max_results
                )
                state.set("rag_context", context, use_reducer=False)
                return NodeResult(status=NodeStatus.COMPLETED)
            else:
                # Assume it's a simple callable
                results = await self.retriever(query)
            
            # Format results
            if isinstance(results, list):
                context = "\n\n".join(
                    r.get("content", str(r)) if isinstance(r, dict) else str(r)
                    for r in results
                )
            else:
                context = str(results)
            
            state.set("rag_context", context, use_reducer=False)
            
            logger.info("[RETRIEVAL_NODE] %s: retrieved %d chars of context", self.name, len(context))
            
            return NodeResult(
                status=NodeStatus.COMPLETED,
                metadata={"context_length": len(context)}
            )
            
        except Exception as e:
            logger.error("[RETRIEVAL_NODE] %s: error - %s", self.name, e)
            state.add_error(str(e), node=self.name)
            return NodeResult(
                status=NodeStatus.FAILED,
                error=str(e)
            )


class OutputNode(Node):
    """
    Node that formats and sets the final output.
    
    Handles:
    - Response formatting
    - Final state updates
    - Cleanup
    """
    
    def __init__(
        self,
        name: str,
        formatter: Callable[[WorkflowState], str] | None = None,
    ):
        super().__init__(name)
        self.formatter = formatter
    
    async def execute(self, state: WorkflowState) -> NodeResult:
        """Format and set the final output."""
        try:
            if self.formatter:
                output = self.formatter(state)
            else:
                output = state.llm_response or state.get("final_response", "")
            
            state.set("final_response", output, use_reducer=False)
            
            # Add to messages
            state.add_message("assistant", output)
            
            logger.info("[OUTPUT_NODE] %s: set final response (%d chars)", self.name, len(output))
            
            return NodeResult(
                status=NodeStatus.COMPLETED,
                metadata={"response_length": len(output)}
            )
            
        except Exception as e:
            logger.error("[OUTPUT_NODE] %s: error - %s", self.name, e)
            state.add_error(str(e), node=self.name)
            return NodeResult(
                status=NodeStatus.FAILED,
                error=str(e)
            )


class ErrorNode(Node):
    """
    Node that handles errors.
    
    Can:
    - Log errors
    - Generate error messages
    - Decide whether to retry
    """
    
    def __init__(
        self,
        name: str,
        max_retries: int = 2,
        fallback_message: str = "Sorry, an error occurred. Please try again.",
    ):
        super().__init__(name)
        self.max_retries = max_retries
        self.fallback_message = fallback_message
    
    async def execute(self, state: WorkflowState) -> NodeResult:
        """Handle errors."""
        errors = state.errors
        
        if not errors:
            return NodeResult(status=NodeStatus.COMPLETED)
        
        last_error = errors[-1]
        
        # Check if we should retry
        if state.retries < self.max_retries and last_error.get("recoverable", True):
            state.retries += 1
            logger.info("[ERROR_NODE] %s: retrying (attempt %d)", self.name, state.retries)
            return NodeResult(
                status=NodeStatus.COMPLETED,
                metadata={"action": "retry", "retry_count": state.retries}
            )
        
        # Generate error response
        state.set("final_response", self.fallback_message, use_reducer=False)
        state.add_message("assistant", self.fallback_message)
        
        logger.warning("[ERROR_NODE] %s: returning fallback message", self.name)
        
        return NodeResult(
            status=NodeStatus.COMPLETED,
            metadata={"action": "fallback"}
        )


class ContextLoaderNode(Node):
    """
    Node that loads context from memory.
    
    Loads:
    - Facts
    - Summary
    - Conversation history
    """
    
    def __init__(
        self,
        name: str,
        memory_manager: Any,
    ):
        super().__init__(name)
        self.memory = memory_manager
    
    async def execute(self, state: WorkflowState) -> NodeResult:
        """Load context from memory."""
        try:
            # Load facts
            facts = await self.memory.get_all_facts(state.user_id)
            state.set("facts", facts, use_reducer=False)
            
            # Load summary
            summary = await self.memory.get_summary(state.user_id, state.channel)
            state.set("summary", summary or "", use_reducer=False)
            
            # Load recent conversations
            recent = await self.memory.get_recent_conversations(state.user_id, limit=10)
            for msg in recent:
                state.add_message(msg["role"], msg["content"])
            
            logger.info(
                "[CONTEXT_NODE] %s: loaded %d facts, %d chars summary, %d history",
                self.name, len(facts), len(summary or ""), len(recent)
            )
            
            return NodeResult(
                status=NodeStatus.COMPLETED,
                metadata={"facts_count": len(facts)}
            )
            
        except Exception as e:
            logger.error("[CONTEXT_NODE] %s: error - %s", self.name, e)
            state.add_error(str(e), node=self.name)
            return NodeResult(
                status=NodeStatus.FAILED,
                error=str(e)
            )


class FactExtractionNode(Node):
    """
    Node that extracts facts from user messages.
    """
    
    def __init__(
        self,
        name: str,
        memory_manager: Any,
        use_llm: bool = False,
        llm: Any = None,
    ):
        super().__init__(name)
        self.memory = memory_manager
        self.use_llm = use_llm
        self.llm = llm
    
    async def execute(self, state: WorkflowState) -> NodeResult:
        """Extract facts from user input."""
        try:
            text = state.user_input
            
            # Simple regex-based extraction
            import re
            patterns = [
                (re.compile(r"my\s+name\s+is\s+(\w+)", re.I), "name"),
                (re.compile(r"i\s+(?:am|'m)\s+(\w+)", re.I), "name"),
            ]
            
            extracted = []
            for pattern, key in patterns:
                match = pattern.search(text)
                if match:
                    value = match.group(1).strip()
                    await self.memory.store_fact(state.user_id, key, value)
                    extracted.append((key, value))
            
            if extracted:
                state.update({"facts": dict(extracted)})
                logger.info("[FACT_NODE] %s: extracted %d facts", self.name, len(extracted))
            
            return NodeResult(
                status=NodeStatus.COMPLETED,
                metadata={"extracted_count": len(extracted)}
            )
            
        except Exception as e:
            logger.error("[FACT_NODE] %s: error - %s", self.name, e)
            return NodeResult(status=NodeStatus.COMPLETED)  # Non-critical
