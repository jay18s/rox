"""
Workflow State - Manages state across the workflow execution.

Mirrors LangGraph's state management pattern where each node
can read and write to a shared state object.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable
from copy import deepcopy

logger = logging.getLogger(__name__)


class StateReducer:
    """
    Defines how to merge values into state keys.
    Similar to LangGraph's reducer functions.
    """
    
    @staticmethod
    def append(existing: list, new: Any) -> list:
        """Append new value to existing list."""
        if existing is None:
            existing = []
        if isinstance(new, list):
            return existing + new
        return existing + [new]
    
    @staticmethod
    def replace(existing: Any, new: Any) -> Any:
        """Replace existing value with new value."""
        return new
    
    @staticmethod
    def merge_dict(existing: dict, new: dict) -> dict:
        """Merge new dict into existing dict."""
        if existing is None:
            existing = {}
        result = deepcopy(existing)
        result.update(new)
        return result
    
    @staticmethod
    def keep_last(existing: Any, new: Any) -> Any:
        """Keep the last non-None value."""
        return new if new is not None else existing


@dataclass
class WorkflowState:
    """
    State container for workflow execution.
    
    Attributes:
        messages: List of conversation messages
        user_input: Original user input
        current_prompt: Current prompt being processed
        llm_response: Response from LLM
        tool_calls: List of tool calls made
        tool_results: List of tool results
        context: Additional context (facts, summary, RAG)
        metadata: Workflow metadata (user_id, channel, etc.)
        artifacts: Generated artifacts (files, data, etc.)
        errors: List of errors encountered
        decisions: Decision points and their outcomes
    """
    
    # Core conversation state
    messages: list[dict[str, str]] = field(default_factory=list)
    user_input: str = ""
    current_prompt: str = ""
    
    # LLM interaction state
    llm_response: str = ""
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    tool_results: list[dict[str, Any]] = field(default_factory=list)
    
    # Context state
    context: dict[str, Any] = field(default_factory=dict)
    facts: dict[str, str] = field(default_factory=dict)
    summary: str = ""
    rag_context: str = ""
    
    # Metadata
    metadata: dict[str, Any] = field(default_factory=dict)
    user_id: str = ""
    channel: str = ""
    session_key: str = ""
    
    # Output
    final_response: str = ""
    artifacts: dict[str, Any] = field(default_factory=dict)
    
    # Error handling
    errors: list[dict[str, Any]] = field(default_factory=list)
    retries: int = 0
    
    # Decision tracking
    decisions: list[dict[str, Any]] = field(default_factory=list)
    
    # Execution tracking
    current_node: str = ""
    visited_nodes: list[str] = field(default_factory=list)
    execution_path: list[dict[str, Any]] = field(default_factory=list)
    
    # Reducers for each key
    _reducers: dict[str, Callable] = field(default_factory=dict, repr=False)
    
    def __post_init__(self):
        """Set default reducers."""
        self._reducers = {
            "messages": StateReducer.append,
            "tool_calls": StateReducer.append,
            "tool_results": StateReducer.append,
            "errors": StateReducer.append,
            "decisions": StateReducer.append,
            "visited_nodes": StateReducer.append,
            "execution_path": StateReducer.append,
            "context": StateReducer.merge_dict,
            "facts": StateReducer.merge_dict,
            "artifacts": StateReducer.merge_dict,
        }
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get a state value with optional default."""
        return getattr(self, key, default)
    
    def set(self, key: str, value: Any, use_reducer: bool = True) -> None:
        """
        Set a state value, optionally using a reducer.
        
        Args:
            key: State key to set
            value: New value
            use_reducer: Whether to apply reducer function
        """
        if use_reducer and key in self._reducers:
            existing = getattr(self, key, None)
            value = self._reducers[key](existing, value)
        
        if hasattr(self, key):
            setattr(self, key, value)
        else:
            # Store unknown keys in context
            self.context[key] = value
        
        logger.debug("[STATE] Set %s = %s", key, str(value)[:100])
    
    def update(self, updates: dict[str, Any], use_reducer: bool = True) -> None:
        """Update multiple state values at once."""
        for key, value in updates.items():
            self.set(key, value, use_reducer=use_reducer)
    
    def add_message(self, role: str, content: str) -> None:
        """Add a message to the conversation."""
        self.messages.append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat(),
        })
    
    def add_error(self, error: str, node: str = "", recoverable: bool = True) -> None:
        """Record an error."""
        self.errors.append({
            "error": error,
            "node": node or self.current_node,
            "recoverable": recoverable,
            "timestamp": datetime.now().isoformat(),
        })
        logger.warning("[STATE] Error at %s: %s", node, error)
    
    def add_decision(self, decision_point: str, outcome: str, reason: str = "") -> None:
        """Record a decision point."""
        self.decisions.append({
            "decision_point": decision_point,
            "outcome": outcome,
            "reason": reason,
            "timestamp": datetime.now().isoformat(),
        })
        logger.debug("[STATE] Decision: %s → %s (%s)", decision_point, outcome, reason)
    
    def add_tool_call(self, tool_name: str, args: dict[str, Any]) -> None:
        """Record a tool call."""
        self.tool_calls.append({
            "tool": tool_name,
            "args": args,
            "timestamp": datetime.now().isoformat(),
        })
    
    def add_tool_result(self, tool_name: str, result: str, success: bool = True) -> None:
        """Record a tool result."""
        self.tool_results.append({
            "tool": tool_name,
            "result": result,
            "success": success,
            "timestamp": datetime.now().isoformat(),
        })
    
    def visit_node(self, node_name: str) -> None:
        """Record visiting a node."""
        self.current_node = node_name
        self.visited_nodes.append(node_name)
        self.execution_path.append({
            "node": node_name,
            "timestamp": datetime.now().isoformat(),
        })
        logger.debug("[STATE] Visited node: %s", node_name)
    
    def snapshot(self) -> dict[str, Any]:
        """Create a snapshot of the current state."""
        return {
            "user_input": self.user_input,
            "current_prompt": self.current_prompt,
            "llm_response": self.llm_response,
            "tool_calls": self.tool_calls.copy(),
            "tool_results": self.tool_results.copy(),
            "context": deepcopy(self.context),
            "facts": deepcopy(self.facts),
            "final_response": self.final_response,
            "errors": self.errors.copy(),
            "decisions": self.decisions.copy(),
            "visited_nodes": self.visited_nodes.copy(),
            "current_node": self.current_node,
        }
    
    def restore(self, snapshot: dict[str, Any]) -> None:
        """Restore state from a snapshot."""
        for key, value in snapshot.items():
            if hasattr(self, key):
                setattr(self, key, deepcopy(value))
    
    def is_complete(self) -> bool:
        """Check if workflow is complete (has final response)."""
        return bool(self.final_response) or bool(self.llm_response)
    
    def has_errors(self) -> bool:
        """Check if there are any errors."""
        return len(self.errors) > 0
    
    def has_unrecoverable_errors(self) -> bool:
        """Check if there are unrecoverable errors."""
        return any(not e.get("recoverable", True) for e in self.errors)
    
    def get_last_tool_result(self) -> dict[str, Any] | None:
        """Get the most recent tool result."""
        return self.tool_results[-1] if self.tool_results else None
    
    def get_conversation_history(self, max_turns: int = 10) -> list[dict[str, str]]:
        """Get recent conversation history."""
        return self.messages[-max_turns:] if self.messages else []
    
    def to_dict(self) -> dict[str, Any]:
        """Convert state to dictionary for serialization."""
        return {
            "messages": self.messages,
            "user_input": self.user_input,
            "current_prompt": self.current_prompt,
            "llm_response": self.llm_response,
            "tool_calls": self.tool_calls,
            "tool_results": self.tool_results,
            "context": self.context,
            "facts": self.facts,
            "summary": self.summary,
            "rag_context": self.rag_context,
            "metadata": self.metadata,
            "user_id": self.user_id,
            "channel": self.channel,
            "session_key": self.session_key,
            "final_response": self.final_response,
            "artifacts": self.artifacts,
            "errors": self.errors,
            "retries": self.retries,
            "decisions": self.decisions,
            "current_node": self.current_node,
            "visited_nodes": self.visited_nodes,
            "execution_path": self.execution_path,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "WorkflowState":
        """Create state from dictionary."""
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
    
    @classmethod
    def create_for_request(
        cls,
        user_input: str,
        user_id: str,
        channel: str,
        history: list[dict[str, str]] | None = None,
    ) -> "WorkflowState":
        """Create a new state for processing a user request."""
        state = cls(
            user_input=user_input,
            current_prompt=user_input,
            user_id=user_id,
            channel=channel,
            session_key=f"{channel}:{user_id}",
            messages=history or [],
        )
        state.metadata["created_at"] = datetime.now().isoformat()
        return state
