"""
Integration Guide: LangGraph-Style Workflow for ZeroClaw Agent
================================================================

This guide shows how to integrate the new workflow-based architecture
into your ZeroClaw agent.

## Architecture Overview (from screenshot)

```
┌─────────────────────────────────────────────────────────────────┐
│                    USER REQUEST                                 │
│                      (input)                                    │
└─────────────────────────────┬───────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                   EXECUTION ROUTER                              │
│         (LangGraph: Determine execution path)                   │
└───────────┬─────────────────────────────┬───────────────────────┘
            │                             │
            ▼                             ▼
┌───────────────────────┐     ┌───────────────────────────────────┐
│    NODE A             │     │    NODE B (Conditional Branch)    │
│  (Process Request)    │     │    (Route based on state)         │
└───────────┬───────────┘     └───────────┬───────────────────────┘
            │                             │
            └─────────────┬───────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                     LANGCHAIN                                   │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐              │
│  │   Prompt    │→ │  Retrieval  │→ │  Model Call │              │
│  │   Builder   │  │    (RAG)    │  │    (LLM)    │              │
│  └─────────────┘  └─────────────┘  └──────┬──────┘              │
│                                           │                      │
│                                           ▼                      │
│                                   ┌─────────────┐                │
│                                   │   Tool      │                │
│                                   │  Execution  │                │
│                                   └─────────────┘                │
└─────────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                     LANGSMITH                                   │
│    (Trace Logger, Output Recorder, Decision Tracker)            │
└─────────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                    FINAL OUTPUT                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Quick Start

### Option 1: Use the new WorkflowEngine (Recommended)

Replace your existing engine with the workflow-based engine:

```python
# In main.py

from agent.workflow_engine import WorkflowEngine

# Instead of:
# from agent.engine import CoreEngine
# engine = CoreEngine(llm, memory, tool_executor, ws_memory, eng_cfg)

# Use:
engine = WorkflowEngine(
    llm=llm,
    memory=memory,
    tool_executor=tool_executor,
    workspace_memory=ws_memory,
    config=eng_cfg,
)
```

### Option 2: Build Custom Workflows

Create your own workflow graphs:

```python
from agent.workflow import WorkflowGraph, LLMNode, ToolNode, RouterNode, OutputNode

# Create graph
graph = WorkflowGraph("my_custom_agent")

# Add nodes
graph.add_node(LLMNode("think", llm))
graph.add_node(ToolNode("act", tool_executor))
graph.add_node(OutputNode("respond"))

# Define flow
graph.set_entry_point("think")
graph.add_edge("think", "act")
graph.add_edge("act", "respond")

# Compile and run
compiled = graph.compile()
final_state = await compiled(state)
```

## Node Types

### LLMNode
Calls the LLM with the current state.

```python
llm_node = LLMNode(
    name="generate_response",
    llm=llm_router,
    system_message="You are a helpful assistant.",
    extract_tool_calls=True,
)
```

### ToolNode
Executes tools from the state.

```python
tool_node = ToolNode(
    name="execute_tools",
    tool_executor=tool_executor,
    max_retries=2,
)
```

### RouterNode
Routes to different nodes based on conditions.

```python
def my_router(state: WorkflowState) -> str:
    if state.has_errors():
        return "error_handler"
    if state.tool_calls:
        return "tool_executor"
    return "output"

router_node = RouterNode(
    name="decide_next",
    router_func=my_router,
    routes={
        "error_handler": "handle_error",
        "tool_executor": "execute_tool",
        "output": "final_output",
    },
)
```

### ContextLoaderNode
Loads facts, summary, and history from memory.

```python
context_node = ContextLoaderNode(
    name="load_context",
    memory_manager=memory,
)
```

### RetrievalNode
Performs RAG retrieval.

```python
retrieval_node = RetrievalNode(
    name="retrieve_context",
    retriever=vector_store,
    max_results=5,
)
```

### OutputNode
Formats and sets the final output.

```python
output_node = OutputNode(
    name="format_output",
    formatter=lambda state: state.llm_response,
)
```

## State Management

The WorkflowState holds all data during execution:

```python
# Create state
state = WorkflowState.create_for_request(
    user_input="Hello",
    user_id="user123",
    channel="telegram",
)

# Access data
print(state.user_input)
print(state.facts)
print(state.visited_nodes)

# Modify state
state.set("custom_key", "value")
state.add_tool_call("web_search", {"query": "python"})
state.add_decision("route_check", "llm", "No tools needed")
```

## Tracing (LangSmith-style)

Enable tracing to debug and monitor:

```python
from agent.tracing import init_tracer, get_tracer

# Initialize tracer
tracer = init_tracer("traces.db")

# Get statistics
stats = tracer.get_stats()
print(f"Total traces: {stats['total_traces']}")

# Get a specific trace
trace = tracer.get_trace("abc123")
print(trace["decisions"])

# Get user history
traces = tracer.get_user_traces("user123", limit=10)
```

## ReAct Pattern Integration

The workflow naturally supports ReAct (Reason + Act):

```python
# ReAct-style workflow
graph = WorkflowGraph("react_agent")

# Nodes
graph.add_node(LLMNode("reason", llm))  # Thought
graph.add_node(ToolNode("act", tools))  # Action
graph.add_node(RouterNode("route", router, routes))
graph.add_node(OutputNode("answer"))

# Edges for ReAct loop
graph.set_entry_point("reason")
graph.add_conditional_edges("reason", check_tool_needed, {
    "tool": "act",
    "answer": "answer",
})
graph.add_edge("act", "reason")  # Loop back for observation

# The LLM sees: Thought → Action → Observation → Thought → ...
```

## Configuration

Add these options to your config.toml:

```toml
[agent.behaviour]
enable_react = true
enable_tracing = true
tool_loop_max = 10

[agent.tracing]
enabled = true
db_path = "traces.db"
```

## Example: Custom Agent Workflow

```python
from agent.workflow import *
from agent.tracing import init_tracer

# Initialize
tracer = init_tracer()

# Build graph
graph = WorkflowGraph("smart_agent")

# Define nodes
nodes = [
    ContextLoaderNode("context", memory),
    FactExtractionNode("facts", memory),
    RetrievalNode("rag", vector_store, max_results=5),
    LLMNode("think", llm),
    ToolNode("act", tools),
    RouterNode("route", lambda s: "act" if s.tool_calls else "done", 
               {"act": "act", "done": "output"}),
    OutputNode("output"),
]

for node in nodes:
    graph.add_node(node)

# Define edges
graph.set_entry_point("context")
graph.add_edge("context", "facts")
graph.add_edge("facts", "rag")
graph.add_edge("rag", "think")
graph.add_conditional_edges("think", 
    lambda s: "act" if s.tool_calls else "output",
    {"act": "act", "output": "output"})
graph.add_edge("act", "think")  # Loop back

# Set tracer
graph.set_tracer(tracer)

# Compile
agent = graph.compile()

# Run
state = WorkflowState.create_for_request(
    user_input="What's the weather?",
    user_id="user123",
    channel="telegram",
)
final_state = await agent(state)
print(final_state.final_response)
```

## Debugging

View execution path:

```python
# After execution
print("Execution path:", " → ".join(final_state.visited_nodes))
print("Decisions made:", final_state.decisions)
print("Tool calls:", final_state.tool_calls)
print("Errors:", final_state.errors)

# Get full trace
trace = tracer.get_trace(final_state.metadata.get("trace_id"))
print(json.dumps(trace, indent=2))
```

## Migration Guide

### From Old Engine

1. Replace `CoreEngine` import with `WorkflowEngine`
2. No changes needed to gateway or channels
3. Tracing is automatically enabled

### Adding Custom Nodes

```python
from agent.workflow.graph import Node, NodeResult, NodeStatus

class MyCustomNode(Node):
    def __init__(self, name: str, my_param: str):
        super().__init__(name)
        self.my_param = my_param
    
    async def execute(self, state: WorkflowState) -> NodeResult:
        # Your logic here
        state.set("custom_result", "something")
        return NodeResult(status=NodeStatus.COMPLETED)
```

## Benefits

1. **Visual Clarity**: See exactly how requests flow through your agent
2. **Easy Debugging**: Trace every decision and step
3. **Flexibility**: Add/remove nodes without changing core logic
4. **ReAct Support**: Natural pattern for reasoning + action loops
5. **Observability**: Built-in tracing like LangSmith
"""

__all__ = [
    "WorkflowEngine",
    "WorkflowGraph",
    "WorkflowState",
    "Node",
    "LLMNode",
    "ToolNode",
    "RouterNode",
    "OutputNode",
    "Tracer",
]
