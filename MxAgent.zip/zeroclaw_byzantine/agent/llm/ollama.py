"""Ollama LLM provider using the ollama Python library."""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from agent.llm.base import BaseLLM, LLMResponse

logger = logging.getLogger(__name__)

TOOL_CALL_PATTERN = re.compile(r"\{[^{}]*\"tool\"\s*:[^{}]*\}", re.DOTALL)


def _build_system_prompt(system_message: str, tools_description: str) -> str:
    parts = [system_message.strip()]
    if tools_description.strip():
        parts.append(
            "\n\n## Available Tools\n"
            + tools_description.strip()
            + "\n\nTo call a tool, output ONLY a JSON object on a single line like:\n"
            '{"tool": "run_command", "args": {"command": "dir", "args": ["."]}}\n'
            "Do NOT add any text before or after the JSON when calling a tool.\n"
            "For regular responses, just output natural language text."
        )
    return "\n".join(parts)


class OllamaProvider(BaseLLM):
    """LLM provider backed by a local Ollama server."""

    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__(config)
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is None:
            try:
                import ollama
                host = self.config.get("ollama_host", "http://localhost:11434")
                self._client = ollama.AsyncClient(host=host)
            except ImportError:
                raise RuntimeError("ollama package not installed. Run: pip install ollama")
        return self._client

    async def generate(
        self,
        prompt: str,
        history: list[dict[str, str]],
        tools_description: str,
        system_message: str,
    ) -> LLMResponse:
        client = self._get_client()
        model = self.config.get("model", "llama3.2")

        system = _build_system_prompt(system_message, tools_description)

        messages: list[dict[str, str]] = [{"role": "system", "content": system}]
        messages.extend(history)
        messages.append({"role": "user", "content": prompt})

        logger.debug("Ollama request: model=%s, messages=%d", model, len(messages))

        try:
            response = await client.chat(
                model=model,
                messages=messages,
                options={
                    "temperature": self.config.get("temperature", 0.7),
                    "num_predict": self.config.get("max_tokens", 2048),
                },
            )
            content: str = response["message"]["content"].strip()
        except Exception as exc:
            logger.error("Ollama request failed: %s", exc)
            return LLMResponse(content=f"[Error communicating with Ollama: {exc}]")

        # Try to detect a tool call embedded in the response
        tool_call = self._extract_tool_call(content)
        if tool_call:
            return LLMResponse(content="", tool_call=tool_call)
        return LLMResponse(content=content)

    @staticmethod
    def _extract_tool_call(text: str) -> dict[str, Any] | None:
        """Try to parse a JSON tool call from the model output."""
        stripped = text.strip()
        if stripped.startswith("{"):
            try:
                parsed = json.loads(stripped)
                if "tool" in parsed:
                    return parsed
            except json.JSONDecodeError:
                pass
        # Fallback: search within the text
        match = TOOL_CALL_PATTERN.search(stripped)
        if match:
            try:
                parsed = json.loads(match.group(0))
                if "tool" in parsed:
                    return parsed
            except json.JSONDecodeError:
                pass
        return None
