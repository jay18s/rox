"""Dummy LLM provider for testing – no external dependencies."""

from __future__ import annotations

import logging
import re
from typing import Any

from agent.llm.base import BaseLLM, LLMResponse

logger = logging.getLogger(__name__)

# Simple rule-based responses for demo purposes
RULES: list[tuple[str, str]] = [
    (r"\bhi\b|\bhello\b|\bhey\b", "Hello! I'm ZeroClaw, your AI agent. How can I help you today?"),
    (r"\bhelp\b", "I can chat, run commands in the workspace, and remember facts. Try 'list files' or 'remember my name is Alex'."),
    (r"\blist files?\b|\bshow files?\b", '{"tool": "run_command", "args": {"command": "dir", "args": ["."]}}'),
    (r"\bremember\b.+\bname is\b\s+(\w+)", None),  # handled specially
    (r"\bwhat.+my name\b", "Your name is stored in my memory. Check the facts!"),
    (r"\bbye\b|\bgoodbye\b", "Goodbye! Feel free to come back anytime."),
    (r"\bversion\b|\bwho are you\b", "I am ZeroClaw Agent v1.0, running in dummy LLM mode."),
]


class DummyProvider(BaseLLM):
    """Rule-based dummy LLM for Phase 1 testing."""

    async def generate(
        self,
        prompt: str,
        history: list[dict[str, str]],
        tools_description: str,
        system_message: str,
    ) -> LLMResponse:
        lower = prompt.lower()
        logger.debug("DummyProvider.generate called with prompt: %r", prompt[:80])

        for pattern, response in RULES:
            match = re.search(pattern, lower)
            if match:
                if response is None:
                    # Special: extract name from "remember my name is X"
                    name_match = re.search(r"name is\s+(\w+)", lower)
                    if name_match:
                        name = name_match.group(1).capitalize()
                        return LLMResponse(
                            content=f"Got it! I'll remember your name is {name}.",
                            tool_call=None,
                        )
                # Check if the response is a JSON tool call
                stripped = response.strip()
                if stripped.startswith("{"):
                    return LLMResponse(content="", tool_call=self._parse_tool(stripped))
                return LLMResponse(content=response)

        # Default echo-style response
        return LLMResponse(
            content=f"[Dummy LLM] You said: \"{prompt}\". (Configure a real LLM provider in config.toml for real responses.)"
        )

    @staticmethod
    def _parse_tool(raw: str) -> dict[str, Any] | None:
        import json
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return None
