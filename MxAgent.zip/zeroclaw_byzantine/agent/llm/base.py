"""Abstract base class for LLM providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class LLMResponse:
    """Structured response from an LLM provider."""

    def __init__(
        self,
        content: str,
        tool_call: dict[str, Any] | None = None,
    ) -> None:
        self.content = content
        self.tool_call = tool_call  # e.g. {"tool": "run_command", "args": {...}}

    def has_tool_call(self) -> bool:
        return self.tool_call is not None

    def __repr__(self) -> str:
        return f"LLMResponse(content={self.content!r}, tool_call={self.tool_call})"


class BaseLLM(ABC):
    """Abstract base for LLM providers."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config

    @abstractmethod
    async def generate(
        self,
        prompt: str,
        history: list[dict[str, str]],
        tools_description: str,
        system_message: str,
    ) -> LLMResponse:
        """Generate a response from the LLM.

        Args:
            prompt: The current user message.
            history: List of {"role": ..., "content": ...} dicts.
            tools_description: Text description of available tools.
            system_message: Injected system context (facts, instructions).

        Returns:
            LLMResponse with content and optional tool_call.
        """
        ...
