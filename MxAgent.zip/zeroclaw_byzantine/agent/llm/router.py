"""
LLM Router — mirrors OpenClaw's primary/fallback model chain.

Features:
  - Primary model first, fallbacks tried in order on 429 / error
  - Context compaction: trims history to fit within token budget
    (mode="safeguard" like OpenClaw's compaction.reserveTokensFloor)
  - Lazy provider instantiation
"""

from __future__ import annotations

import logging
from typing import Any

from agent.llm.base import BaseLLM, LLMResponse

logger = logging.getLogger(__name__)


def _make_provider(model_name: str, model_cfg: dict[str, Any]) -> BaseLLM:
    """Instantiate the right LLM class for a given model config."""
    provider = model_cfg.get("provider", "dummy").lower()

    if provider == "gemini":
        from agent.llm.gemini import GeminiProvider
        return GeminiProvider({**model_cfg, "model": model_name})

    elif provider == "ollama":
        from agent.llm.ollama import OllamaProvider
        return OllamaProvider({**model_cfg, "model": model_name})

    elif provider == "openai":
        from agent.llm.openai import OpenAIProvider
        return OpenAIProvider({**model_cfg, "model": model_name})

    elif provider == "cerebras":
        from agent.llm.cerebras import CerebrasProvider
        return CerebrasProvider({**model_cfg, "model": model_name})

    else:  # dummy / unknown
        from agent.llm.dummy import DummyProvider
        return DummyProvider(model_cfg)


class LLMRouter(BaseLLM):
    """
    Routes requests through primary → fallback models.
    Applies context compaction before each call.
    """

    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__(config)

        # Read the new structured config
        agent_cfg     = config.get("agent", {})
        model_cfg     = agent_cfg.get("model", {})
        models_detail = agent_cfg.get("models", {})
        context_cfg   = agent_cfg.get("context", {})
        compaction_cfg = context_cfg.get("compaction", {})

        self.primary_name: str       = model_cfg.get("primary", "gemini-2.0-flash")
        self.fallback_names: list[str] = model_cfg.get("fallbacks", ["dummy"])
        self.models_detail           = models_detail  # name → {provider, max_tokens, ...}

        # Context / compaction
        self.context_tokens: int  = int(context_cfg.get("context_tokens", 16000))
        self.reserve_tokens: int  = int(compaction_cfg.get("reserve_tokens", 6000))
        self.chars_per_token: int = int(context_cfg.get("chars_per_token", 4))
        self.compaction_mode: str = compaction_cfg.get("mode", "safeguard")

        # Available budget for history (chars)
        self._history_budget_chars: int = (
            (self.context_tokens - self.reserve_tokens) * self.chars_per_token
        )

        # Lazy-loaded provider instances
        self._providers: dict[str, BaseLLM] = {}

        logger.info(
            "LLMRouter: primary=%s  fallbacks=%s  context_tokens=%d  reserve=%d",
            self.primary_name, self.fallback_names,
            self.context_tokens, self.reserve_tokens,
        )

    def _get_provider(self, name: str) -> BaseLLM:
        if name not in self._providers:
            cfg = self.models_detail.get(name, {})
            if not cfg:
                # Fallback to flat [llm] config
                cfg = self.config.get("llm", {})
                cfg["model"] = name
            self._providers[name] = _make_provider(name, cfg)
        return self._providers[name]

    # ── Context compaction ────────────────────────────────────────────────────

    def _compact_history(
        self, history: list[dict[str, str]], system_message: str, prompt: str
    ) -> list[dict[str, str]]:
        """
        Trim history so total chars fit within budget.
        Mirrors OpenClaw compaction.mode="safeguard".

        Strategy: keep the MOST RECENT turns (pairs), dropping oldest first.
        Always preserves at least 2 turns (1 exchange) for coherence.
        """
        if self.compaction_mode == "off":
            return history

        # Chars already committed: system prompt + current prompt
        fixed_chars = len(system_message) + len(prompt)
        available   = self._history_budget_chars - fixed_chars

        if available <= 0:
            logger.warning("Context budget exhausted by system prompt alone — sending no history.")
            return []

        # Walk backwards through history, accumulating until budget is hit
        kept: list[dict[str, str]] = []
        used = 0
        for msg in reversed(history):
            msg_chars = len(msg.get("content", ""))
            if used + msg_chars > available and kept:
                break  # budget hit; at least 1 message kept
            kept.append(msg)
            used += msg_chars

        kept.reverse()

        dropped = len(history) - len(kept)
        if dropped:
            logger.info(
                "Compaction: dropped %d old turns to fit %d-token budget (%d chars used / %d available)",
                dropped, self.context_tokens, used, available,
            )
        else:
            logger.info(
                "Context OK: %d turns, %d chars (budget %d chars)",
                len(kept), used, available,
            )

        return kept

    # ── Primary → fallback call chain ─────────────────────────────────────────

    async def generate(
        self,
        prompt: str,
        history: list[dict[str, str]],
        tools_description: str,
        system_message: str,
    ) -> LLMResponse:
        # Compact history before every call
        compacted = self._compact_history(history, system_message, prompt)

        chain = [self.primary_name] + self.fallback_names
        logger.info("[ROUTER] Starting LLM chain: %s", " → ".join(chain))

        for idx, model_name in enumerate(chain):
            is_fallback = idx > 0
            if is_fallback:
                logger.warning("[ROUTER] Falling back to model: %s", model_name)

            try:
                provider = self._get_provider(model_name)
                logger.info("[ROUTER] Calling provider for model: %s", model_name)
                
                response = await provider.generate(
                    prompt=prompt,
                    history=compacted,
                    tools_description=tools_description,
                    system_message=system_message,
                )

                # Check if provider returned a rate-limit message (not an exception)
                if _is_rate_limit_message(response.content):
                    logger.warning(
                        "[ROUTER] Model %s returned rate-limit message, trying next fallback.", model_name
                    )
                    continue

                if is_fallback:
                    logger.info("[ROUTER] Fallback model %s succeeded.", model_name)
                else:
                    logger.info("[ROUTER] Primary model %s succeeded.", model_name)
                return response

            except Exception as exc:
                err = str(exc)
                if _is_rate_limit_error(err):
                    logger.warning("[ROUTER] Model %s: rate limit — %s", model_name, err[:80])
                    if idx < len(chain) - 1:
                        continue  # try next
                logger.error("[ROUTER] Model %s failed: %s", model_name, err)
                if idx == len(chain) - 1:
                    return LLMResponse(
                        content=f"All models failed. Last error from {model_name}: {err[:200]}"
                    )

        return LLMResponse(content="[Router] No model could handle this request.")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _is_rate_limit_error(err: str) -> bool:
    markers = ["429", "RESOURCE_EXHAUSTED", "rate limit", "quota", "RateLimitError"]
    return any(m.lower() in err.lower() for m in markers)


def _is_rate_limit_message(content: str) -> bool:
    markers = ["rate limit reached", "resource_exhausted", "quota"]
    return any(m in content.lower() for m in markers)
