"""Google Gemini LLM provider using the new google-genai library."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from typing import Any

from agent.llm.base import BaseLLM, LLMResponse

logger = logging.getLogger(__name__)

TOOL_CALL_PATTERN = re.compile(r"\{.*?\"tool\"\s*:.*?\}", re.DOTALL)


def _build_system_prompt(system_message: str, tools_description: str) -> str:
    parts = [system_message.strip()]
    if tools_description.strip():
        parts.append(
            "\n\n## Available Tools\n"
            + tools_description.strip()
            + "\n\nTo call a tool, output ONLY a raw JSON object on a single line like:\n"
            '{"tool": "run_command", "args": {"command": "dir", "args": ["."]}}\n'
            "Do NOT add markdown fences, explanation, or any text around the JSON when calling a tool.\n"
            "For regular responses, just output natural language text."
        )
    return "\n".join(parts)


class GeminiProvider(BaseLLM):
    """LLM provider backed by Google Gemini API (google-genai SDK)."""

    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__(config)
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is None:
            try:
                from google import genai
            except ImportError:
                raise RuntimeError(
                    "google-genai is not installed. "
                    "Run: pip install google-genai"
                )
            api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
            if not api_key:
                raise RuntimeError(
                    "Neither GEMINI_API_KEY nor GOOGLE_API_KEY environment variable is set.\n"
                    "Run:  set GEMINI_API_KEY=your_key_here"
                )
            self._client = genai.Client(api_key=api_key)
            logger.info("Gemini client initialised (model: %s)", self.config.get("model"))
        return self._client

    async def generate(
        self,
        prompt: str,
        history: list[dict[str, str]],
        tools_description: str,
        system_message: str,
    ) -> LLMResponse:
        from google.genai import types

        client = self._get_client()
        model_name: str = self.config.get("model", "gemini-2.5-pro")
        system = _build_system_prompt(system_message, tools_description)

        # Build contents list from history + current prompt
        contents: list[types.Content] = []
        for msg in history:
            role = "user" if msg["role"] == "user" else "model"
            contents.append(
                types.Content(role=role, parts=[types.Part(text=msg["content"])])
            )
        if prompt.strip():
            contents.append(
                types.Content(role="user", parts=[types.Part(text=prompt)])
            )

        gen_config = types.GenerateContentConfig(
            system_instruction=system,
            temperature=self.config.get("temperature", 0.7),
            max_output_tokens=self.config.get("max_tokens", 2048),
        )

        logger.info("[GEMINI] Request: model=%s, turns=%d, prompt_len=%d", model_name, len(contents), len(prompt))

        try:
            # SDK is synchronous — run in thread executor so we don't block the event loop
            # Add timeout to prevent hanging
            response = await asyncio.wait_for(
                asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: client.models.generate_content(
                        model=model_name,
                        contents=contents,
                        config=gen_config,
                    ),
                ),
                timeout=90.0  # 90 second timeout
            )
            content: str = response.text.strip()
            logger.info("[GEMINI] Response received: %d chars", len(content))
        except asyncio.TimeoutError:
            logger.error("[GEMINI] Request timed out after 90s")
            return LLMResponse(content="[Error: Gemini API request timed out. Please try again.]")
        except Exception as exc:
            logger.error("[GEMINI] Request failed: %s", exc)
            return LLMResponse(content=f"[Error communicating with Gemini: {exc}]")

        tool_call = self._extract_tool_call(content)
        if tool_call:
            logger.info("[GEMINI] Tool call detected: %s", tool_call.get("tool"))
            return LLMResponse(content="", tool_call=tool_call)
        return LLMResponse(content=content)

    @staticmethod
    def _extract_tool_call(text: str) -> dict[str, Any] | None:
        stripped = text.strip()
        # Strip markdown fences if the model wraps JSON anyway
        if stripped.startswith("```"):
            stripped = re.sub(r"^```(?:json)?\s*", "", stripped)
            stripped = re.sub(r"\s*```$", "", stripped).strip()

        if stripped.startswith("{"):
            try:
                parsed = json.loads(stripped)
                if "tool" in parsed:
                    return parsed
            except json.JSONDecodeError:
                pass

        match = TOOL_CALL_PATTERN.search(stripped)
        if match:
            try:
                parsed = json.loads(match.group(0))
                if "tool" in parsed:
                    return parsed
            except json.JSONDecodeError:
                pass
        return None
