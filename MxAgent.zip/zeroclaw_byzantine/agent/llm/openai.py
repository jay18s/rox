"""OpenAI LLM provider using the openai Python library."""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from agent.llm.base import BaseLLM, LLMResponse

logger = logging.getLogger(__name__)

TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "run_command",
            "description": "Execute a whitelisted shell command inside the sandbox workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "The command to run (must be in the allowlist).",
                    },
                    "args": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of arguments to pass to the command.",
                    },
                },
                "required": ["command"],
            },
        },
    }
]


class OpenAIProvider(BaseLLM):
    """LLM provider backed by OpenAI's API."""

    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__(config)
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is None:
            try:
                from openai import AsyncOpenAI
            except ImportError:
                raise RuntimeError("openai package not installed. Run: pip install openai")
            api_key = os.environ.get("OPENAI_API_KEY")
            if not api_key:
                raise RuntimeError("OPENAI_API_KEY environment variable not set.")
            self._client = AsyncOpenAI(api_key=api_key)
        return self._client

    async def generate(
        self,
        prompt: str,
        history: list[dict[str, str]],
        tools_description: str,
        system_message: str,
    ) -> LLMResponse:
        client = self._get_client()
        model = self.config.get("model", "gpt-4o-mini")

        system_content = system_message.strip()
        if tools_description.strip():
            system_content += (
                "\n\nYou have access to tools. Use the run_command function when you need "
                "to execute shell commands in the workspace."
            )

        messages: list[dict[str, str]] = [{"role": "system", "content": system_content}]
        messages.extend(history)
        messages.append({"role": "user", "content": prompt})

        logger.debug("OpenAI request: model=%s, messages=%d", model, len(messages))

        try:
            response = await client.chat.completions.create(
                model=model,
                messages=messages,
                tools=TOOLS_SCHEMA if tools_description else None,
                tool_choice="auto" if tools_description else None,
                temperature=self.config.get("temperature", 0.7),
                max_tokens=self.config.get("max_tokens", 2048),
            )
        except Exception as exc:
            logger.error("OpenAI request failed: %s", exc)
            return LLMResponse(content=f"[Error communicating with OpenAI: {exc}]")

        choice = response.choices[0]

        # Handle native function/tool calls
        if choice.finish_reason == "tool_calls" and choice.message.tool_calls:
            tc = choice.message.tool_calls[0]
            try:
                args = json.loads(tc.function.arguments)
            except json.JSONDecodeError:
                args = {}
            tool_call = {"tool": tc.function.name, "args": args}
            return LLMResponse(content="", tool_call=tool_call)

        return LLMResponse(content=choice.message.content or "")
