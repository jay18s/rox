"""Cerebras LLM provider (llama3.1-8b etc.) — fast free-tier inference."""

from __future__ import annotations

import json
import logging
import os
import re
from typing import Any

from agent.llm.base import BaseLLM, LLMResponse

logger = logging.getLogger(__name__)
TOOL_CALL_RE = re.compile(r"\{.*?\"tool\"\s*:.*?\}", re.DOTALL)


class CerebrasProvider(BaseLLM):
    """Cerebras API provider using OpenAI-compatible client."""

    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__(config)
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is None:
            try:
                from openai import AsyncOpenAI
            except ImportError:
                raise RuntimeError("openai package required for Cerebras. Run: pip install openai")
            api_key = os.environ.get("CEREBRAS_API_KEY")
            if not api_key:
                raise RuntimeError("CEREBRAS_API_KEY not set in .env")
            self._client = AsyncOpenAI(
                api_key=api_key,
                base_url="https://api.cerebras.ai/v1",
            )
        return self._client

    async def generate(
        self,
        prompt: str,
        history: list[dict[str, str]],
        tools_description: str,
        system_message: str,
    ) -> LLMResponse:
        client = self._get_client()
        model  = self.config.get("model", "llama3.1-8b")

        system = system_message.strip()
        if tools_description.strip():
            system += (
                "\n\nTo call a tool output ONLY JSON:\n"
                '{"tool": "run_command", "args": {...}}\n'
                "No surrounding text."
            )

        messages = [{"role": "system", "content": system}]
        messages.extend(history)
        if prompt.strip():
            messages.append({"role": "user", "content": prompt})

        try:
            resp = await client.chat.completions.create(
                model=model,
                messages=messages,
                max_tokens=self.config.get("max_tokens", 6000),
                temperature=self.config.get("temperature", 0.7),
            )
            content: str = resp.choices[0].message.content.strip()
        except Exception as exc:
            logger.error("Cerebras request failed: %s", exc)
            return LLMResponse(content=f"[Cerebras error: {exc}]")

        # Detect tool call
        stripped = content.strip()
        if stripped.startswith("```"):
            stripped = re.sub(r"^```(?:json)?\s*", "", stripped)
            stripped = re.sub(r"\s*```$", "", stripped).strip()
        if stripped.startswith("{"):
            try:
                parsed = json.loads(stripped)
                if "tool" in parsed:
                    return LLMResponse(content="", tool_call=parsed)
            except json.JSONDecodeError:
                pass
        m = TOOL_CALL_RE.search(content)
        if m:
            try:
                parsed = json.loads(m.group(0))
                if "tool" in parsed:
                    return LLMResponse(content="", tool_call=parsed)
            except json.JSONDecodeError:
                pass

        return LLMResponse(content=content)
