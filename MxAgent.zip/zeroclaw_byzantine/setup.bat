@echo off
echo ╔══════════════════════════════════════════════════════╗
echo ║         MxAgent Setup — ZeroClaw × Byzantine        ║
echo ╚══════════════════════════════════════════════════════╝
echo.

echo [1/7] Installing Python dependencies...
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo [ERROR] pip install failed. Check your Python installation.
    pause & exit /b 1
)

echo.
echo [2/7] Installing Ollama (Byzantine voting models)...
winget install Ollama.Ollama --silent 2>nul || echo    Ollama already installed or manual install required from ollama.com

echo.
echo [3/7] Configuring Ollama environment...
setx OLLAMA_MAX_LOADED_MODELS 3
setx OLLAMA_NUM_PARALLEL 3
setx OLLAMA_KEEP_ALIVE 300
echo    Set OLLAMA_MAX_LOADED_MODELS=3, OLLAMA_NUM_PARALLEL=3, OLLAMA_KEEP_ALIVE=300

echo.
echo [4/7] Pulling Byzantine voting models...
echo    This downloads ~5GB. Please wait...
ollama pull phi3:mini
ollama pull gemma2:2b
ollama pull qwen2.5:1.5b

echo.
echo [5/7] Creating directories...
mkdir workspace\cron 2>nul
mkdir workspace\memory 2>nul
mkdir logs 2>nul
echo    workspace\ and logs\ ready

echo.
echo [6/7] Copying config template...
if not exist .env (
    copy .env.example .env
    echo    Created .env — edit it to add your API keys
) else (
    echo    .env already exists — skipping
)

echo.
echo [7/7] Verifying Ollama connection...
curl -s http://localhost:11434/api/tags >nul 2>&1
if %errorlevel%==0 (
    echo    Ollama is running ✓
) else (
    echo    [WARN] Ollama not running yet.
    echo    Start Ollama from the system tray or run: ollama serve
)

echo.
echo ══════════════════════════════════════════════════════
echo  Setup complete!
echo.
echo  Next steps:
echo    1. Edit .env and add: GEMINI_API_KEY=your_key_here
echo    2. Edit config.toml if needed
echo    3. Run: python main.py doctor   (verify setup)
echo    4. Run: python main.py          (start agent)
echo ══════════════════════════════════════════════════════
echo.
pause
