"""
Daily Summary Script — runs once per day via HeartbeatScheduler.

This script is triggered by the heartbeat system when:
- The script is named "daily.py" (runs once per day)
- Heartbeat is enabled in config.toml

What it does:
1. Reviews MEMORY.md and recent daily logs
2. Generates a daily summary
3. Identifies pending tasks or follow-ups
4. Updates MEMORY.md with any new long-term memories
"""

from datetime import datetime, timedelta
from pathlib import Path

# This script runs in the agent's workspace context
# The heartbeat scheduler passes execution to the agent's tool executor

def generate_daily_summary(workspace_path: str = ".") -> str:
    """
    Generate a daily summary from memory files.
    
    Returns a summary string that the agent can use for proactive notifications.
    """
    workspace = Path(workspace_path)
    memory_dir = workspace / "memory"
    
    today = datetime.now()
    yesterday = today - timedelta(days=1)
    
    summary_parts = []
    
    # Read today's and yesterday's logs
    for date in [today, yesterday]:
        log_file = memory_dir / date.strftime("%Y-%m-%d.md")
        if log_file.exists():
            content = log_file.read_text(encoding="utf-8", errors="replace")
            summary_parts.append(f"## {date.strftime('%Y-%m-%d')}\n{content[:500]}")
    
    # Read MEMORY.md for long-term context
    memory_file = workspace / "MEMORY.md"
    if memory_file.exists():
        memory_content = memory_file.read_text(encoding="utf-8", errors="replace")
        summary_parts.append(f"## Long-term Memory\n{memory_content[:800]}")
    
    # Read SOUL.md for agent identity
    soul_file = workspace / "SOUL.md"
    if soul_file.exists():
        soul_content = soul_file.read_text(encoding="utf-8", errors="replace")
        summary_parts.append(f"## Agent Identity\n{soul_content[:300]}")
    
    return "\n\n".join(summary_parts) if summary_parts else "No memory files found."


def get_pending_tasks(workspace_path: str = ".") -> list[str]:
    """
    Extract pending tasks from memory files.
    
    Looks for markers like:
    - TODO: 
    - [ ] 
    - pending:
    - follow-up:
    """
    import re
    
    workspace = Path(workspace_path)
    memory_dir = workspace / "memory"
    tasks = []
    
    # Patterns for pending tasks
    patterns = [
        r"TODO:\s*(.+)",
        r"\[ \]\s*(.+)",
        r"pending:\s*(.+)",
        r"follow-up:\s*(.+)",
        r"next:\s*(.+)",
    ]
    
    # Check recent log files
    for log_file in memory_dir.glob("*.md"):
        if log_file.name == "MEMORY.md":
            continue
        try:
            content = log_file.read_text(encoding="utf-8", errors="replace")
            for pattern in patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                tasks.extend(matches)
        except Exception:
            pass
    
    return tasks[:10]  # Return max 10 tasks


# Entry point for the heartbeat executor
if __name__ == "__main__":
    print("=== Daily Summary Script ===")
    print(f"Generated at: {datetime.now().isoformat()}")
    print()
    
    summary = generate_daily_summary()
    print("### Recent Activity ###")
    print(summary)
    print()
    
    tasks = get_pending_tasks()
    if tasks:
        print("### Pending Tasks ###")
        for i, task in enumerate(tasks, 1):
            print(f"{i}. {task}")
    else:
        print("### No pending tasks found ###")
    
    print()
    print("=== End Daily Summary ===")
