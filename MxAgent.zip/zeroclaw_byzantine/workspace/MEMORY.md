# Long-Term Memory

This file contains curated facts, decisions, patterns, and learnings
that should persist across all sessions.

## User Preferences

## Known Issues & Solutions

## Recurring Tasks
(none yet)

## Learnings
(none yet)
- If a user states a file exists but `list_files` does not show it, clearly communicate what was found and ask for clarification on the file's name and location.
- When a user simply says "Hi", a reasonable default action is to list available files and prompt for a task.
