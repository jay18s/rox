#!/usr/bin/env python3
"""
MxAgent — ZeroClaw × Byzantine Multi-Agent System
Main entry point.

Usage:
    python main.py              Start interactive CLI
    python main.py doctor       Health check
    python main.py --task "X"   Run single task
    python main.py --config x.toml  Use alternate config
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys
import uuid
from pathlib import Path
from typing import Any

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))


# ── .env loader ───────────────────────────────────────────────────────────────

def load_dotenv(env_path: str = ".env") -> None:
    p = Path(env_path)
    if not p.exists():
        return
    loaded = []
    with open(p, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key   = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value
                loaded.append(key)
    if loaded:
        print(f"[.env] Loaded: {', '.join(loaded)}")


# ── Config loader ─────────────────────────────────────────────────────────────

def load_config(path: str = "config.toml") -> dict[str, Any]:
    config_path = Path(path)
    if not config_path.exists():
        print(f"[ERROR] Config not found: {config_path.resolve()}")
        sys.exit(1)
    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore
        except ImportError:
            print("[ERROR] tomli not installed. Run: pip install tomli")
            sys.exit(1)
    with open(config_path, "rb") as fh:
        return tomllib.load(fh)


# ── Logging setup ─────────────────────────────────────────────────────────────

def setup_logging(config: dict[str, Any]) -> None:
    agent_cfg = config.get("agent", {})
    level     = getattr(logging, agent_cfg.get("log_level", "INFO").upper(), logging.INFO)
    log_file  = agent_cfg.get("log_file", "logs/agent.log")
    Path(log_file).parent.mkdir(parents=True, exist_ok=True)
    fmt = "%(asctime)s [%(levelname)s] %(name)s — %(message)s"
    logging.basicConfig(
        level=level, format=fmt,
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_file, encoding="utf-8"),
        ],
    )
    for noisy in ("httpx", "telegram", "apscheduler", "hpack"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


# ── Factory helpers ───────────────────────────────────────────────────────────

def create_llm(config: dict[str, Any]) -> Any:
    from agent.llm.router import LLMRouter
    agent_cfg = config.get("agent", {})
    if "model" in agent_cfg and "models" in agent_cfg:
        return LLMRouter(config)
    llm_cfg  = config.get("llm", {})
    provider = llm_cfg.get("provider", "dummy")
    model    = llm_cfg.get("model", "gemini-2.0-flash")
    synthetic = {
        "agent": {
            "model":   {"primary": model, "fallbacks": ["dummy"]},
            "models":  {model: {**llm_cfg, "provider": provider}},
            "context": {"context_tokens": 16000, "chars_per_token": 4,
                        "compaction": {"mode": "safeguard", "reserve_tokens": 6000}},
        },
        "llm": llm_cfg,
    }
    return LLMRouter(synthetic)


def create_memory(config: dict[str, Any]) -> Any:
    from agent.memory.manager import MemoryManager
    mem_cfg = config.get("agent", {}).get("memory", config.get("memory", {}))
    return MemoryManager(mem_cfg)


def create_tool_executor(config: dict[str, Any]) -> Any:
    from agent.tools.executor import ToolExecutor
    tools_cfg = config.get("agent", {}).get("tools", config.get("tools", {}))
    executor  = ToolExecutor(tools_cfg)
    executor.setup()
    return executor


def create_workspace_memory(config: dict[str, Any]) -> Any:
    from agent.memory.workspace import WorkspaceMemory
    ws_cfg = config.get("agent", {}).get("tools", {})
    ws_dir = ws_cfg.get("workspace", "workspace")
    return WorkspaceMemory(ws_dir)


def create_byzantine_engine(config: dict[str, Any]) -> Any | None:
    """Create ByzantineDecisionEngine if enabled and Ollama is reachable."""
    byz_cfg = config.get("agent", {}).get("byzantine", {})
    if not byz_cfg.get("enabled", True):
        print("[Byzantine] Disabled in config.")
        return None
    try:
        import requests
        host = byz_cfg.get("voting_models", {}).get("ollama_host", "http://localhost:11434")
        resp = requests.get(f"{host}/api/tags", timeout=3)
        if resp.status_code != 200:
            raise ConnectionError("Non-200 response")
        print(f"[Byzantine] Ollama reachable at {host} ✓")
    except Exception as exc:
        print(f"[Byzantine] Ollama not reachable ({exc}). Byzantine disabled.")
        print("  → Start Ollama and run: ollama pull llama3.1:8b qwen2.5:7b")
        return None
    from agent.byzantine.engine import ByzantineDecisionEngine
    return ByzantineDecisionEngine(config=byz_cfg)


def create_channels(config: dict[str, Any], queue: asyncio.Queue) -> dict:
    channels: dict = {}
    agent_cfg = config.get("agent", {})

    # CLI always enabled
    try:
        from agent.channels.cli import CLIChannel
        channels["cli"] = CLIChannel({}, queue)
    except Exception as exc:
        print(f"[WARN] CLI channel failed: {exc}")

    # Telegram optional
    tg_cfg = agent_cfg.get("telegram", config.get("telegram", {}))
    if tg_cfg.get("enabled", False):
        try:
            from agent.channels.telegram import TelegramChannel
            channels["telegram"] = TelegramChannel(tg_cfg, queue)
        except Exception as exc:
            print(f"[WARN] Telegram channel failed: {exc}")

    return channels


# ── Doctor (health check) ─────────────────────────────────────────────────────

async def run_doctor(config: dict[str, Any]) -> None:
    print("\n🔍 MxAgent Health Check\n" + "=" * 50)

    # Ollama
    try:
        import requests
        byz_cfg  = config.get("agent", {}).get("byzantine", {})
        host     = byz_cfg.get("voting_models", {}).get("ollama_host", "http://localhost:11434")
        resp     = requests.get(f"{host}/api/tags", timeout=3)
        models   = [m["name"] for m in resp.json().get("models", [])]
        required = ["llama3.1:8b", "qwen2.5:7b"]
        for m in required:
            status = "✅" if any(m in model for model in models) else "❌ MISSING"
            print(f"  Ollama {m}: {status}")
    except Exception as exc:
        print(f"  Ollama: ❌ Not reachable ({exc})")
        print("    → Install: winget install Ollama.Ollama")
        print("    → Pull:    ollama pull llama3.1:8b qwen2.5:7b")

    # LangGraph
    try:
        import langgraph
        from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver
        print(f"  LangGraph: ✅ {langgraph.__version__}")
    except ImportError:
        print("  LangGraph: ❌  pip install langgraph>=0.2.28")

    # Main LLM
    agent_cfg = config.get("agent", {})
    primary   = agent_cfg.get("model", {}).get("primary", "unknown")
    print(f"  Primary LLM: {primary}")

    # Workspace
    ws = Path("workspace")
    print(f"  Workspace: {'✅' if ws.exists() else '❌ missing'} {ws.resolve()}")

    # DB files
    for db in ("memory.db", "byzantine_checkpoints.db"):
        p = Path(db)
        print(f"  {db}: {'✅ exists' if p.exists() else '⬜ will be created on first run'}")

    print("\n" + "=" * 50)


# ── Pretty print ──────────────────────────────────────────────────────────────

def print_banner():
    print("""
╔══════════════════════════════════════════════════════════════════╗
║          🔱 MxAgent — ZeroClaw × Byzantine  🔱                   ║
║                                                                  ║
║  Memory: SOUL.md | Facts | RAG | Summary | Self-Review           ║
║  Safety: Alpha(llama3.1) + Beta(llama3.1) + Gamma(qwen2.5) Voting ║
║  HITL:   /approve <id> | /reject <id> | /pending <id>            ║
╚══════════════════════════════════════════════════════════════════╝
""")


# ── Main async runner ─────────────────────────────────────────────────────────

async def main_async(config: dict[str, Any], args: argparse.Namespace) -> None:
    # Build components
    llm              = create_llm(config)
    memory           = create_memory(config)
    tool_executor    = create_tool_executor(config)
    workspace_memory = create_workspace_memory(config)

    memory.setup()

    agent_cfg = config.get("agent", {})
    engine_cfg = {
        "tool_loop_max":         agent_cfg.get("tool_loop_max", 10),
        "summarise_every_turns": agent_cfg.get("memory", {}).get("summarise_every_turns", 6),
        "self_review":           agent_cfg.get("self_review", True),
        "enable_react":          agent_cfg.get("enable_react", True),
        "llm_fact_extraction":   agent_cfg.get("llm_fact_extraction", False),
        "byzantine_enabled":     agent_cfg.get("byzantine", {}).get("enabled", True),
    }

    from agent.engine import CoreEngine
    engine = CoreEngine(
        llm=llm, memory=memory, tool_executor=tool_executor,
        workspace_memory=workspace_memory, config=engine_cfg,
    )

    # Wire Byzantine engine
    byzantine = create_byzantine_engine(config)
    engine.byzantine = byzantine

    # Wire sub-agent orchestrator
    try:
        from agent.subagents.orchestrator import SubAgentOrchestrator
        orchestrator = SubAgentOrchestrator(config)
        tool_executor._engine       = engine
        tool_executor._orchestrator = orchestrator
    except Exception as exc:
        logging.getLogger("main").warning("Sub-agents unavailable: %s", exc)

    # Single task mode
    if args.task:
        from agent.engine import CoreEngine as _CE
        result = await engine.process(
            message={"text": args.task},
            session_history=[],
            user_id="cli",
            channel="cli",
        )
        print(f"\n{result}\n")
        return

    # Interactive loop
    print_banner()

    queue    = asyncio.Queue()
    channels = create_channels(config, queue)

    from agent.gateway import MessageGateway
    gw_cfg = {
        "session_max_length":   agent_cfg.get("memory", {}).get("session_max_length", 40),
        "max_history_turns":    agent_cfg.get("context", {}).get("max_history_turns", 6),
        "min_reply_gap_seconds": agent_cfg.get("concurrency", {}).get("min_reply_gap_seconds", 1.0),
        "llm_concurrency":      agent_cfg.get("concurrency", {}).get("max_concurrent", 1),
    }
    gateway = MessageGateway(queue=queue, engine=engine, channels=channels, config=gw_cfg)

    # Heartbeat
    from agent.heartbeat import HeartbeatScheduler
    heartbeat = HeartbeatScheduler(config=config, engine=engine, channels=channels)

    # Start channels
    tasks = [asyncio.create_task(gateway.run())]
    if "cli" in channels:
        tasks.append(asyncio.create_task(channels["cli"].start()))
    if "telegram" in channels:
        tasks.append(asyncio.create_task(channels["telegram"].start()))
    tasks.append(asyncio.create_task(heartbeat.run()))

    print("Agent running. Type your message below (Ctrl+C to quit).\n")
    print("HITL commands: /approve <thread_id> | /reject <thread_id> [reason] | /pending <thread_id>\n")

    try:
        await asyncio.gather(*tasks, return_exceptions=True)
    except (KeyboardInterrupt, asyncio.CancelledError):
        print("\nShutting down...")
    finally:
        gateway.stop()
        for task in tasks:
            task.cancel()


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="MxAgent — ZeroClaw × Byzantine")
    parser.add_argument("command", nargs="?", help="doctor | (leave empty for interactive)")
    parser.add_argument("--config", default="config.toml", help="Config file path")
    parser.add_argument("--task",   default="", help="Run single task and exit")
    args = parser.parse_args()

    load_dotenv()
    config = load_config(args.config)
    setup_logging(config)

    if args.command == "doctor":
        asyncio.run(run_doctor(config))
        return

    asyncio.run(main_async(config, args))


if __name__ == "__main__":
    main()
