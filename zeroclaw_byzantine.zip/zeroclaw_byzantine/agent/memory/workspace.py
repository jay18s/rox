"""
Workspace Memory — markdown file-based memory system mirroring OpenClaw.

Files maintained in agent workspace:
  SOUL.md         — agent identity, personality, name, style (self-modifiable)
  MEMORY.md       — curated long-term facts, decisions, learnings (append-only)
  memory/YYYY-MM-DD.md  — daily running log of what happened today

These are injected into every system prompt alongside SQLite facts.
The agent can write to these files via tools — so it can improve itself.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_SOUL_DEFAULT = """\
# Agent Identity

## Name
ZeroClaw

## Personality
I am ZeroClaw — a capable, autonomous AI agent. I am:
- Direct and efficient: I act, not just describe what I would do.
- Self-improving: I learn from errors and update my memory.
- Honest: I tell the user when something fails and why.
- Persistent: I retry failed tasks with a different approach.

## Communication Style
- Concise replies for simple questions.
- Step-by-step narration for complex tasks so the user follows along.
- Always confirm what I actually did (not what I plan to do).

## Core Behaviours
- After completing a task, I briefly review if it was done correctly.
- If I make an error, I acknowledge it, fix it, and note it in MEMORY.md.
- I proactively suggest next steps when a task opens up follow-on work.
"""

_MEMORY_DEFAULT = """\
# Long-Term Memory

This file contains curated facts, decisions, patterns, and learnings
that should persist across all sessions.

## User Preferences
(none yet)

## Known Issues & Solutions
(none yet)

## Recurring Tasks
(none yet)

## Learnings
(none yet)
"""


class WorkspaceMemory:
    """Manages markdown-based memory files in the agent workspace."""

    def __init__(self, workspace: Path | str) -> None:
        self.workspace = Path(workspace) if isinstance(workspace, str) else workspace
        self.soul_path   = self.workspace / "SOUL.md"
        self.memory_path = self.workspace / "MEMORY.md"
        self.daily_dir   = self.workspace / "memory"

    def setup(self) -> None:
        """Create default files if they don't exist."""
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.daily_dir.mkdir(exist_ok=True)

        if not self.soul_path.exists():
            self.soul_path.write_text(_SOUL_DEFAULT, encoding="utf-8")
            logger.info("Created SOUL.md")

        if not self.memory_path.exists():
            self.memory_path.write_text(_MEMORY_DEFAULT, encoding="utf-8")
            logger.info("Created MEMORY.md")

    # ── Readers ───────────────────────────────────────────────────────────────

    def read_soul(self) -> str:
        try:
            return self.soul_path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return _SOUL_DEFAULT

    def read_memory(self) -> str:
        try:
            return self.memory_path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return _MEMORY_DEFAULT

    def read_today_log(self) -> str:
        path = self._today_log_path()
        try:
            return path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return "(no entries today yet)"

    def build_context_block(self) -> str:
        """Return all workspace memory formatted for injection into system prompt."""
        soul   = self.read_soul()
        memory = self.read_memory()
        today  = self.read_today_log()
        date   = datetime.now().strftime("%Y-%m-%d %H:%M")
        return f"""\
## AGENT SOUL (Identity & Personality)
{soul}

## LONG-TERM MEMORY
{memory}

## TODAY'S LOG ({date})
{today}
"""

    # ── Writers ───────────────────────────────────────────────────────────────

    def append_daily_log(self, entry: str) -> None:
        """Append a timestamped entry to today's log file."""
        path = self._today_log_path()
        ts   = datetime.now().strftime("%H:%M")
        line = f"\n### {ts}\n{entry.strip()}\n"
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(line)

    def append_memory(self, section: str, entry: str) -> None:
        """Append an entry under a section in MEMORY.md."""
        try:
            content = self.memory_path.read_text(encoding="utf-8")
            marker  = f"## {section}"
            if marker in content:
                content = content.replace(
                    f"(none yet)\n",
                    "",
                    1,
                )
                insert_at = content.find(marker) + len(marker) + 1
                # Find end of this section (next ## or EOF)
                next_section = content.find("\n## ", insert_at)
                if next_section == -1:
                    content = content.rstrip() + f"\n- {entry}\n"
                else:
                    content = (
                        content[:next_section].rstrip()
                        + f"\n- {entry}"
                        + content[next_section:]
                    )
            else:
                content += f"\n## {section}\n- {entry}\n"
            self.memory_path.write_text(content, encoding="utf-8")
            logger.info("Appended to MEMORY.md [%s]: %s", section, entry[:60])
        except Exception as exc:
            logger.warning("Failed to append to MEMORY.md: %s", exc)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _today_log_path(self) -> Path:
        date = datetime.now().strftime("%Y-%m-%d")
        return self.daily_dir / f"{date}.md"
