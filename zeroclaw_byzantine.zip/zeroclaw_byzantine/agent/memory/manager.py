"""
Memory Manager — layered storage for ZeroClaw agent.
Simplified synchronous version for reliability.
"""

from __future__ import annotations

import logging
import sqlite3
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_CREATE_FACTS = """
CREATE TABLE IF NOT EXISTS facts (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id   TEXT    NOT NULL,
    key       TEXT    NOT NULL,
    value     TEXT    NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, key) ON CONFLICT REPLACE
);
"""

_CREATE_CONVERSATIONS = """
CREATE TABLE IF NOT EXISTS conversations (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id   TEXT    NOT NULL,
    role      TEXT    NOT NULL,
    content   TEXT    NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);
"""

_CREATE_SUMMARIES = """
CREATE TABLE IF NOT EXISTS conversation_summaries (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      TEXT    NOT NULL,
    channel      TEXT    NOT NULL DEFAULT 'default',
    summary      TEXT    NOT NULL,
    turn_count   INTEGER NOT NULL DEFAULT 0,
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, channel) ON CONFLICT REPLACE
);
"""


class MemoryManager:
    """Synchronous memory manager - fast and reliable."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.db_path = Path(config.get("db_path", "memory.db"))
        self.store_conversations: bool = config.get("store_conversations", True)
        self._conn: sqlite3.Connection | None = None
        self._vector_store = None
        self._vector_config = config.get("vector", {})

    def setup(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL;")
        self._conn.execute(_CREATE_FACTS)
        self._conn.execute(_CREATE_CONVERSATIONS)
        self._conn.execute(_CREATE_SUMMARIES)
        self._conn.commit()
        logger.info("Memory DB ready at: %s", self.db_path)

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    # ── Facts ─────────────────────────────────────────────────────────────────

    async def store_fact(self, user_id: str, key: str, value: str) -> None:
        assert self._conn
        self._conn.execute(
            "INSERT OR REPLACE INTO facts(user_id, key, value) VALUES (?, ?, ?)",
            (user_id, key, value),
        )
        self._conn.commit()

    async def get_fact(self, user_id: str, key: str) -> str | None:
        assert self._conn
        row = self._conn.execute(
            "SELECT value FROM facts WHERE user_id=? AND key=?", (user_id, key)
        ).fetchone()
        return row["value"] if row else None

    async def get_all_facts(self, user_id: str) -> dict[str, str]:
        assert self._conn
        rows = self._conn.execute(
            "SELECT key, value FROM facts WHERE user_id=?", (user_id,)
        ).fetchall()
        return {r["key"]: r["value"] for r in rows}

    # ── Summaries ─────────────────────────────────────────────────────────────

    async def get_summary(self, user_id: str, channel: str = "default") -> str | None:
        assert self._conn
        row = self._conn.execute(
            "SELECT summary FROM conversation_summaries WHERE user_id=? AND channel=?",
            (user_id, channel),
        ).fetchone()
        return row["summary"] if row else None

    async def store_summary(
        self, user_id: str, channel: str, summary: str, turn_count: int
    ) -> None:
        assert self._conn
        self._conn.execute(
            """
            INSERT OR REPLACE INTO conversation_summaries
                (user_id, channel, summary, turn_count, last_updated)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            """,
            (user_id, channel, summary, turn_count),
        )
        self._conn.commit()
        logger.info("Summary updated for %s/%s (%d turns)", user_id, channel, turn_count)

    # ── Conversations ─────────────────────────────────────────────────────────

    async def store_conversation(self, user_id: str, role: str, content: str) -> int:
        if not self.store_conversations:
            return -1
        assert self._conn
        cursor = self._conn.execute(
            "INSERT INTO conversations(user_id, role, content) VALUES (?, ?, ?)",
            (user_id, role, content),
        )
        self._conn.commit()
        return cursor.lastrowid or -1

    async def get_recent_conversations(
        self, user_id: str, limit: int = 20
    ) -> list[dict[str, str]]:
        assert self._conn
        rows = self._conn.execute(
            """
            SELECT role, content FROM conversations
            WHERE user_id=? ORDER BY timestamp DESC LIMIT ?
            """,
            (user_id, limit),
        ).fetchall()
        return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]

    async def get_conversation_turn_count(self, user_id: str) -> int:
        assert self._conn
        row = self._conn.execute(
            "SELECT COUNT(*) as cnt FROM conversations WHERE user_id=?", (user_id,)
        ).fetchone()
        return row["cnt"] if row else 0

    # ── RAG ───────────────────────────────────────────────────────────────────

    async def get_rag_context(
        self, user_id: str, query: str, max_results: int = 5
    ) -> str:
        return ""  # Not implemented