"""
Core Engine — ZeroClaw + Byzantine Integrated Agentic Loop.

DUAL-PATH DECISION SYSTEM:
  FAST PATH  — conversational/read-only tools: single LLM, no voting
  SAFE PATH  — write/execute tools: 3-agent Byzantine consensus before execution

Integration:
  When the main LLM proposes a tool call, _requires_consensus() checks the tool name.
  Low-risk tools (read_file, list_files, calculate, web_search) skip Byzantine.
  Medium/high-risk tools (run_python, write_file, run_command, spawn_agent) go through
  ByzantineDecisionEngine.decide(), which injects ZeroClaw memory context into each voter.

ZeroClaw patterns preserved:
  SOUL.md / MEMORY.md — agent identity, persistent learnings
  self-review         — LLM grades output after every task
  daily log           — YYYY-MM-DD.md running entry
  hook bus            — before/after tool call, session_start, agent_end
  memory flush        — summary compaction trigger
  ReAct pattern       — Thought → Action → Observation
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from datetime import datetime
from typing import Any

from agent.llm.base import BaseLLM, LLMResponse
from agent.memory.manager import MemoryManager
from agent.memory.workspace import WorkspaceMemory
from agent.tools.executor import ToolExecutor
from agent.hooks import bus as hook_bus

logger = logging.getLogger(__name__)

# ── Tools that bypass Byzantine consensus (fast path) ─────────────────────────
FAST_PATH_TOOLS = {"read_file", "list_files", "calculate", "web_search"}

# ── Fact patterns (regex fallback) ────────────────────────────────────────────
_FACT_PATTERNS: list[tuple[re.Pattern, str | None]] = [
    (re.compile(r"remember\s+(?:that\s+)?my\s+name\s+is\s+(\w+)", re.I), "name"),
    (re.compile(r"my\s+name\s+is\s+(\w+)", re.I), "name"),
    (re.compile(r"i\s+(?:am|'m)\s+(\w+)", re.I), "name"),
    (re.compile(r"remember\s+(?:that\s+)?i\s+(?:am|live in|work at|like)\s+(.+)", re.I), None),
    (re.compile(r"my\s+(\w+)\s+is\s+(.+)", re.I), None),
]

_FACT_EXTRACTION_PROMPT = """\
Analyze this user message for important facts to remember about the user.
Extract: name, preferences, goals, location, occupation, relationships, interests, constraints.

USER MESSAGE: {text}

Respond with ONLY a JSON object (no markdown, no explanation):
{{"facts": [{{"key": "lowercase_key", "value": "extracted value", "category": "preference|goal|context|identity"}}]}}

If no facts worth remembering: {{"facts": []}}

Rules:
- Keys: lowercase, underscore-separated (e.g. "favorite_color", "current_project")
- Only extract explicit or strongly implied facts — not assumptions
- Ignore temporary states ("I'm tired today")
- Category: preference | goal | context | identity"""

_SUMMARISE_PROMPT = """\
Summarise the conversation below in max 200 words. Third-person.
Preserve facts, tasks, errors, decisions, outcomes.
{turns}
Summary:"""

_REVIEW_PROMPT = """\
You just completed a task. Review your own performance.

USER REQUEST: {request}
YOUR RESPONSE: {response}
TOOLS USED: {tools_used}

Answer briefly:
1. Did you fully complete what was asked? (yes/partial/no)
2. Were there any errors or retries?
3. Is there anything to remember for next time? (or "nothing")
4. Suggested improvement: (or "none")

Format:
COMPLETED: yes|partial|no
ERRORS: <summary or none>
REMEMBER: <fact to store or nothing>
IMPROVEMENT: <suggestion or none>"""

_REACT_SYSTEM_TEMPLATE = """\
{soul_and_memory}

## SESSION CONTEXT
User: {user_id} | Channel: {channel} | Time: {now}

## SQLite FACTS ABOUT {user_id}
{facts_section}

## ROLLING CONVERSATION SUMMARY
{summary_section}

{rag_context}

## REACT REASONING FRAMEWORK
Follow this pattern for every response:

1. **Thought**: Reason about what needs to be done.
2. **Action**: If a tool is needed, call it. Otherwise proceed to final answer.
3. **Observation**: After each tool call, analyze the result.
4. **Final Answer**: Only after reasoning through the problem.

Format internal reasoning as:
```
Thought: [your reasoning]
Action: [tool call or "none" if ready to answer]
```
When you have a final answer, output it directly.
"""

_SYSTEM_TEMPLATE = """\
{soul_and_memory}

## SESSION CONTEXT
User: {user_id} | Channel: {channel} | Time: {now}

## SQLite FACTS ABOUT {user_id}
{facts_section}

## ROLLING CONVERSATION SUMMARY
{summary_section}

{rag_context}
"""


def _facts_section(facts: dict[str, str]) -> str:
    return "\n".join(f"  • {k}: {v}" for k, v in facts.items()) or "None stored yet."


def _summary_section(s: str | None) -> str:
    return s or "No previous summary — new or fresh session."


def _rag_section(rag: str) -> str:
    return rag if rag else ""


def _fmt(tc: dict) -> str:
    try:
        return json.dumps(tc, indent=2)
    except Exception:
        return str(tc)


def _parse_review(raw: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in raw.splitlines():
        if ":" in line:
            key, _, val = line.partition(":")
            result[key.strip().upper()] = val.strip()
    return result


class CoreEngine:
    """
    ZeroClaw-Byzantine integrated agentic loop.

    FAST PATH:  conversational messages + read-only tools → single LLM, no voting
    SAFE PATH:  write/execute tool calls → ByzantineDecisionEngine consensus
    """

    def __init__(
        self,
        llm: BaseLLM,
        memory: MemoryManager,
        tool_executor: ToolExecutor,
        workspace_memory: WorkspaceMemory,
        config: dict[str, Any],
    ) -> None:
        self.llm = llm
        self.memory = memory
        self.tool_executor = tool_executor
        self.ws_memory = workspace_memory
        self.max_iterations = int(config.get("tool_loop_max", 10))
        self.summarise_every = int(config.get("summarise_every_turns", 6))
        self.enable_review = config.get("self_review", True)
        self.enable_react = config.get("enable_react", True)
        self.llm_fact_extract = config.get("llm_fact_extraction", False)
        self._seen_sessions: set[str] = set()

        # Byzantine decision engine (injected by main.py, optional)
        self.byzantine: Any = None
        self._byzantine_enabled: bool = config.get("byzantine_enabled", True)

    # ── Public ────────────────────────────────────────────────────────────────

    async def process(
        self,
        message: dict[str, Any],
        session_history: list[dict[str, str]],
        user_id: str,
        channel: str,
    ) -> str:
        text = message["text"]
        session_key = f"{channel}:{user_id}"

        if session_key not in self._seen_sessions:
            self._seen_sessions.add(session_key)
            await hook_bus.fire("session_start", {
                "session_key": session_key, "user_id": user_id, "channel": channel
            })

        logger.info("Processing [%s/%s]: %r", channel, user_id, text[:60])

        # Step 1: Fact extraction (with timeout)
        logger.info("[ENGINE] Step 1: Starting fact extraction...")
        try:
            logger.debug("[ENGINE] Starting fact extraction...")
            await asyncio.wait_for(self._auto_extract_facts(user_id, text), timeout=10.0)
            logger.debug("[ENGINE] Fact extraction done.")
        except asyncio.TimeoutError:
            logger.warning("Fact extraction timed out, skipping")
        except Exception as exc:
            logger.warning("Fact extraction error (non-critical): %s", exc)
        logger.info("[ENGINE] Step 1: Fact extraction done.")

        # Step 2: Summary update check (with timeout)
        logger.debug("[ENGINE] Checking summary update...")
        try:
            await asyncio.wait_for(self._maybe_update_summary(user_id, channel), timeout=10.0)
        except asyncio.TimeoutError:
            logger.warning("Summary update timed out, skipping")
        except Exception as exc:
            logger.warning("Summary update error (non-critical): %s", exc)
        logger.debug("[ENGINE] Summary check done.")

        # Step 3: Build context (with timeouts)
        logger.debug("[ENGINE] Building context...")
        try:
            facts = await asyncio.wait_for(self.memory.get_all_facts(user_id), timeout=5.0)
        except asyncio.TimeoutError:
            logger.warning("get_all_facts timed out")
            facts = {}
        logger.debug("[ENGINE] Got facts: %d", len(facts))

        try:
            summary = await asyncio.wait_for(self.memory.get_summary(user_id, channel), timeout=5.0)
        except asyncio.TimeoutError:
            logger.warning("get_summary timed out")
            summary = None
        logger.debug("[ENGINE] Got summary.")

        soul_block = self.ws_memory.build_context_block()
        logger.debug("[ENGINE] Got soul block.")

        try:
            rag_context = await asyncio.wait_for(
                self.memory.get_rag_context(user_id, text, max_results=5), timeout=5.0
            )
        except asyncio.TimeoutError:
            logger.warning("get_rag_context timed out")
            rag_context = ""
        logger.debug("[ENGINE] Context building complete.")

        template = _REACT_SYSTEM_TEMPLATE if self.enable_react else _SYSTEM_TEMPLATE
        system_message = template.format(
            soul_and_memory = soul_block,
            user_id         = user_id,
            channel         = channel,
            now             = datetime.now().strftime("%Y-%m-%d %H:%M"),
            facts_section   = _facts_section(facts),
            summary_section = _summary_section(summary),
            rag_context     = _rag_section(rag_context),
        )

        # Build memory context string for Byzantine voters
        memory_context = "\n".join([
            soul_block,
            f"USER FACTS:\n{_facts_section(facts)}",
            f"SUMMARY: {summary or 'None'}",
        ])

        tools_desc = self.tool_executor.get_tools_description()
        working_history = list(session_history)
        current_prompt = text
        final_answer = ""
        tools_used: list[str] = []
        thread_id = f"{channel}:{user_id}"

        # ── Agentic loop ──────────────────────────────────────────────────────
        logger.info("[ENGINE] Starting LLM agentic loop...")
        for iteration in range(self.max_iterations):
            logger.info("[ENGINE] Calling LLM (iteration %d)...", iteration)
            try:
                llm_response: LLMResponse = await asyncio.wait_for(
                    self.llm.generate(
                        prompt=current_prompt,
                        history=working_history,
                        tools_description=tools_desc,
                        system_message=system_message,
                    ),
                    timeout=90.0
                )
            except asyncio.TimeoutError:
                logger.error("LLM call timed out after 90s")
                final_answer = "Sorry, the LLM request timed out. Please try again."
                break
            logger.info("[ENGINE] LLM response received.")

            if not llm_response.has_tool_call():
                final_answer = llm_response.content
                break

            tool_call = llm_response.tool_call
            tool_name = tool_call.get("tool", "?")
            tools_used.append(tool_name)

            await hook_bus.fire("before_tool_call", {
                "tool": tool_name, "args": tool_call.get("args", {}),
                "user_id": user_id, "iteration": iteration,
            })

            # ── DUAL-PATH DECISION ─────────────────────────────────────────
            tool_result = await self._execute_with_routing(
                tool_call=tool_call,
                user_input=text,
                memory_context=memory_context,
                thread_id=thread_id,
                tools_used=tools_used,
            )

            logger.info("Tool[%d] %s → %s", iteration, tool_name, tool_result[:120])

            await hook_bus.fire("after_tool_call", {
                "tool": tool_name, "result": tool_result,
                "user_id": user_id, "iteration": iteration,
            })

            working_history.append({
                "role": "assistant",
                "content": f"[Tool: {tool_name}]\n{_fmt(tool_call)}",
            })
            working_history.append({
                "role": "user",
                "content": (
                    f"[Result: {tool_name}]\n{tool_result}\n\n"
                    "Continue. If done, summarise. If error, fix it."
                ),
            })
            current_prompt = ""

        else:
            final_answer = (
                f"Task ran for {self.max_iterations} iterations. "
                "Last tool result:\n\n"
                + (working_history[-1]["content"] if working_history else "(none)")
            )

        # ── Self-review ───────────────────────────────────────────────────────
        if self.enable_review and tools_used:
            try:
                await asyncio.wait_for(
                    self._self_review(text, final_answer, tools_used, user_id, channel),
                    timeout=30.0
                )
            except asyncio.TimeoutError:
                logger.warning("Self-review timed out")
            except Exception as exc:
                logger.warning("Self-review error: %s", exc)
        else:
            self.ws_memory.append_daily_log(
                f"**User ({user_id}):** {text[:120]}\n"
                f"**Agent:** {final_answer[:200]}"
            )

        # Store conversations (with timeouts)
        try:
            await asyncio.wait_for(
                self.memory.store_conversation(user_id, "user", text),
                timeout=5.0
            )
        except asyncio.TimeoutError:
            logger.warning("Store user conversation timed out")

        try:
            await asyncio.wait_for(
                self.memory.store_conversation(user_id, "assistant", final_answer),
                timeout=5.0
            )
        except asyncio.TimeoutError:
            logger.warning("Store assistant conversation timed out")

        await hook_bus.fire("agent_end", {
            "user_id": user_id, "channel": channel,
            "request": text, "response": final_answer,
            "tools_used": tools_used,
        })

        return final_answer

    # ── Dual-path routing ─────────────────────────────────────────────────────

    async def _execute_with_routing(
        self,
        tool_call: dict,
        user_input: str,
        memory_context: str,
        thread_id: str,
        tools_used: list[str],
    ) -> str:
        """
        Route tool execution through Byzantine consensus or direct path.

        FAST PATH:  read_file, list_files, calculate, web_search → direct
        SAFE PATH:  run_python, write_file, run_command, patch_file, spawn_agent
                    → Byzantine 3-agent consensus + HITL gate
        """
        tool_name = tool_call.get("tool", "")

        # Fast path: low-risk tools skip Byzantine voting
        if not self._requires_consensus(tool_name):
            logger.debug("Fast path: %s", tool_name)
            return await self.tool_executor.execute(tool_call)

        # Safe path: Byzantine consensus required
        if not self.byzantine or not self._byzantine_enabled:
            logger.warning(
                "Byzantine disabled but %s is high-risk — executing with warning", tool_name
            )
            return await self.tool_executor.execute(tool_call)

        logger.info("Safe path: routing '%s' through Byzantine consensus", tool_name)

        try:
            decision = await asyncio.wait_for(
                self.byzantine.decide(
                    proposed_action = {"tool": tool_name, "args": tool_call.get("args", {})},
                    user_input      = user_input,
                    memory_context  = memory_context,
                    thread_id       = thread_id,
                ),
                timeout=120.0
            )
        except asyncio.TimeoutError:
            logger.error("Byzantine consensus timed out")
            return f"[ERROR] Byzantine consensus timed out for {tool_name}"

        if decision.requires_human:
            tools_used.append(f"{tool_name}[awaiting_human]")
            return (
                f"[HUMAN APPROVAL REQUIRED]\n"
                f"The proposed action '{tool_name}' requires your approval.\n"
                f"Use: /approve {thread_id}  or  /reject {thread_id} <reason>\n"
                f"To review: /pending {thread_id}"
            )

        if decision.approved:
            tools_used.append(f"{tool_name}[byzantine_approved]")
            return decision.execution_result or "(no output)"

        tools_used.append(f"{tool_name}[byzantine_blocked]")
        return f"[BLOCKED by Byzantine consensus]: {decision.escalation_reason}"

    def _requires_consensus(self, tool_name: str) -> bool:
        """Return True if tool needs Byzantine voting."""
        return (
            self._byzantine_enabled
            and self.byzantine is not None
            and tool_name not in FAST_PATH_TOOLS
        )

    # ── Self-review ───────────────────────────────────────────────────────────

    async def _self_review(
        self, request: str, response: str, tools_used: list[str],
        user_id: str, channel: str,
    ) -> None:
        review_prompt = _REVIEW_PROMPT.format(
            request=request, response=response[:500],
            tools_used=", ".join(tools_used),
        )
        try:
            review = await self.llm.generate(
                prompt=review_prompt, history=[], tools_description="",
                system_message="You are a quality reviewer. Be brief and honest.",
            )
            raw = review.content.strip()
            fields = _parse_review(raw)

            self.ws_memory.append_daily_log(
                f"**Task:** {request[:100]}\n"
                f"**Completed:** {fields.get('COMPLETED', '?')}\n"
                f"**Errors:** {fields.get('ERRORS', 'none')}\n"
                f"**Improvement:** {fields.get('IMPROVEMENT', 'none')}"
            )

            remember = fields.get("REMEMBER", "nothing").strip()
            if remember and remember.lower() not in ("nothing", "none", "n/a", ""):
                self.ws_memory.append_memory("Learnings", remember)
                try:
                    await asyncio.wait_for(
                        self.memory.store_fact(user_id, f"learning:{request[:30]}", remember),
                        timeout=5.0
                    )
                except asyncio.TimeoutError:
                    logger.warning("Store learning fact timed out")

            improvement = fields.get("IMPROVEMENT", "none").strip()
            if improvement and improvement.lower() not in ("none", "n/a", ""):
                self.ws_memory.append_memory(
                    "Known Issues & Solutions",
                    f"[{request[:50]}] → {improvement}"
                )
        except Exception as exc:
            logger.warning("Self-review failed (non-critical): %s", exc)

    # ── Summary management ────────────────────────────────────────────────────

    async def _maybe_update_summary(self, user_id: str, channel: str) -> None:
        try:
            total = await asyncio.wait_for(
                self.memory.get_conversation_turn_count(user_id),
                timeout=5.0
            )
        except asyncio.TimeoutError:
            return

        try:
            last = await asyncio.wait_for(
                self._get_last_summary_tc(user_id, channel),
                timeout=5.0
            )
        except asyncio.TimeoutError:
            last = 0

        if total - last < self.summarise_every:
            return

        await hook_bus.fire("memory_flush", {"user_id": user_id, "channel": channel})
        await hook_bus.fire("before_compaction", {"user_id": user_id, "channel": channel})

        try:
            recent = await asyncio.wait_for(
                self.memory.get_recent_conversations(user_id, limit=30),
                timeout=10.0
            )
        except asyncio.TimeoutError:
            logger.warning("Get recent conversations timed out")
            return

        if not recent:
            return

        turns_text = "\n".join(f"{m['role'].upper()}: {m['content']}" for m in recent)
        existing = await asyncio.wait_for(
            self.memory.get_summary(user_id, channel),
            timeout=5.0
        )

        prompt = (
            f"Existing summary:\n{existing}\n\nNew turns:\n{turns_text}\n\n"
            "Update summary. Max 200 words. Third-person."
        ) if existing else _SUMMARISE_PROMPT.format(turns=turns_text)

        try:
            resp = await asyncio.wait_for(
                self.llm.generate(
                    prompt=prompt, history=[], tools_description="",
                    system_message="You are a memory assistant. Write concise summaries.",
                ),
                timeout=60.0
            )
            if resp.content.strip():
                await asyncio.wait_for(
                    self.memory.store_summary(user_id, channel, resp.content.strip(), total),
                    timeout=5.0
                )
        except asyncio.TimeoutError:
            logger.warning("Summary generation timed out")
        except Exception as exc:
            logger.warning("Summary rebuild failed: %s", exc)

        await hook_bus.fire("after_compaction", {"user_id": user_id, "channel": channel})

    async def _get_last_summary_tc(self, user_id: str, channel: str) -> int:
        """Get the turn count from last summary update."""
        summary = await self.memory.get_summary(user_id, channel)
        if not summary:
            return 0
        # Parse turn count from summary or return 0
        return 0  # Simplified - could store separately if needed

    # ── Fact extraction ────────────────────────────────────────────────────────

    async def _auto_extract_facts(self, user_id: str, text: str) -> None:
        if self.llm_fact_extract:
            try:
                await self._llm_extract_facts(user_id, text)
                return
            except Exception as exc:
                logger.warning("LLM fact extraction failed, using regex: %s", exc)
        await self._regex_extract_facts(user_id, text)

    async def _llm_extract_facts(self, user_id: str, text: str) -> None:
        if len(text.strip()) < 20:
            return
        prompt = _FACT_EXTRACTION_PROMPT.format(text=text)
        try:
            response = await asyncio.wait_for(
                self.llm.generate(
                    prompt=prompt, history=[], tools_description="",
                    system_message="You are a fact extraction system. Output only valid JSON.",
                ),
                timeout=30.0
            )
            raw = response.content.strip()
            if not raw.startswith("{"):
                return
            data = json.loads(raw)
            facts = data.get("facts", [])
            for fact in facts:
                key = fact.get("key", "").strip().lower()
                value = fact.get("value", "").strip()
                category = fact.get("category", "context")
                if key and value and len(key) <= 50 and len(value) <= 500:
                    full_key = f"{category}:{key}" if category != "identity" else key
                    await asyncio.wait_for(
                        self.memory.store_fact(user_id, full_key, value),
                        timeout=5.0
                    )
        except asyncio.TimeoutError:
            logger.debug("LLM fact extraction timed out")
        except Exception as exc:
            logger.debug("LLM fact extraction parse error: %s", exc)

    async def _regex_extract_facts(self, user_id: str, text: str) -> None:
        for pattern, key in _FACT_PATTERNS:
            match = pattern.search(text)
            if not match:
                continue
            if key:
                v = match.group(1).strip()
                if v:
                    await asyncio.wait_for(
                        self.memory.store_fact(user_id, key, v),
                        timeout=5.0
                    )
            else:
                groups = match.groups()
                if len(groups) >= 2:
                    k, v = groups[0].strip().lower(), groups[1].strip()
                    if k and v:
                        await asyncio.wait_for(
                            self.memory.store_fact(user_id, k, v),
                            timeout=5.0
                        )
