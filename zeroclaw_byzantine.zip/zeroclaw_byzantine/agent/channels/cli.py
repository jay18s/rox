"""CLI channel adapter – reads from stdin, writes to stdout."""

from __future__ import annotations

import asyncio
import logging
import sys
import platform
from typing import Any

from agent.channels.base import BaseChannel

logger = logging.getLogger(__name__)

CLI_USER_ID = "cli_user"


class CLIChannel(BaseChannel):
    """Async CLI channel using asyncio streams."""

    def __init__(self, config: dict[str, Any], queue: asyncio.Queue) -> None:
        super().__init__(config, queue)
        self.name = "cli"
        self._running = False
        self._is_windows = platform.system() == "Windows"

    async def start(self) -> None:
        """Start the CLI input loop."""
        self._running = True
        logger.info("CLI channel started. Type your message (Ctrl+C to exit).")
        print("\n🤖  ZeroClaw Agent — CLI Mode")
        print("=" * 40)
        print("Type a message and press Enter. Ctrl+C to quit.\n")

        loop = asyncio.get_running_loop()

        while self._running:
            try:
                # On Windows, use a simpler approach with asyncio.stdin
                # On Unix, run blocking input() in a thread executor
                if self._is_windows:
                    text = await self._read_line_windows()
                else:
                    text = await loop.run_in_executor(None, self._read_line)
                
                if text is None:  # EOF
                    break
                text = text.strip()
                if not text:
                    continue

                msg = {
                    "channel": self.name,
                    "user_id": CLI_USER_ID,
                    "chat_id": CLI_USER_ID,
                    "text": text,
                }
                await self.queue.put(msg)

            except asyncio.CancelledError:
                break
            except (EOFError, KeyboardInterrupt):
                break

        self._running = False
        logger.info("CLI channel stopped.")

    def _read_line(self) -> str | None:
        """Read a line from stdin (blocking). Returns None on EOF."""
        try:
            print("You: ", end="", flush=True)
            line = sys.stdin.readline()
            if not line:  # EOF
                return None
            return line.rstrip("\n")
        except (EOFError, KeyboardInterrupt):
            return None

    async def _read_line_windows(self) -> str | None:
        """Read a line from stdin on Windows (async-friendly)."""
        try:
            # Use asyncio's stdin reader on Windows
            print("You: ", end="", flush=True)
            
            # Create a future for the input
            loop = asyncio.get_running_loop()
            future = loop.run_in_executor(None, self._read_line)
            
            # Wait for input with a small timeout to allow checking _running
            while self._running:
                try:
                    result = await asyncio.wait_for(future, timeout=0.5)
                    return result
                except asyncio.TimeoutError:
                    # Check if we should still be running
                    if not self._running:
                        return None
                    # Re-create the future for the next wait
                    future = loop.run_in_executor(None, self._read_line)
                    
        except (EOFError, KeyboardInterrupt):
            return None
        except Exception as e:
            logger.warning("Windows stdin read error: %s", e)
            return None

    async def stop(self) -> None:
        """Stop the CLI loop."""
        self._running = False

    async def send_message(self, text: str, user_id: str, chat_id: str | None = None) -> None:
        """Print the agent's response to stdout."""
        print(f"\n🤖 Agent: {text}\n")
