"""
LangGraph Assembly — Byzantine Fault-Tolerant Decision Engine.

Based on Kimi's excellent graph.py with:
  - Correct module import paths for integration
  - AsyncSqliteSaver (not synchronous SqliteSaver)
  - interrupt_before=["execution"] for HITL
  - loop-back edge arbitration → re_vote → voting
  - select_winner_node (separate from router — router is READ-ONLY)
  - sanitize_input integrated
  - escalation_node with structured JSON report

Graph flow:
  START → voting → [consensus_router]
              ├─ execute  → select_winner → execution → END
              ├─ arbitrate → arbitration → [arbitration_router]
              │                    ├─ execute  → execution → END
              │                    ├─ re_vote  → voting       (loop-back)
              │                    └─ escalate → escalation → END
              └─ escalate → escalation → END
"""

from __future__ import annotations

import json
import re
import time
import logging
from datetime import datetime
from pathlib import Path

from langgraph.graph import StateGraph, START, END
try:
    from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver
except ImportError:
    from langgraph.checkpoint.memory import MemorySaver as AsyncSqliteSaver

from agent.byzantine.state import ByzantineState, create_default_state
from agent.byzantine.consensus import (
    voting_node, consensus_router, select_winner_node,
    arbitration_node, arbitration_router,
)
from agent.byzantine.execution import execution_node
from agent.byzantine.circuit_breaker import get_circuit_breaker

logger = logging.getLogger(__name__)

# Checkpoint DB path
CHECKPOINT_DB = Path(__file__).parent.parent.parent / "byzantine_checkpoints.db"

# ── Escalation node ────────────────────────────────────────────────────────────

def escalation_node(state: dict) -> dict:
    """Build escalation report and terminate with escalated status."""
    thread_id   = state.get("thread_id", "unknown")
    user_input  = state.get("user_input", "")
    current_round = state.get("current_round", 0)
    reflection  = state.get("reflection_count", 0)

    votes_by_round: dict[int, list] = {}
    for vote in state.get("votes", []):
        rid = vote.get("round_id", 0)
        votes_by_round.setdefault(rid, []).append({
            "agent":     vote.get("agent_id"),
            "action":    vote.get("proposed_action"),
            "confidence": vote.get("confidence"),
            "risk":      vote.get("risk_level"),
            "reasoning": vote.get("reasoning", "")[:100],
        })

    current_votes = [
        v for v in state.get("votes", [])
        if v.get("round_id") == current_round
    ]

    if reflection >= 3:
        reason = "Maximum reflection attempts (3) reached"
    elif any(v.get("risk_level") == "critical" for v in current_votes):
        reason = "Critical risk vote detected"
    elif state.get("human_decision"):
        reason = f"Human decision: {state['human_decision']}"
    else:
        reason = "No consensus reached"

    report = {
        "timestamp":       datetime.utcnow().isoformat() + "Z",
        "thread_id":       thread_id,
        "user_request":    user_input,
        "proposed_tool":   state.get("proposed_tool", ""),
        "proposed_params": state.get("proposed_params", {}),
        "failure_reason":  reason,
        "rounds":          current_round,
        "reflections":     reflection,
        "votes_by_round":  votes_by_round,
        "recommendation":  "Review votes above and manually approve or reject the action.",
    }

    workspace_dir = Path(__file__).parent.parent.parent / "workspace"
    workspace_dir.mkdir(exist_ok=True)
    report_file = workspace_dir / f"escalation_{thread_id}_{int(time.time())}.json"
    try:
        with open(report_file, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
    except Exception as exc:
        logger.error("Failed to write escalation report: %s", exc)

    logger.critical(
        "ESCALATION thread=%s reason=%s rounds=%d reflections=%d",
        thread_id, reason, current_round, reflection,
    )

    summary = (
        f"ESCALATED: {reason}\n"
        f"Proposed tool: {state.get('proposed_tool', 'unknown')}\n"
        f"Rounds attempted: {current_round}\n"
        f"Report: {report_file.name}"
    )
    return {"status": "escalated", "execution_result": summary}


# ── Input sanitization ─────────────────────────────────────────────────────────

INJECTION_PATTERNS = [
    r"ignore\s+(previous|prior|above|all)\s+instructions",
    r"new\s+(system\s+)?prompt",
    r"you\s+are\s+now\s+\w+",
    r"disregard\s+(all\s+)?previous",
    r"act\s+as\s+(if\s+you\s+are|a\s+)",
    r"override\s+(your\s+)?(previous\s+)?(instructions|rules)",
    r"jailbreak",
    r"dan\s+mode",
    r"developer\s+mode",
    r"forget\s+(everything|all|previous)",
]


class SecurityViolation(Exception):
    pass


def sanitize_input(text: str) -> str:
    if not text:
        return ""
    text = text.strip()
    if len(text) > 512:
        raise SecurityViolation(f"Input exceeds 512 chars ({len(text)})")
    for pattern in INJECTION_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            raise SecurityViolation(f"Prompt injection pattern detected")
    if "{" in text and "}" in text and len(text) > 50:
        logger.warning("PROMPT_INJECTION_WARNING: Input contains JSON-like structure: %s", text[:50])
    return text


# ── Graph assembly ─────────────────────────────────────────────────────────────

def build_graph():
    builder = StateGraph(ByzantineState)

    builder.add_node("voting",        voting_node)
    builder.add_node("select_winner", select_winner_node)
    builder.add_node("arbitration",   arbitration_node)
    builder.add_node("execution",     execution_node)
    builder.add_node("escalation",    escalation_node)

    builder.add_edge(START, "voting")

    builder.add_conditional_edges(
        "voting",
        consensus_router,
        {"execute": "select_winner", "arbitrate": "arbitration", "escalate": "escalation"},
    )

    builder.add_edge("select_winner", "execution")

    builder.add_conditional_edges(
        "arbitration",
        arbitration_router,
        {
            "execute":  "execution",
            "re_vote":  "voting",       # ← THE LOOP-BACK (critical)
            "escalate": "escalation",
        },
    )

    builder.add_edge("execution",  END)
    builder.add_edge("escalation", END)
    return builder


# ── Compiled graph (singleton) ────────────────────────────────────────────────

_compiled_graph = None


async def get_compiled_graph(checkpoint_db: str = None):
    global _compiled_graph
    if _compiled_graph is None:
        db_path = checkpoint_db or str(CHECKPOINT_DB)
        builder = build_graph()
        checkpointer = AsyncSqliteSaver.from_conn_string(db_path)
        _compiled_graph = builder.compile(
            checkpointer=checkpointer,
            interrupt_before=["execution"],   # HITL: pause before every execution
        )
        logger.info("Byzantine graph compiled with HITL interrupt_before=['execution']")
    return _compiled_graph


# ── Public API ─────────────────────────────────────────────────────────────────

async def run_task(
    input_text: str,
    thread_id: str = "default",
    proposed_tool: str = "",
    proposed_params: dict = None,
    memory_context: str = "",
) -> dict:
    """
    Run a task through Byzantine consensus.
    Graph will pause at interrupt_before=['execution'] awaiting human approval.
    """
    start = time.time()
    try:
        sanitized = sanitize_input(input_text)
    except SecurityViolation as e:
        return {
            "thread_id": thread_id, "status": "escalated",
            "result": f"Security violation: {e}",
            "consensus_rounds": 0, "votes_summary": [], "winning_action": None,
            "circuit_breaker_health": get_circuit_breaker().get_health_report(),
            "execution_time_ms": 0, "error_log": [{"error": str(e)}],
        }

    initial_state = create_default_state(
        thread_id=thread_id,
        user_input=sanitized,
        proposed_tool=proposed_tool,
        proposed_params=proposed_params or {},
        memory_context=memory_context,
    )

    graph  = await get_compiled_graph()
    config = {"configurable": {"thread_id": thread_id}}

    try:
        result = await graph.ainvoke(initial_state, config)
        state  = await graph.aget_state(config)
        values = state.values if hasattr(state, "values") else result
        elapsed = int((time.time() - start) * 1000)

        votes_summary = [
            {"agent": v.get("agent_id"), "action": v.get("proposed_action"),
             "confidence": v.get("confidence"), "risk": v.get("risk_level")}
            for v in values.get("votes", [])
        ]

        current_status = values.get("status", "unknown")

        # Check if we're paused at the HITL interrupt
        if current_status == "executing" and values.get("winning_action"):
            current_status = "awaiting_human"

        return {
            "thread_id":              thread_id,
            "status":                 current_status,
            "result":                 values.get("execution_result") or "Awaiting approval",
            "consensus_rounds":       values.get("current_round", 0),
            "votes_summary":          votes_summary,
            "winning_action":         values.get("winning_action"),
            "circuit_breaker_health": get_circuit_breaker().get_health_report(),
            "execution_time_ms":      elapsed,
            "error_log":              values.get("error_log", []),
        }

    except Exception as exc:
        elapsed = int((time.time() - start) * 1000)
        logger.error("Graph execution failed for thread=%s: %s", thread_id, exc)
        return {
            "thread_id": thread_id, "status": "escalated",
            "result": f"Graph error: {type(exc).__name__}: {exc}",
            "consensus_rounds": 0, "votes_summary": [], "winning_action": None,
            "circuit_breaker_health": get_circuit_breaker().get_health_report(),
            "execution_time_ms": elapsed,
            "error_log": [{"error": f"{type(exc).__name__}: {str(exc)}"}],
        }


async def get_pending_action(thread_id: str) -> dict:
    graph  = await get_compiled_graph()
    config = {"configurable": {"thread_id": thread_id}}
    try:
        state  = await graph.aget_state(config)
        values = state.values if hasattr(state, "values") else {}
        risk_counts = {"low": 0, "medium": 0, "high": 0, "critical": 0}
        for v in values.get("votes", []):
            risk = v.get("risk_level", "medium")
            risk_counts[risk] = risk_counts.get(risk, 0) + 1
        return {
            "thread_id":      thread_id,
            "user_input":     values.get("user_input", ""),
            "proposed_tool":  values.get("proposed_tool", ""),
            "winning_action": values.get("winning_action"),
            "all_votes":      values.get("votes", []),
            "risk_summary":   risk_counts,
            "reflection_count": values.get("reflection_count", 0),
        }
    except Exception as exc:
        return {"thread_id": thread_id, "error": str(exc)}


async def resume_task(thread_id: str, approved: bool, human_note: str = "") -> dict:
    """Resume after HITL interrupt."""
    graph  = await get_compiled_graph()
    config = {"configurable": {"thread_id": thread_id}}
    start  = time.time()

    if not approved:
        await graph.aupdate_state(config, {
            "status":         "escalated",
            "human_decision": f"Human rejected: {human_note}",
            "execution_result": f"Rejected by human: {human_note}",
        })

    try:
        result  = await graph.ainvoke(None, config)
        elapsed = int((time.time() - start) * 1000)
        return {
            "thread_id":       thread_id,
            "status":          result.get("status", "unknown") if approved else "escalated",
            "result":          result.get("execution_result", "No result"),
            "human_note":      human_note,
            "execution_time_ms": elapsed,
        }
    except Exception as exc:
        return {
            "thread_id": thread_id, "status": "escalated",
            "result": f"Resume error: {exc}", "human_note": human_note,
            "execution_time_ms": int((time.time() - start) * 1000),
        }
