"""
Byzantine Agent Nodes.

Three agents vote in parallel on every tool-call decision:
  Alpha (llama3.1:8b)  — Cautious Strategist
  Beta  (llama3.1:8b)  — Efficient Executor
  Gamma (qwen2.5:7b)   — Safety Validator

KEY integration: each agent receives ZeroClaw's memory_context
(SOUL.md + user facts + summary) so voters are context-aware.

FIXES applied vs source implementations:
  - asyncio.run() removed from LLM repair (was crashing inside event loop)
  - memory_context injected into every agent system prompt
  - SYSTEMROOT preserved in Windows subprocess env
  - proposed_tool/proposed_params used as context for evaluation
"""

from __future__ import annotations

import asyncio
import json
import re
import time
import logging
from typing import Optional

from langchain_ollama import ChatOllama

from agent.byzantine.state import Vote, create_vote, BYZANTINE_FAULT_VOTE, ABSTAIN_VOTE, create_timestamp
from agent.byzantine.circuit_breaker import get_circuit_breaker

logger = logging.getLogger(__name__)


# ── Agent configuration ────────────────────────────────────────────────────────

AGENT_CONFIG = {
    "alpha": {
        "model": "llama3.1:8b",
        "persona": "Cautious Strategist — prioritize correctness and safety above speed",
        "temperature": 0.05,
    },
    "beta": {
        "model": "llama3.1:8b",
        "persona": "Efficient Executor — minimize steps, maximize precision",
        "temperature": 0.1,
    },
    "gamma": {
        "model": "qwen2.5:7b",
        "persona": "Safety Validator — detect dangerous/malicious requests. "
                   "If unsafe: risk_level=critical, proposed_action=reject. When in doubt, reject.",
        "temperature": 0.05,
    },
}

OLLAMA_HOST     = "http://localhost:11434"
OLLAMA_CTX      = 2048
OLLAMA_KEEPALIVE = 300


# ── System prompt builder ──────────────────────────────────────────────────────

def build_system_prompt(
    agent_id: str,
    available_tools: list[dict],
    proposed_tool: str = "",
    proposed_params: dict = None,
    memory_context: str = "",
) -> str:
    """Build per-agent system prompt, including ZeroClaw memory context."""
    config = AGENT_CONFIG[agent_id]

    tools_str = "\n".join(
        f"  - {t['name']}: {t['description']}" for t in available_tools
    )

    proposed_section = ""
    if proposed_tool:
        proposed_section = f"""
## MAIN AGENT PROPOSED ACTION
Tool: {proposed_tool}
Params: {json.dumps(proposed_params or {}, indent=2)}

Evaluate this proposal. You may approve it, modify it, or reject it.
"""

    memory_section = ""
    if memory_context:
        memory_section = f"""
## USER CONTEXT (from ZeroClaw memory)
{memory_context[:1000]}
"""

    return f"""You are {agent_id.upper()}, an AI agent with the following persona:
{config['persona']}
{memory_section}{proposed_section}
AVAILABLE TOOLS:
{tools_str}

You MUST respond with a valid JSON object in exactly this format:
{{
  "proposed_action": "<tool_name from available tools>",
  "action_params": {{...tool-specific parameters...}},
  "reasoning": "<max 200 char explanation>",
  "confidence": <integer 0-100>,
  "risk_level": "<low|medium|high|critical>"
}}

CRITICAL RULES:
1. Output ONLY valid JSON — no markdown, no text outside JSON
2. If request is unsafe or uncertain: proposed_action="reject", risk_level="critical"
3. confidence=100 means absolutely certain; confidence=0 means guessing
4. If in doubt about safety: reject

Example:
{{"proposed_action": "calculate", "action_params": {{"expression": "2+2"}}, "reasoning": "Simple math", "confidence": 95, "risk_level": "low"}}"""


# ── JSON repair (5 layers, fixed asyncio) ─────────────────────────────────────

def robust_json_parse(raw_text: str, agent_id: str) -> Optional[dict]:
    """
    5-layer JSON parsing. Layer 5 (LLM repair) is exposed separately as async.
    The asyncio.run() bug from source is removed — callers use repair_json_async().
    """
    if not raw_text or not raw_text.strip():
        return None
    text = raw_text.strip()

    # Layer 1: Direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Layer 2: Strip markdown fences
    try:
        cleaned = re.sub(r'^```json\s*', '', text, flags=re.IGNORECASE)
        cleaned = re.sub(r'\s*```\s*$', '', cleaned)
        cleaned = re.sub(r'^```\s*', '', cleaned)
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # Layer 3: Regex extract first {...} block
    try:
        match = re.search(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', text, re.DOTALL)
        if match:
            return json.loads(match.group(0))
    except json.JSONDecodeError:
        pass

    # Layer 4: Field-by-field extraction
    result: dict = {}
    for field, pattern in [
        ("proposed_action", r'"proposed_action"\s*:\s*"([^"]+)"'),
        ("reasoning",       r'"reasoning"\s*:\s*"([^"]+)"'),
        ("risk_level",      r'"risk_level"\s*:\s*"([^"]+)"'),
    ]:
        m = re.search(pattern, text)
        if m:
            result[field] = m.group(1)

    conf = re.search(r'"confidence"\s*:\s*(\d+)', text)
    result["confidence"] = int(conf.group(1)) if conf else 50

    params_m = re.search(r'"action_params"\s*:\s*(\{[^}]+\})', text)
    try:
        result["action_params"] = json.loads(params_m.group(1)) if params_m else {}
    except Exception:
        result["action_params"] = {}

    if len(result) >= 3:
        return result

    return None


async def repair_json_async(raw_text: str, repair_llm: ChatOllama) -> Optional[dict]:
    """Layer 5: async LLM self-repair (call only when all other layers fail)."""
    try:
        repair_prompt = (
            "Fix this malformed JSON, return ONLY valid JSON with no markdown:\n"
            f"{raw_text[:500]}\n\n"
            'Required: {"proposed_action":"...","action_params":{},"reasoning":"...","confidence":50,"risk_level":"low|medium|high|critical"}'
        )
        response = await asyncio.wait_for(
            repair_llm.ainvoke([{"role": "user", "content": repair_prompt}]),
            timeout=20.0,
        )
        raw = response.content if hasattr(response, "content") else str(response)
        return json.loads(raw.strip())
    except Exception as exc:
        logger.debug("LLM repair failed: %s", exc)
        return None


# ── Agent node ─────────────────────────────────────────────────────────────────

async def agent_node(state: dict, agent_id: str) -> dict:
    """
    Execute a single Byzantine agent with circuit breaker and timeout.
    Returns a state-delta dict: {"votes": [vote], "error_log": [...]}
    """
    thread_id  = state.get("thread_id", "unknown")
    round_id   = state.get("current_round", 0)
    config     = AGENT_CONFIG[agent_id]

    # 1. Circuit breaker check
    circuit = get_circuit_breaker()
    if not circuit.can_execute(agent_id):
        logger.info("Circuit OPEN for %s — abstaining", agent_id)
        abstain = dict(ABSTAIN_VOTE)
        abstain["round_id"]  = round_id
        abstain["timestamp"] = create_timestamp()
        return {"votes": [abstain]}

    # 2. Lazy import to avoid circular imports at module load
    from agent.byzantine.execution import get_registry
    registry       = get_registry()
    available_tools = registry.list_tools()

    system_prompt = build_system_prompt(
        agent_id,
        available_tools,
        proposed_tool   = state.get("proposed_tool", ""),
        proposed_params = state.get("proposed_params", {}),
        memory_context  = state.get("memory_context", ""),
    )

    messages = [
        {"role": "system", "content": system_prompt},
        *state.get("messages", []),
        {"role": "user", "content": state.get("user_input", "")},
    ]

    llm = ChatOllama(
        model=config["model"],
        temperature=config["temperature"],
        format="json",
        base_url=OLLAMA_HOST,
        keep_alive=OLLAMA_KEEPALIVE,
        num_ctx=OLLAMA_CTX,
    )

    logger.info("Agent %s calling LLM (round=%d, thread=%s)", agent_id, round_id, thread_id)
    start = time.time()

    try:
        response = await asyncio.wait_for(llm.ainvoke(messages), timeout=60.0)
        duration_ms = int((time.time() - start) * 1000)
        raw_output  = response.content if hasattr(response, "content") else str(response)

        # Parse — try sync layers first, then async repair
        parsed = robust_json_parse(raw_output, agent_id)
        if parsed is None:
            parsed = await repair_json_async(raw_output, llm)

        if parsed is None:
            raise ValueError("All JSON parse layers failed")

        # Validate required fields
        for field in ("proposed_action", "action_params", "confidence", "risk_level"):
            if field not in parsed:
                raise ValueError(f"Missing field: {field}")

        vote = create_vote(
            agent_id        = agent_id,
            round_id        = round_id,
            proposed_action = parsed["proposed_action"],
            action_params   = parsed.get("action_params", {}),
            reasoning       = parsed.get("reasoning", ""),
            confidence      = parsed["confidence"],
            risk_level      = parsed["risk_level"],
            raw_output      = raw_output,
        )

        circuit.record_success(agent_id)
        logger.info(
            "Agent %s voted: action=%s conf=%d risk=%s duration=%dms",
            agent_id, vote["proposed_action"], vote["confidence"], vote["risk_level"], duration_ms,
        )
        return {"votes": [vote]}

    except asyncio.TimeoutError:
        circuit.record_failure(agent_id)
        logger.warning("Agent %s TIMEOUT after 60s", agent_id)
        fault = dict(BYZANTINE_FAULT_VOTE)
        fault["round_id"]  = round_id
        fault["timestamp"] = create_timestamp()
        fault["reasoning"] = "Timeout after 60s"
        return {
            "votes": [fault],
            "error_log": [{"timestamp": create_timestamp(), "agent_id": agent_id, "error": "Timeout"}],
        }

    except Exception as exc:
        circuit.record_failure(agent_id)
        logger.error("Agent %s ERROR: %s", agent_id, exc)
        fault = dict(BYZANTINE_FAULT_VOTE)
        fault["round_id"]  = round_id
        fault["timestamp"] = create_timestamp()
        fault["reasoning"] = f"{type(exc).__name__}: {str(exc)[:100]}"
        return {
            "votes": [fault],
            "error_log": [{
                "timestamp": create_timestamp(),
                "agent_id":  agent_id,
                "error":     f"{type(exc).__name__}: {str(exc)}",
            }],
        }


# ── Convenience wrappers ───────────────────────────────────────────────────────

async def node_alpha(state: dict) -> dict:
    return await agent_node(state, "alpha")

async def node_beta(state: dict) -> dict:
    return await agent_node(state, "beta")

async def node_gamma(state: dict) -> dict:
    return await agent_node(state, "gamma")
