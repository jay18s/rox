#!/usr/bin/env python3
"""
ROX Proven Edge Engine v3.0 - Main Entry Point (Production)
==========================================================
Command-line interface for the multi-agent swing trading system.
Windows-compatible with comprehensive error handling and logging.
"""

import os
import sys
import argparse
import asyncio
import signal
from pathlib import Path
from datetime import datetime, date
from typing import Dict, List, Optional

# Add project root to path
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

# Initialize logging first
try:
    from core import (
        init_logging, get_logger, setup_logging,
        SystemConfig, DEFAULT_CONFIG, MarketRegime,
        TradeDirection, ConvictionLevel, NIFTY_50_STOCKS,
        NewsFetcher, fetch_news_sync
    )
    from core.config import get_system_config
except ImportError:
    # Fallback for direct execution
    from config import (
        SystemConfig, DEFAULT_CONFIG, MarketRegime,
        TradeDirection, ConvictionLevel, NIFTY_50_STOCKS
    )
    import logging
    logging.basicConfig(level=logging.INFO)
    get_logger = logging.getLogger

# Initialize logging
init_logging()
logger = get_logger("Main")


class ROXEdgeEngine:
    """
    Main application class for the ROX Edge Engine.
    
    Production-ready with:
    - Comprehensive error handling
    - Geopolitical news integration
    - Stock price change news
    - Windows compatibility
    """
    
    def __init__(self, portfolio_value: float = None, config: SystemConfig = None):
        self.config = config or get_system_config()
        self.portfolio_value = portfolio_value or self.config.default_portfolio_value
        
        logger.info(f"Initializing ROX Edge Engine with portfolio: {self.portfolio_value:,.2f}")

        # L-07: Path for persisting portfolio state between runs
        self._portfolio_state_file = Path(__file__).parent / "data" / "portfolio_state.json"
        
        # Initialize components
        try:
            from coordinator import LeadCoordinator
            from data.data_manager import DataManager, TradeRecord
            from data.trade_logger import TradeLogger
            from data.pattern_database import PatternDatabase
            from data.scorecard import AgentScorecard

            self.coordinator = LeadCoordinator(self.config, self.portfolio_value)
            self.data_manager = DataManager()
            self.trade_logger = TradeLogger(self.data_manager)
            self.pattern_db = PatternDatabase(self.data_manager)
            self.scorecard = AgentScorecard(self.data_manager)
            
        except ImportError as e:
            logger.warning(f"Import warning: {e}. Some features may be limited.")
            self.coordinator = None
            self.data_manager = None
            self.trade_logger = None
            self.pattern_db = None
        
        # Initialize news fetcher
        self.news_fetcher = NewsFetcher(self.config.news)
        
        # State
        self._running = False
        self._shutdown_requested = False
        
        # Set up signal handlers
        self._setup_signal_handlers()
    
    def _setup_signal_handlers(self):
        """Set up signal handlers for graceful shutdown."""
        def signal_handler(signum, frame):
            logger.info(f"Received signal {signum}, shutting down...")
            self._shutdown_requested = True
        
        try:
            signal.signal(signal.SIGINT, signal_handler)
            signal.signal(signal.SIGTERM, signal_handler)
        except (AttributeError, ValueError):
            # Windows may not support all signals
            pass
    
    async def initialize(self):
        """Asynchronous initialization."""
        logger.info("Performing async initialization...")
        # Pre-fetch news cache
        try:
            await self.news_fetcher.get_market_news_summary()
        except Exception as e:
            logger.warning(f"News pre-fetch failed: {e}")

    # ── L-07: Portfolio state persistence ─────────────────────────────────────
    def _load_portfolio_state(self) -> Dict:
        """
        Load portfolio state from disk.  Returns a fresh default state if the
        file does not exist or cannot be parsed.  This ensures the Portfolio Risk
        Dashboard reflects real open positions rather than always showing 0% deployed.
        """
        import json as _json
        default = {
            "total_capital":    self.portfolio_value,
            "deployed_capital": 0.0,
            "cash":             self.portfolio_value,
            "portfolio_heat":   0.0,
            "current_drawdown": 0.0,
            "open_positions":   [],
            "sector_exposure":  {},
            "last_updated":     "",
        }
        try:
            if self._portfolio_state_file.exists():
                with open(self._portfolio_state_file, "r") as f:
                    saved = _json.load(f)
                # Always keep total_capital in sync with the configured value
                saved["total_capital"] = self.portfolio_value
                saved["cash"] = max(0.0, self.portfolio_value - saved.get("deployed_capital", 0.0))
                logger.info(
                    f"Portfolio state loaded: "
                    f"{len(saved.get('open_positions', []))} open positions | "
                    f"deployed={saved.get('deployed_capital', 0):,.0f} | "
                    f"heat={saved.get('portfolio_heat', 0)*100:.1f}%"
                )
                return saved
        except Exception as e:
            logger.warning(f"Could not load portfolio state: {e} — using defaults")
        return default

    def _save_portfolio_state(self, state: Dict) -> None:
        """Persist portfolio state to disk after each plan generation."""
        import json as _json
        try:
            self._portfolio_state_file.parent.mkdir(parents=True, exist_ok=True)
            state["last_updated"] = datetime.now().isoformat()
            with open(self._portfolio_state_file, "w") as f:
                _json.dump(state, f, indent=2, default=str)
        except Exception as e:
            logger.warning(f"Could not save portfolio state: {e}")
    # ── END portfolio persistence ──────────────────────────────────────────────
    
    async def shutdown(self):
        """Clean shutdown."""
        logger.info("Shutting down...")
        await self.news_fetcher.close()
        self._running = False
    
    def generate_daily_plan(self, market_data: Dict = None, 
                           watchlist: List[str] = None) -> str:
        """
        Generate daily trading plan.
        
        Args:
            market_data: Market data dictionary
            watchlist: List of stocks to analyze
            
        Returns:
            Formatted trading plan report
        """
        logger.info("Generating daily trading plan...")
        
        if self.coordinator is None:
            return self._generate_basic_plan()
        
        try:
            market_data = market_data or self._get_sample_market_data()
            watchlist = watchlist or NIFTY_50_STOCKS[:20]

            # FIX BUG-1: Root cause — generate_daily_plan() is called from inside
            # run_async_main(), which means an asyncio event loop is ALREADY RUNNING
            # in this thread.  fetch_news_sync() internally calls asyncio.run(_fetch()),
            # which raises RuntimeError: "This event loop is already running".
            # Python then tries to display that error but _fetch is a coroutine that
            # was never awaited, producing:
            #   RuntimeWarning: coroutine 'fetch_news_sync.<locals>._fetch' was never awaited
            #
            # Fix: run fetch_news_sync() in a ThreadPoolExecutor — a new OS thread has
            # no running event loop, so asyncio.run() works there without conflict.
            # This is the exact same pattern used for Fyers async connect below.
            try:
                import concurrent.futures as _cf
                with _cf.ThreadPoolExecutor(max_workers=1) as _news_pool:
                    _news_summary = _news_pool.submit(fetch_news_sync, "all").result(timeout=30)
                _stock_news   = _news_summary.get("stock_news", {})
                _geo          = _news_summary.get("geopolitical", {})
                _combined_sentiment = _news_summary.get("combined_sentiment", 0.0)

                # Map combined_sentiment (−100 … +100) to the 5 KAIRO channels.
                # We don't have channel-level breakdown from RSS, so use a single
                # scalar scaled into the existing static proportions as a delta.
                _base = market_data.get("sentiment_data", {})
                _delta = _combined_sentiment * 0.5   # dampen: RSS score is noisy
                market_data["sentiment_data"] = {
                    "news":      max(-100, min(100, _base.get("news",      35) + _delta)),
                    "analyst":   max(-100, min(100, _base.get("analyst",   45) + _delta * 0.5)),
                    "social":    max(-100, min(100, _base.get("social",    25) + _delta * 0.3)),
                    "corporate": max(-100, min(100, _base.get("corporate", 20) + _delta * 0.4)),
                    "global":    max(-100, min(100, _base.get("global",    30) + _delta * 0.6)),
                }
                _geo_count = _geo.get("count", 0)
                _critical  = len([e for e in _geo.get("critical_events", [])
                                  if hasattr(e, "severity") and e.severity in ("critical", "high")])
                logger.info(
                    f"Live news loaded — sentiment delta: {_delta:+.1f} | "
                    f"geo events: {_geo_count} | critical: {_critical}"
                )
            except Exception as _news_err:
                # Non-fatal: static sentiment_data from _get_sample_market_data() is used
                logger.debug(f"Live news fetch skipped (using static fallback): {_news_err}")

            # L-07: Load real portfolio state so the risk dashboard reflects
            # actual open positions from previous runs, not always 0% deployed.
            portfolio_status = self._load_portfolio_state()
            
            plan = self.coordinator.generate_trading_plan(
                market_data=market_data,
                watchlist=watchlist,
                portfolio_status=portfolio_status,
            )
            
            report = self.coordinator.format_report(plan)
            
            if self.data_manager:
                self.data_manager.save_daily_report(report)

            # L-07: Persist portfolio state so next run sees real deployed capital.
            # Update the in-memory portfolio_status with anything PRUDENCE calculated
            # (e.g. new position sizes) so it accumulates across runs.
            updated_risk = plan.portfolio_risk
            portfolio_status["deployed_capital"] = (
                updated_risk.get("deployed_percent", 0) / 100 * self.portfolio_value
            )
            portfolio_status["cash"] = (
                updated_risk.get("cash_percent", 100) / 100 * self.portfolio_value
            )
            portfolio_status["portfolio_heat"]   = updated_risk.get("portfolio_heat", 0) / 100
            portfolio_status["current_drawdown"] = updated_risk.get("drawdown", 0) / 100
            self._save_portfolio_state(portfolio_status)
            
            logger.info("Daily trading plan generated successfully")

            # ── MARKET CONTEXT (built unconditionally) ─────────────────────
            # mctx is shared by both AI Brain and the F&O Brain rule-based
            # fallback.  Building it here — outside the brain.is_ready gate —
            # ensures the F&O extension always receives real PCR, VIX, and
            # regime data even when no LLM API key is configured.
            _deriv = market_data.get("derivatives_data", {})
            consensus_dict = {
                "direction":          str(plan.consensus.direction.value),
                "strength":           plan.consensus.strength,
                "net_score":          plan.consensus.net_score,
                "agreeing_agents":    plan.consensus.agreeing_agents,
                "disagreeing_agents": plan.consensus.disagreeing_agents,
            }
            setups_list = [
                {
                    "stock":       s.stock,
                    "direction":   str(s.direction.value),
                    "conviction":  s.conviction,
                    "entry_price": s.entry_price,
                    "stop_loss":   s.stop_loss,
                    "target1":     s.target_1,
                    "target2":     s.target_2,
                    "rr_ratio":    s.risk_reward,
                }
                for s in plan.top_setups
            ]
            mctx = {
                "nifty_price":       market_data.get("nifty_price", 0),
                "nifty_200dma":      market_data.get("nifty_200dma", 0),
                "india_vix":         market_data.get("india_vix", 0),
                "market_regime":     str(plan.market_regime.value),
                "regime_confidence": plan.regime_confidence,
                "pcr":               _deriv.get("pcr", 1.0),
                "iv_rank":           _deriv.get("iv_rank", 50),
                "max_pain":          _deriv.get("max_pain", 0),
            }
            # ── AI BRAIN ──────────────────────────────────────────────────
            # Synthesizes agent consensus + setups with the configured LLM.
            # Controlled entirely via .env (BRAIN_LLM_PROVIDER + API keys).
            try:
                from agents.ai_brain import AIBrain, print_brain_output
                brain = AIBrain()
                if brain.is_ready:
                    options_sig    = None
                    optimus_report = plan.agent_reports.get("OPTIMUS")
                    if optimus_report and "options_signal" in optimus_report.analysis_details:
                        options_sig = optimus_report.analysis_details["options_signal"]
                    brain_output = brain.synthesize_sync(
                        consensus      = consensus_dict,
                        setups         = setups_list,
                        market_context = mctx,
                        options_signal = options_sig,
                    )
                    print_brain_output(brain_output)
                else:
                    logger.info("AIBrain offline — configure BRAIN_LLM_PROVIDER + API key in .env")
            except Exception as _brain_err:
                logger.warning(f"AIBrain skipped: {_brain_err}")
            # ── END AI BRAIN ──────────────────────────────────────────────

            # ── F&O EXTENSION ─────────────────────────────────────────────
            # Greeks calc, Option Chain, Settlement check, Strategy Builder,
            # FNO Brain, and FNO Execution Engine (paper mode by default).
            try:
                from infrastructure.greeks_calculator import GreeksCalculator
                from infrastructure.option_chain_stream import OptionChainStream
                from infrastructure.physical_settlement_manager import PhysicalSettlementManager
                from agents.strategy_builders import StrategyFactory
                from agents.fno_brain_extension import FNOBrainExtension, print_fno_brain_output
                from execution.fno_execution_engine import FNOExecutionEngine

                calc   = GreeksCalculator()
                chain  = OptionChainStream()
                psm    = PhysicalSettlementManager()
                fno_exec = FNOExecutionEngine(
                    portfolio_value    = self.portfolio_value,
                    settlement_manager = psm,
                )
                factory = StrategyFactory()

                # Build option chain snapshot from existing market_data
                nifty_price = market_data.get("nifty_price", 0)
                deriv    = market_data.get("derivatives_data", {})
                snap     = chain.build_from_market_data("NIFTY", nifty_price, deriv)
                near     = snap.chains.get(snap.near_expiry)
                call_walls = near.call_walls[:2] if near else []
                put_walls  = near.put_walls[:2]  if near else []

                # Greeks for ATM straddle (indicative risk snapshot)
                dte   = 7
                iv    = market_data.get("india_vix", 15) / 100
                atm   = round(nifty_price / 50) * 50
                g_ce  = calc.calculate("CE", nifty_price, atm, dte, iv)
                g_pe  = calc.calculate("PE", nifty_price, atm, dte, iv)
                logger.info(
                    f"F&O Greeks (ATM {atm:.0f}): "
                    f"CE Δ={g_ce.delta:.3f} Θ={g_ce.theta:.1f}/day | "
                    f"PE Δ={g_pe.delta:.3f} Θ={g_pe.theta:.1f}/day"
                )

                # F&O Brain synthesis
                fno_brain = FNOBrainExtension()
                iv_rank   = deriv.get("iv_rank", 50)
                fno_ctx   = {
                    "iv_rank":                iv_rank,
                    "atm_iv":                 iv,
                    "call_walls":             [{"strike": w.strike, "strength": w.strength}
                                               for w in call_walls],
                    "put_walls":              [{"strike": w.strike, "strength": w.strength}
                                               for w in put_walls],
                    "pcr":                    deriv.get("pcr", 1.0),
                    "max_pain":               near.max_pain if near else atm,
                    "settlement_risk_present":False,
                    "dte_nearest_expiry":     dte,
                    "greeks_snapshot": {
                        "atm_strike":  atm,
                        "ce_delta":    round(g_ce.delta, 3),
                        "pe_delta":    round(g_pe.delta, 3),
                        "ce_theta":    round(g_ce.theta, 2),
                        "pe_theta":    round(g_pe.theta, 2),
                        "ce_vega":     round(g_ce.vega, 2),
                    },
                }

                fno_output = fno_brain.fno_synthesize_sync(
                    consensus      = consensus_dict,
                    equity_setups  = setups_list,
                    market_context = mctx,
                    fno_context    = fno_ctx,
                )
                print_fno_brain_output(fno_output)

                # Build and dry-run the top recommended strategy
                if fno_output.strategy_recommendations:
                    top_rec = fno_output.strategy_recommendations[0]
                    if top_rec.proceed:
                        strat_order = factory.build(
                            strategy_name = top_rec.strategy_name,
                            symbol        = "NIFTY",
                            spot          = nifty_price,
                            dte           = dte,
                            quantity      = 1,
                            lot_size      = calc.lot_size("NIFTY"),
                            iv            = iv,
                        )
                        if strat_order:
                            exec_result = fno_exec.submit_strategy(
                                strat_order, spot=nifty_price, dry_run=True
                            )
                            # max_profit is now always a real number (3× premium for
                            # straddle/strangle), never float("inf"). Safe to format.
                            logger.info(
                                f"F&O Strategy '{strat_order.strategy_name}' | "
                                f"max_profit=₹{strat_order.max_profit:,.0f} (3× target) | "
                                f"max_loss=₹{strat_order.max_loss:,.0f} | "
                                f"R:R={strat_order.risk_reward:.1f} | "
                                f"margin_est=₹{exec_result.margin_used:,.0f} | "
                                f"{exec_result.message}"
                            )

            except Exception as _fno_err:
                logger.warning(f"F&O extension skipped: {_fno_err}")
            # ── END F&O EXTENSION ──────────────────────────────────────────

            return report
            
        except Exception as e:
            logger.error(f"Error generating trading plan: {e}")
            return f"Error generating plan: {str(e)}"
    
    def _generate_basic_plan(self) -> str:
        """Generate a basic plan when full system is not available."""
        lines = []
        lines.append("=" * 65)
        lines.append("ROX EDGE ENGINE - DAILY TRADING PLAN")
        lines.append(f"Date: {datetime.now().strftime('%Y-%m-%d')}")
        lines.append("=" * 65)
        lines.append("")
        lines.append("NOTE: Full trading system requires additional dependencies.")
        lines.append("Please install all required packages from requirements.txt")
        lines.append("")
        lines.append("Run: pip install -r requirements.txt")
        lines.append("")
        return "\n".join(lines)
    
    def check_portfolio_status(self) -> str:
        """
        Check current portfolio status.
        
        Returns:
            Formatted portfolio status report
        """
        logger.info("Checking portfolio status...")
        
        if self.trade_logger is None:
            return "Portfolio tracking not available. Please install required dependencies."
        
        try:
            open_trades = self.trade_logger.get_open_trades()
            heat = self.trade_logger.calculate_portfolio_heat()
            stats = self.data_manager.get_trading_statistics(days=30)
            
            lines = []
            lines.append("=" * 50)
            lines.append("PORTFOLIO STATUS CHECK")
            lines.append(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
            lines.append("=" * 50)
            lines.append("")
            
            lines.append("OPEN POSITIONS:")
            if open_trades:
                for trade in open_trades:
                    lines.append(f"  {trade['stock']} | {trade['direction']} | Entry: {trade['entry_price']}")
                    lines.append(f"    SL: {trade['stop_loss']} | Target: {trade['target_price']}")
            else:
                lines.append("  No open positions")
            lines.append("")
            
            lines.append("RISK METRICS:")
            lines.append(f"  Portfolio Heat: {heat:.2f}% (Max: 8%)")
            lines.append(f"  Available Heat: {max(0, 8 - heat):.2f}%")
            lines.append("")
            
            lines.append("RECENT PERFORMANCE (30 days):")
            lines.append(f"  Total Trades: {stats['total']}")
            lines.append(f"  Win Rate: {stats['win_rate']*100:.1f}%")
            lines.append(f"  Total Return: {stats['total_return']:.2f}%")
            lines.append("")
            
            lines.append("ACTION ITEMS:")
            if heat > 6:
                lines.append("  [!] Portfolio heat elevated - reduce new position sizes")
            if not open_trades:
                lines.append("  [ ] No open positions - scan for new setups")
            else:
                lines.append("  [ ] Review stop losses for all open positions")
            
            return "\n".join(lines)
            
        except Exception as e:
            logger.error(f"Error checking portfolio status: {e}")
            return f"Error: {str(e)}"
    
    def generate_weekly_reconciliation(self) -> str:
        """
        Generate weekly reconciliation report.
        
        Returns:
            Formatted reconciliation report
        """
        logger.info("Generating weekly reconciliation...")
        
        if self.trade_logger is None:
            return "Weekly reconciliation requires additional dependencies."
        
        try:
            week_num = date.today().isocalendar()[1]
            report = self.trade_logger.generate_weekly_reconciliation(week_num)
            return report
        except Exception as e:
            logger.error(f"Error generating reconciliation: {e}")
            return f"Error: {str(e)}"
    
    async def fetch_geopolitical_news(self) -> Dict:
        """
        Fetch geopolitical news.
        
        Returns:
            Dictionary with geopolitical events
        """
        logger.info("Fetching geopolitical news...")
        
        try:
            events = await self.news_fetcher.fetch_geopolitical_news()
            
            lines = []
            lines.append("=" * 65)
            lines.append("GEOPOLITICAL NEWS UPDATE")
            lines.append(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
            lines.append("=" * 65)
            lines.append("")
            
            if not events:
                lines.append("No significant geopolitical events found.")
            else:
                for i, event in enumerate(events[:10], 1):
                    lines.append(f"EVENT #{i}: {event.title}")
                    lines.append(f"  Type: {event.event_type} | Severity: {event.severity.upper()}")
                    lines.append(f"  Countries: {', '.join(event.countries_involved[:3])}")
                    lines.append(f"  Market Impact: {event.market_impact}")
                    if event.affected_sectors:
                        lines.append(f"  Affected Sectors: {', '.join(event.affected_sectors[:3])}")
                    lines.append(f"  Source: {event.source}")
                    lines.append("")
            
            return {
                "report": "\n".join(lines),
                "events": [e.to_dict() for e in events],
                "count": len(events)
            }
            
        except Exception as e:
            logger.error(f"Error fetching geopolitical news: {e}")
            return {"report": f"Error: {str(e)}", "events": [], "count": 0}
    
    async def fetch_stock_news(self, stocks: List[str] = None) -> Dict:
        """
        Fetch stock price change news.
        
        Args:
            stocks: Optional list of specific stocks to filter
            
        Returns:
            Dictionary with stock news
        """
        logger.info("Fetching stock price news...")
        
        try:
            news_items = await self.news_fetcher.fetch_stock_price_news(stocks)
            
            lines = []
            lines.append("=" * 65)
            lines.append("STOCK PRICE CHANGE NEWS")
            lines.append(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
            lines.append("=" * 65)
            lines.append("")
            
            if not news_items:
                lines.append("No significant stock news found.")
            else:
                for i, news in enumerate(news_items[:10], 1):
                    lines.append(f"NEWS #{i}: {news.title}")
                    lines.append(f"  Stock: {news.stock} ({news.company_name})")
                    lines.append(f"  Type: {news.news_type} | Impact: {news.price_impact}")
                    lines.append(f"  Source: {news.source}")
                    lines.append("")
            
            return {
                "report": "\n".join(lines),
                "news_items": [n.to_dict() for n in news_items],
                "count": len(news_items)
            }
            
        except Exception as e:
            logger.error(f"Error fetching stock news: {e}")
            return {"report": f"Error: {str(e)}", "news_items": [], "count": 0}
    
    async def get_market_summary(self) -> Dict:
        """
        Get comprehensive market summary including all news.
        
        Returns:
            Dictionary with complete market summary
        """
        logger.info("Generating market summary...")
        
        try:
            summary = await self.news_fetcher.get_market_news_summary()
            
            lines = []
            lines.append("=" * 65)
            lines.append("ROX EDGE ENGINE - MARKET SUMMARY")
            lines.append(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
            lines.append("=" * 65)
            lines.append("")
            
            # Market impact assessment
            impact = summary.get('market_impact_assessment', {})
            lines.append("MARKET IMPACT ASSESSMENT:")
            lines.append(f"  Direction: {impact.get('direction', 'neutral').upper()}")
            lines.append(f"  Confidence: {impact.get('confidence', 50)}%")
            lines.append("")
            
            # Geopolitical summary
            geo = summary.get('geopolitical', {})
            lines.append("GEOPOLITICAL OVERVIEW:")
            lines.append(f"  Events Found: {geo.get('count', 0)}")
            if geo.get('critical_events'):
                lines.append("  CRITICAL EVENTS:")
                for event in geo['critical_events'][:3]:
                    lines.append(f"    - {event.title[:50]}...")
            lines.append("")
            
            # Stock news summary
            stock = summary.get('stock_news', {})
            lines.append("STOCK NEWS OVERVIEW:")
            lines.append(f"  News Items: {stock.get('count', 0)}")
            lines.append(f"  Sentiment: {stock.get('overall_sentiment', 0):.1f}")
            lines.append("")
            
            # Key factors
            if impact.get('key_factors'):
                lines.append("KEY FACTORS TO WATCH:")
                for factor in impact['key_factors'][:5]:
                    lines.append(f"  * {factor}")
            
            return {
                "report": "\n".join(lines),
                "summary": summary
            }
            
        except Exception as e:
            logger.error(f"Error generating market summary: {e}")
            return {"report": f"Error: {str(e)}", "summary": {}}
    
    def _get_sample_market_data(self) -> Dict:
        """
        Fetch market data — priority order:
          1. Fyers API  (if FYERS_ENABLED=true and token present)
          2. yfinance   (free, ~15 min delayed)
          3. Static defaults
        """
        import datetime as _dt

        # ── defaults ──────────────────────────────────────────────────────
        nifty_price  = 22500.0
        nifty_200dma = 21800.0
        india_vix    = 14.5
        price_data   = {}
        indicators   = {}

        end   = _dt.datetime.now()
        start = end - _dt.timedelta(days=365)

        # ── helper: build indicators from OHLCV list ───────────────────────
        def _indicators_from_ohlcv(sym: str, candles) -> tuple:
            """Returns (price_dict, indicator_dict) from a list of OHLCV objects."""
            if not candles or len(candles) < 20:
                return None, None
            import statistics
            closes  = [c.close  for c in candles]
            volumes = [c.volume for c in candles]
            highs   = [c.high   for c in candles]
            lows    = [c.low    for c in candles]

            sma20  = sum(closes[-20:]) / 20
            sma50  = sum(closes[-50:]) / 50  if len(closes) >= 50  else sma20
            sma200 = sum(closes[-200:]) / 200 if len(closes) >= 200 else sma50

            # RSI-14
            diffs = [closes[i] - closes[i-1] for i in range(1, len(closes))]
            gains = [max(0, d) for d in diffs[-14:]]
            losses= [max(0, -d) for d in diffs[-14:]]
            avg_g = sum(gains)  / 14
            avg_l = sum(losses) / 14
            rsi   = 100 - (100 / (1 + avg_g / avg_l)) if avg_l != 0 else 50.0

            # ATR-14
            tr_vals = []
            for i in range(1, min(15, len(candles))):
                tr_vals.append(max(
                    highs[-i] - lows[-i],
                    abs(highs[-i] - closes[-i-1]),
                    abs(lows[-i]  - closes[-i-1]),
                ))
            atr = sum(tr_vals) / len(tr_vals) if tr_vals else closes[-1] * 0.01

            last = candles[-1]
            avg_vol = int(sum(volumes[-20:]) / 20) if volumes else 0
            trend = ("UPTREND"   if closes[-1] > sma50 > sma200 else
                     "DOWNTREND" if closes[-1] < sma50 < sma200 else "SIDEWAYS")

            pd = {"open": last.open, "high": last.high, "low": last.low,
                  "close": last.close, "volume": last.volume,
                  "avg_volume": avg_vol, "atr": atr}
            ind = {"rsi": rsi, "sma20": sma20, "sma50": sma50, "sma200": sma200,
                   "atr": atr, "trend": trend,
                   "volume_ratio": last.volume / avg_vol if avg_vol > 0 else 1.0,
                   "above_200dma": closes[-1] > sma200}
            return pd, ind

        # ══════════════════════════════════════════════════════════════════
        # SOURCE 1 — Fyers API
        # ══════════════════════════════════════════════════════════════════
        fyers_ok = False
        if self.config.api.fyers_enabled and self.config.api.fyers_access_token:
            try:
                from infrastructure.data_feed import FyersProvider
                from infrastructure.historical_data_manager import HistoricalDataManager
                fyers = FyersProvider({
                    "client_id":    self.config.api.fyers_app_id,
                    "access_token": self.config.api.fyers_access_token,
                    "log_path":     "logs",
                })

                import asyncio
                import concurrent.futures
                # Run Fyers async connect in a separate thread to avoid
                # "cannot run loop while another loop is running" on Windows
                def _connect_sync():
                    _loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(_loop)
                    try:
                        return _loop.run_until_complete(fyers.connect())
                    finally:
                        _loop.close()

                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    connected = pool.submit(_connect_sync).result(timeout=15)

                if connected:
                    logger.info("Using Fyers API for market data")

                    # ── HistoricalDataManager: rate-limited + SQLite cache ──────
                    # Replaces 22 sequential get_historical_data_sync() calls with
                    # a smart cache that only downloads bars that aren't stored yet.
                    hdm = HistoricalDataManager(fyers)

                    all_symbols = ["NIFTY", "INDIAVIX"] + NIFTY_50_STOCKS[:20]

                    # Detect cold vs warm cache by checking if NIFTY bars exist
                    nifty_cached = "NIFTY|1d" in hdm.cache_stats()

                    if not nifty_cached:
                        # PRE-MARKET WARM-UP — runs once (first start of the day)
                        # Downloads full 365-day history for all symbols: ~22 API calls
                        logger.info("HDM: cold cache — running full warm-up (~22 API calls) ...")
                        hdm.warm_cache_sync(all_symbols, timeframe="1d", lookback_days=365)
                        logger.info("HDM: warm-up complete")
                    else:
                        # LIVE CYCLE REFRESH — only fetches today's new bars
                        # Typically 1 bar per symbol: ~22 API calls total regardless
                        # of how many cycles have run today
                        logger.info("HDM: warm cache — fetching today's delta ...")
                        hdm.refresh_today_sync(all_symbols, timeframe="1d")

                    # Capture stats AFTER warm-up/refresh so counts are accurate
                    cache_stats = hdm.cache_stats()

                    # ── NIFTY — read from SQLite, zero API calls ────────────────
                    nifty_candles = hdm.get_sync("NIFTY", "1d", lookback_days=365)
                    if nifty_candles and len(nifty_candles) >= 20:
                        nifty_price  = nifty_candles[-1]["close"]
                        nifty_200dma = (sum(c["close"] for c in nifty_candles[-200:])
                                        / min(200, len(nifty_candles)))
                        logger.info(f"Fyers Nifty: {nifty_price:.0f} | 200DMA: {nifty_200dma:.0f}")

                    # ── India VIX — read from SQLite ────────────────────────────
                    vix_candles = hdm.get_sync("INDIAVIX", "1d", lookback_days=30)
                    if vix_candles:
                        india_vix = vix_candles[-1]["close"]
                        logger.info(f"Fyers VIX: {india_vix:.1f}")

                    # ── Live quotes — still one fast REST call ──────────────────
                    watchlist = NIFTY_50_STOCKS[:20]
                    quotes = fyers.get_quotes(watchlist)

                    from collections import namedtuple
                    _Candle = namedtuple("Candle", ["open", "high", "low", "close", "volume"])

                    ohlcv_history = {}   # L-05: raw candle history for S/R detection

                    for sym, q in quotes.items():
                        if q.get("ltp", 0) > 0:
                            # Read full history from SQLite — zero API calls
                            raw_candles = hdm.get_sync(sym, "1d", lookback_days=365)
                            # Store raw dicts for ohlcv_history (S/R detection)
                            ohlcv_history[sym] = raw_candles
                            # Convert dicts → namedtuples so _indicators_from_ohlcv() works unchanged
                            ohlcv_compat = [
                                _Candle(c["open"], c["high"], c["low"], c["close"], c["volume"])
                                for c in raw_candles
                            ]
                            pd, ind = _indicators_from_ohlcv(sym, ohlcv_compat)
                            if pd and ind:
                                # Override with live LTP as before
                                pd["close"]  = q["ltp"]
                                pd["open"]   = q.get("open",   pd["open"])
                                pd["high"]   = q.get("high",   pd["high"])
                                pd["low"]    = q.get("low",    pd["low"])
                                pd["volume"] = q.get("volume", pd["volume"])
                                price_data[sym] = pd
                                indicators[sym] = ind

                    logger.info(f"Fyers: loaded {len(price_data)} stocks "
                                f"| HDM cache: {len(cache_stats)} series stored")
                    fyers_ok = True

            except Exception as e:
                logger.warning(f"Fyers data fetch failed: {e} — falling back to yfinance")

        # ══════════════════════════════════════════════════════════════════
        # SOURCE 2 — yfinance (fallback)
        # ══════════════════════════════════════════════════════════════════
        if not fyers_ok:
            try:
                import yfinance as yf
                import warnings
                warnings.filterwarnings("ignore", category=FutureWarning)

                nifty_df = yf.download("^NSEI", start=start, end=end,
                                       interval="1d", progress=False, auto_adjust=True)
                if not nifty_df.empty:
                    nifty_price  = float(nifty_df["Close"].iloc[-1])
                    nifty_200dma = float(nifty_df["Close"].tail(200).mean())
                    logger.info(f"yfinance Nifty: {nifty_price:.0f} | 200DMA: {nifty_200dma:.0f}")

                vix_df = yf.download("^INDIAVIX", start=start, end=end,
                                     interval="1d", progress=False, auto_adjust=True)
                if not vix_df.empty:
                    india_vix = float(vix_df["Close"].iloc[-1])
                    logger.info(f"yfinance VIX: {india_vix:.1f}")

                watchlist = NIFTY_50_STOCKS[:20]
                tickers   = [f"{s}.NS" for s in watchlist]
                raw = yf.download(tickers, start=start, end=end,
                                  interval="1d", progress=False, auto_adjust=True,
                                  group_by="ticker")

                ohlcv_history = {}   # L-05: raw candle history for S/R detection

                for sym, ticker in zip(watchlist, tickers):
                    try:
                        df = raw[ticker] if len(tickers) > 1 and ticker in raw.columns.get_level_values(0) else raw
                        if df is None or df.empty:
                            continue
                        from infrastructure.data_feed import OHLCV as _OHLCV
                        candles = []
                        for ts, row in df.iterrows():
                            try:
                                candles.append(_OHLCV(
                                    symbol=sym, timestamp=ts.to_pydatetime(),
                                    open=float(row["Open"]), high=float(row["High"]),
                                    low=float(row["Low"]),   close=float(row["Close"]),
                                    volume=int(row["Volume"]), timeframe="1d",
                                ))
                            except Exception:
                                pass
                        # Store raw dicts for ohlcv_history (S/R detection)
                        ohlcv_history[sym] = [
                            {"open": c.open, "high": c.high, "low": c.low,
                             "close": c.close, "volume": c.volume}
                            for c in candles
                        ]
                        pd_, ind_ = _indicators_from_ohlcv(sym, candles)
                        if pd_ and ind_:
                            price_data[sym] = pd_
                            indicators[sym] = ind_
                    except Exception as e:
                        logger.debug(f"yfinance parse error {sym}: {e}")

                logger.info(f"yfinance: loaded {len(price_data)} stocks")

            except ImportError:
                logger.warning("yfinance not installed — using static defaults")
            except Exception as e:
                logger.warning(f"yfinance error: {e} — using static defaults")

        # ── dynamic OI walls based on actual Nifty level ─────────────────
        atm = round(nifty_price / 50) * 50
        price_structure = "higher_highs" if nifty_price > nifty_200dma else "lower_lows"

        # Ensure ohlcv_history is always defined (will be empty for static fallback)
        if 'ohlcv_history' not in dir():
            ohlcv_history = {}

        # FIX BUG-3: fundamental_data was always an empty dict {}, so NEXUS
        # always reported "No stock fundamentals available" and defaulted to
        # NEUTRAL conviction for every stock.
        #
        # Fix: fetch per-stock fundamentals from yfinance .info for each symbol
        # that already has price_data (i.e. it downloaded successfully).
        # yfinance .info is a single cached HTTP call per ticker — no rate-limit
        # concern.  Fields map directly onto NEXUS's FundamentalData dataclass.
        # On failure (network down, delisted, etc.) we skip gracefully; NEXUS's
        # existing no-data guard keeps the system running with index-level proxy.
        fundamental_data: Dict = {}
        try:
            import yfinance as _yf
            import warnings as _warn
            _warn.filterwarnings("ignore", category=FutureWarning)

            _fund_watchlist = list(price_data.keys())   # only stocks we already loaded
            logger.info(f"Fetching yfinance fundamentals for {len(_fund_watchlist)} stocks...")

            for _sym in _fund_watchlist:
                try:
                    _ticker = _yf.Ticker(f"{_sym}.NS")
                    _info   = _ticker.info or {}

                    # Map yfinance fields → NEXUS FundamentalData fields
                    # returnOnEquity comes as a decimal (0.18 = 18%) — convert to %
                    _roe  = (_info.get("returnOnEquity")  or 0) * 100
                    _roa  = (_info.get("returnOnAssets")  or 0) * 100
                    # Use ROA as ROCE proxy when ROCE not directly available
                    _roce = (_info.get("returnOnCapitalEmployed") or _roa) * 100 \
                            if (_info.get("returnOnCapitalEmployed") or _roa) > 1 \
                            else (_info.get("returnOnCapitalEmployed") or _roa)

                    _d_e  = _info.get("debtToEquity") or 0          # already a ratio
                    _op_m = (_info.get("operatingMargins") or 0) * 100
                    _rev_g = (_info.get("revenueGrowth")  or 0) * 100
                    _earn_g = (_info.get("earningsGrowth") or 0) * 100
                    _pe   = _info.get("trailingPE")  or _info.get("forwardPE") or 0
                    _ind_pe = _info.get("industryPE") or 0          # rarely present
                    _peg  = _info.get("pegRatio")    or 0
                    _ev_ebitda = _info.get("enterpriseToEbitda") or 0
                    # promoterHolding is not in yfinance; use heldPercentInsiders as proxy
                    _promoter = (_info.get("heldPercentInsiders") or 0) * 100
                    # Interest coverage not directly in yfinance; default 0 → NEXUS skips
                    _int_cov = 0
                    _div_years = 1 if (_info.get("dividendYield") or 0) > 0 else 0

                    fundamental_data[_sym] = {
                        "pe_ratio":          round(_pe, 2),
                        "industry_pe":       round(_ind_pe, 2),
                        "historical_pe_avg": round(_pe * 0.9, 2),   # conservative proxy
                        "peg_ratio":         round(_peg, 2),
                        "ev_ebitda":         round(_ev_ebitda, 2),
                        "roe":               round(_roe, 2),
                        "roce":              round(_roce, 2),
                        "operating_margin":  round(_op_m, 2),
                        "revenue_cagr_3yr":  round(_rev_g, 2),
                        "pat_cagr_3yr":      round(_earn_g, 2),
                        "debt_equity":       round(_d_e / 100, 3) if _d_e > 10 else round(_d_e, 3),
                        "interest_coverage": _int_cov,
                        "promoter_holding":  round(_promoter, 2),
                        "promoter_pledging": 0.0,   # not in yfinance
                        "dividend_years":    _div_years,
                        "governance_issues": False,
                        "fcf_positive_years": 2 if (_info.get("freeCashflow") or 0) > 0 else 0,
                    }
                except Exception as _ferr:
                    logger.debug(f"Fundamental fetch skipped for {_sym}: {_ferr}")

            _loaded = len([k for k, v in fundamental_data.items() if v.get("roe", 0) > 0])
            logger.info(f"Fundamentals loaded: {_loaded}/{len(_fund_watchlist)} stocks with real data")

        except ImportError:
            logger.warning(
                "yfinance not installed — NEXUS will use market-level proxy. "
                "Install with: pip install yfinance"
            )
        except Exception as _fund_err:
            logger.warning(f"Fundamental data fetch failed: {_fund_err} — NEXUS using proxy")

        return {
            "nifty_price":     nifty_price,
            "nifty_200dma":    nifty_200dma,
            "price_structure": price_structure,
            "adx":             28,
            "india_vix":       india_vix,
            "nifty_pe":        22.5,
            "gsec_yield":      7.1,
            "flow_data": {
                "fii_cash_daily": 1500, "dii_cash_daily": 800,
                "fii_cash_5day":  4500, "dii_cash_5day":  2800,
                "flow_momentum":  500,
            },
            "sentiment_data": {
                "news": 35, "analyst": 45, "social": 25,
                "corporate": 20, "global": 30,
            },
            "derivatives_data": {
                "pcr":       1.05,
                "pcr_trend": "stable",
                "max_pain":  atm - 50,
                "iv_rank":   min(100, max(0, int((india_vix - 10) / 20 * 100))),
                "call_oi_walls": [
                    {"strike": atm + 300, "oi": 5000000, "strength": 0.8},
                    {"strike": atm + 500, "oi": 4000000, "strength": 0.6},
                ],
                "put_oi_walls": [
                    {"strike": atm - 300, "oi": 4500000, "strength": 0.7},
                    {"strike": atm - 500, "oi": 6000000, "strength": 0.9},
                ],
            },
            "event_data": {
                "events": [{
                    "name": "RBI Policy",
                    "date": (date.today() + _dt.timedelta(days=5)).isoformat(),
                    "impact": "HIGH",
                    "category": "MACRO_INDIA",
                }]
            },
            "price_data":       price_data,
            "indicators":       indicators,
            "fundamental_data": fundamental_data,   # FIX BUG-3: was always {}
            "ohlcv_history":    ohlcv_history,       # L-05: for ORION S/R detection
        }
    def run_test(self) -> str:
        """Run system test."""
        logger.info("Running system test...")
        
        lines = []
        lines.append("=" * 50)
        lines.append("ROX EDGE ENGINE SYSTEM TEST")
        lines.append("=" * 50)
        
        # Test 1: Configuration
        lines.append("\n1. Configuration Test: PASSED")
        lines.append(f"   Portfolio Value: {self.portfolio_value:,.2f}")
        
        # Test 2: Logging
        lines.append("\n2. Logging Test: PASSED")
        logger.info("Test log message")
        
        # Test 3: News Fetcher
        lines.append("\n3. News Fetcher: Initializing...")
        lines.append("   (Use 'news' command to test)")
        
        # Test 4: Agents (if available)
        if self.coordinator:
            lines.append("\n4. Agent System Test:")
            for name, agent in self.coordinator.agents.items():
                lines.append(f"   {name}: {agent.domain} (weight: {agent.current_weight:.1%})")
            
            # Test regime detection
            market_data = self._get_sample_market_data()
            regime, confidence = self.coordinator._tier_11_detect_regime(market_data)
            lines.append(f"\n5. Regime Detection: {regime.value} (confidence: {confidence}%)")
        else:
            lines.append("\n4. Agent System: Not available (install dependencies)")
        
        lines.append("\n" + "=" * 50)
        lines.append("System test completed!")
        
        return "\n".join(lines)


async def run_async_main():
    """Main async entry point."""
    parser = argparse.ArgumentParser(
        description="ROX Proven Edge Engine v3.0 - Multi-Agent Swing Trading System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py plan                    # Generate daily trading plan
  python main.py news --type geopolitical # Fetch geopolitical news
  python main.py news --type stock        # Fetch stock price news
  python main.py news --type all          # Fetch all news
  python main.py summary                  # Get market summary
  python main.py status                   # Check portfolio status
  python main.py test                     # Run system test
        """
    )
    
    parser.add_argument(
        "command",
        choices=["plan", "status", "weekly", "test", "news", "summary"],
        help="Command to execute"
    )
    
    parser.add_argument(
        "--portfolio", "-p",
        type=float,
        default=None,
        help="Portfolio value in rupees"
    )
    
    parser.add_argument(
        "--watchlist", "-w",
        nargs="+",
        help="Watchlist of stocks to analyze"
    )
    
    parser.add_argument(
        "--type", "-t",
        choices=["geopolitical", "stock", "all"],
        default="all",
        help="Type of news to fetch"
    )
    
    parser.add_argument(
        "--output", "-o",
        choices=["text", "json"],
        default="text",
        help="Output format"
    )
    
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose logging"
    )
    
    args = parser.parse_args()
    
    # Adjust log level if verbose
    if args.verbose:
        import logging
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Initialize engine
    engine = ROXEdgeEngine(portfolio_value=args.portfolio)
    await engine.initialize()
    
    try:
        # Execute command
        if args.command == "plan":
            report = engine.generate_daily_plan(watchlist=args.watchlist)
            print(report)
            
        elif args.command == "status":
            report = engine.check_portfolio_status()
            print(report)
            
        elif args.command == "weekly":
            report = engine.generate_weekly_reconciliation()
            print(report)
            
        elif args.command == "test":
            report = engine.run_test()
            print(report)
            
        elif args.command == "news":
            if args.type == "geopolitical":
                result = await engine.fetch_geopolitical_news()
            elif args.type == "stock":
                result = await engine.fetch_stock_news()
            else:
                result = await engine.get_market_summary()
            
            if args.output == "json":
                import json
                print(json.dumps(result.get("summary", result), indent=2, default=str))
            else:
                print(result.get("report", ""))
            
        elif args.command == "summary":
            result = await engine.get_market_summary()
            if args.output == "json":
                import json
                print(json.dumps(result.get("summary", {}), indent=2, default=str))
            else:
                print(result.get("report", ""))
                
    finally:
        await engine.shutdown()


def main():
    """Main entry point."""
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    try:
        asyncio.run(run_async_main())
    except KeyboardInterrupt:
        print("\nShutdown requested by user.")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
