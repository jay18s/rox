"""
ROX Proven Edge Engine v4.0 — Macro Data Fetcher
=================================================
Fetches real FII/DII institutional flow data, Nifty P/E ratio,
and India 10-year G-sec yield to feed VESPER and NEXUS agents.

Data sources (all free, no API key required):
    FII/DII flows  — NSE India public JSON API
    Nifty P/E      — yfinance (^NSEI trailingPE) with NSE fallback
    G-sec yield    — yfinance (^IRX proxy) + hardcoded fallback

Cache strategy (same as fyers_fetcher):
    Macro data changes at end-of-day; cached once per calendar day.
    Each 60s live cycle reuses the in-memory cache.

Usage:
    from data.macro_fetcher import MacroFetcher
    fetcher = MacroFetcher()                # create once
    macro   = fetcher.fetch()              # call each cycle (cached intraday)

    # Returns dict with keys:
    #   flow_data   : {fii_cash_5day, dii_cash_5day, fii_cash_daily,
    #                  dii_cash_daily, fii_cash_3day, dii_cash_3day,
    #                  flow_momentum, fii_derivative_daily}
    #   nifty_pe    : float
    #   gsec_yield  : float   (10Y, percent)
"""

import logging
import time
from datetime import date, datetime, timedelta
from typing import Dict, Any, List, Optional

logger = logging.getLogger("MacroFetcher")

# ── NSE public endpoints (no auth, but require browser-like headers) ─────────
_NSE_BASE    = "https://www.nseindia.com"
_NSE_FII_DII = f"{_NSE_BASE}/api/fiidiiTradeReact"
_NSE_INDICES = f"{_NSE_BASE}/api/allIndices"

_HEADERS = {
    "User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/120.0.0.0 Safari/537.36",
    "Accept":          "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer":         "https://www.nseindia.com/",
}


class MacroFetcher:
    """
    Fetches macro market data (FII/DII flows, Nifty PE, G-sec yield).
    Designed to be instantiated once and reused across 60s cycles.
    All data is cached for the calendar day — only one real fetch per day.
    """

    def __init__(self, timeout: int = 10):
        self.timeout = timeout
        self._session = self._make_session()

        # Daily cache
        self._cache: Optional[Dict[str, Any]] = None
        self._cache_date: Optional[date]      = None

    # ── Public API ────────────────────────────────────────────────────────────

    def fetch(self) -> Dict[str, Any]:
        """
        Return macro data dict. Uses in-memory cache during the day.
        Forces a fresh fetch once per calendar day.
        """
        today = date.today()
        if self._cache_date == today and self._cache is not None:
            logger.debug("MacroFetcher: using daily cache")
            return self._cache

        logger.info("MacroFetcher: fetching fresh macro data...")
        data = self._fetch_all()
        self._cache      = data
        self._cache_date = today
        logger.info(
            f"MacroFetcher: FII 5d={data['flow_data']['fii_cash_5day']:+,.0f} Cr | "
            f"DII 5d={data['flow_data']['dii_cash_5day']:+,.0f} Cr | "
            f"PE={data['nifty_pe']:.1f} | yield={data['gsec_yield']:.2f}%"
        )
        return data

    # ── Internal orchestration ────────────────────────────────────────────────

    def _fetch_all(self) -> Dict[str, Any]:
        flow_data  = self._fetch_fii_dii()
        nifty_pe   = self._fetch_nifty_pe()
        gsec_yield = self._fetch_gsec_yield()
        return {
            "flow_data":  flow_data,
            "nifty_pe":   nifty_pe,
            "gsec_yield": gsec_yield,
        }

    # ── FII / DII flows ───────────────────────────────────────────────────────

    def _fetch_fii_dii(self) -> Dict[str, float]:
        """
        Fetch last 5 days of FII/DII cash segment data from NSE.
        NSE returns rows like:
            {date, buyValue, sellValue, netValue, category}
        where category is "FII/FPI" or "DII".
        """
        try:
            resp = self._session.get(_NSE_FII_DII, timeout=self.timeout)
            resp.raise_for_status()
            rows = resp.json()             # list of dicts

            fii_daily: List[float] = []
            dii_daily: List[float] = []

            for row in rows:
                cat = row.get("category", "").upper()
                net = self._parse_cr(row.get("netValue", 0))
                if "FII" in cat or "FPI" in cat:
                    fii_daily.append(net)
                elif "DII" in cat:
                    dii_daily.append(net)

            # NSE returns ~10 rows (5 FII + 5 DII), most-recent first
            fii_daily = fii_daily[:5]
            dii_daily = dii_daily[:5]

            return self._build_flow_dict(fii_daily, dii_daily)

        except Exception as e:
            logger.warning(f"FII/DII fetch failed ({e}), using zeros")
            return self._zero_flow()

    def _build_flow_dict(self, fii_daily: List[float],
                         dii_daily: List[float]) -> Dict[str, float]:
        """Aggregate daily FII/DII series into the fields VESPER expects."""
        def safe_sum(lst, n):
            return round(sum(lst[:n]), 2) if lst else 0.0

        fii_1 = fii_daily[0] if fii_daily else 0.0
        dii_1 = dii_daily[0] if dii_daily else 0.0
        fii_3 = safe_sum(fii_daily, 3)
        dii_3 = safe_sum(dii_daily, 3)
        fii_5 = safe_sum(fii_daily, 5)
        dii_5 = safe_sum(dii_daily, 5)

        # Momentum: change from day-3 sum to day-1 sum (annualised direction)
        fii_3_prev = safe_sum(fii_daily[1:], 3) if len(fii_daily) > 1 else fii_3
        momentum   = round(fii_3 - fii_3_prev, 2)

        return {
            "fii_cash_daily":      fii_1,
            "dii_cash_daily":      dii_1,
            "fii_cash_3day":       fii_3,
            "dii_cash_3day":       dii_3,
            "fii_cash_5day":       fii_5,
            "dii_cash_5day":       dii_5,
            "flow_momentum":       momentum,
            "fii_derivative_daily": 0.0,   # NSE API doesn't expose F&O flows
        }

    @staticmethod
    def _zero_flow() -> Dict[str, float]:
        return {
            "fii_cash_daily": 0.0, "dii_cash_daily": 0.0,
            "fii_cash_3day":  0.0, "dii_cash_3day":  0.0,
            "fii_cash_5day":  0.0, "dii_cash_5day":  0.0,
            "flow_momentum":  0.0, "fii_derivative_daily": 0.0,
        }

    @staticmethod
    def _parse_cr(value) -> float:
        """Parse NSE crore values that may come as strings with commas."""
        try:
            return float(str(value).replace(",", ""))
        except (ValueError, TypeError):
            return 0.0

    # ── Nifty P/E ─────────────────────────────────────────────────────────────

    def _fetch_nifty_pe(self) -> float:
        """
        Fetch current Nifty 50 trailing P/E.
        Primary  : yfinance  ^NSEI trailingPE
        Fallback : NSE allIndices endpoint (pe field)
        Default  : 22.5
        """
        # Try yfinance first
        pe = self._nifty_pe_yfinance()
        if pe and 10 < pe < 60:
            return round(pe, 2)

        # Try NSE indices endpoint
        pe = self._nifty_pe_nse()
        if pe and 10 < pe < 60:
            return round(pe, 2)

        logger.warning("Nifty PE unavailable, using default 22.5")
        return 22.5

    def _nifty_pe_yfinance(self) -> Optional[float]:
        try:
            import yfinance as yf
            ticker = yf.Ticker("^NSEI")
            pe = ticker.info.get("trailingPE")
            if pe:
                logger.debug(f"Nifty PE from yfinance: {pe}")
            return float(pe) if pe else None
        except Exception as e:
            logger.debug(f"yfinance PE fetch failed: {e}")
            return None

    def _nifty_pe_nse(self) -> Optional[float]:
        """Fallback: scrape PE from NSE allIndices response."""
        try:
            resp = self._session.get(_NSE_INDICES, timeout=self.timeout)
            resp.raise_for_status()
            data = resp.json()
            for idx in data.get("data", []):
                if "NIFTY 50" in idx.get("indexSymbol", "").upper():
                    pe = idx.get("pe")
                    if pe:
                        logger.debug(f"Nifty PE from NSE: {pe}")
                        return float(pe)
        except Exception as e:
            logger.debug(f"NSE PE fetch failed: {e}")
        return None

    # ── G-sec yield ───────────────────────────────────────────────────────────

    def _fetch_gsec_yield(self) -> float:
        """
        Fetch India 10-year G-sec yield.
        Primary  : yfinance IN10Y=RR  (Reuters code for India 10Y bond)
        Fallback : yfinance ^IRX (US 13-week T-bill) — not ideal, skip
        Default  : 7.0 (approximate current India 10Y yield)
        """
        yield_ = self._gsec_yfinance("IN10Y=RR")
        if yield_ and 4 < yield_ < 15:
            return round(yield_, 2)

        # Secondary ticker sometimes used
        yield_ = self._gsec_yfinance("GSPC10YT=RR")
        if yield_ and 4 < yield_ < 15:
            return round(yield_, 2)

        logger.warning("G-sec yield unavailable, using default 7.0%")
        return 7.0

    def _gsec_yfinance(self, ticker_sym: str) -> Optional[float]:
        try:
            import yfinance as yf
            ticker = yf.Ticker(ticker_sym)
            price  = ticker.info.get("regularMarketPrice") or \
                     ticker.info.get("previousClose")
            if price:
                logger.debug(f"G-sec yield from yfinance ({ticker_sym}): {price}")
                return float(price)
        except Exception as e:
            logger.debug(f"yfinance yield fetch ({ticker_sym}) failed: {e}")
        return None

    # ── HTTP session ──────────────────────────────────────────────────────────

    def _make_session(self):
        """
        Build a requests.Session with NSE-compatible headers and a
        session cookie (NSE requires a cookie obtained from the homepage).
        """
        import requests
        session = requests.Session()
        session.headers.update(_HEADERS)

        # Warm up NSE session cookie — NSE blocks requests without a prior
        # homepage visit. Ignore failures; FII/DII endpoint may still work.
        try:
            session.get(_NSE_BASE, timeout=8)
        except Exception:
            pass

        return session
