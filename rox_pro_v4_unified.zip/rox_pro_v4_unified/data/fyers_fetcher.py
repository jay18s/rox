"""
ROX Proven Edge Engine v4.0 — Fyers Live Data Fetcher
======================================================
Fetches real-time and historical market data from the Fyers API
and returns it in the exact schema expected by UnifiedCoordinator
/ LeadCoordinator.generate_trading_plan().

Required .env keys (populated by fyers_login.py):
    FYERS_APP_ID        — e.g.  XYZ123-100
    FYERS_ACCESS_TOKEN  — refreshed daily via fyers_login.py
    FYERS_ENABLED       — must be "true"

Performance design
------------------
- The Fyers client is created ONCE and reused across all cycles.
- OHLCV history (60+ days of daily bars, used for SMA/ATR/RSI) is
  fetched once per calendar day and cached in memory. This reduces
  each 60-second cycle from ~50 API calls to just 1 quotes batch
  call + 1 option-chain call (~2-3 seconds total).
- Quotes (LTP, OHLC, volume) are fetched fresh every cycle.

Usage (internal — called by ROXUnifiedEngine._fetch_live_data):
    from data.fyers_fetcher import FyersFetcher
    fetcher = FyersFetcher(api_config)          # create once
    data = fetcher.fetch_market_data()          # call every cycle
"""

import logging
import time
from datetime import datetime, date, timedelta
from typing import Dict, Any, List, Optional

logger = logging.getLogger("FyersFetcher")

# Macro data (FII/DII, PE, yield) — fetched via separate fetcher, cached daily
_macro_fetcher = None
def _get_macro_fetcher():
    global _macro_fetcher
    if _macro_fetcher is None:
        from data.macro_fetcher import MacroFetcher
        _macro_fetcher = MacroFetcher()
    return _macro_fetcher

# ── Fyers symbol format helpers ──────────────────────────────────────────────

NSE_PREFIX  = "NSE:"
BSE_PREFIX  = "BSE:"
INDEX_NIFTY = "NSE:NIFTY50-INDEX"
INDEX_VIX   = "NSE:INDIAVIX-INDEX"
INDEX_BANKNIFTY = "NSE:NIFTYBANK-INDEX"

def _eq(symbol: str) -> str:
    """Convert bare ticker to Fyers NSE equity symbol."""
    return f"{NSE_PREFIX}{symbol}-EQ"

def _index(symbol: str) -> str:
    return f"{NSE_PREFIX}{symbol}-INDEX"


# ── Simple SMA / ATR helpers (computed from OHLCV history) ──────────────────

def _sma(closes: List[float], period: int) -> float:
    if len(closes) < period:
        return closes[-1] if closes else 0.0
    return sum(closes[-period:]) / period

def _atr(candles: List[Dict], period: int = 14) -> float:
    """Average True Range over last `period` bars."""
    trs = []
    for i in range(1, len(candles)):
        h = candles[i]["high"]; l = candles[i]["low"]; pc = candles[i-1]["close"]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    if not trs:
        return candles[-1]["close"] * 0.015
    return sum(trs[-period:]) / min(len(trs), period)

def _rsi(closes: List[float], period: int = 14) -> float:
    if len(closes) < period + 1:
        return 50.0
    deltas = [closes[i] - closes[i-1] for i in range(1, len(closes))]
    gains  = [d for d in deltas[-period:] if d > 0]
    losses = [-d for d in deltas[-period:] if d < 0]
    avg_gain = sum(gains) / period if gains else 0
    avg_loss = sum(losses) / period if losses else 1e-9
    rs = avg_gain / avg_loss
    return round(100 - 100 / (1 + rs), 2)

def _trend(close: float, sma20: float, sma50: float, sma200: float) -> str:
    if close > sma20 > sma50 > sma200:
        return "UPTREND"
    if close < sma20 < sma50 < sma200:
        return "DOWNTREND"
    return "SIDEWAYS"

def _adx_approx(candles: List[Dict], period: int = 14) -> float:
    """Simplified ADX approximation from ATR and directional range."""
    if len(candles) < period + 1:
        return 20.0
    dm_plus_list, dm_minus_list, tr_list = [], [], []
    for i in range(1, len(candles)):
        h, l, ph, pl = candles[i]["high"], candles[i]["low"], candles[i-1]["high"], candles[i-1]["low"]
        pc = candles[i-1]["close"]
        up   = h - ph; down = pl - l
        dm_plus_list.append(up if up > down and up > 0 else 0)
        dm_minus_list.append(down if down > up and down > 0 else 0)
        tr_list.append(max(h - l, abs(h - pc), abs(l - pc)))
    atr14 = sum(tr_list[-period:]) / period or 1e-9
    di_plus  = (sum(dm_plus_list[-period:]) / period) / atr14 * 100
    di_minus = (sum(dm_minus_list[-period:]) / period) / atr14 * 100
    dx = abs(di_plus - di_minus) / (di_plus + di_minus + 1e-9) * 100
    return round(dx, 1)


# ── Main fetcher class ───────────────────────────────────────────────────────

class FyersFetcher:
    """
    Fetches live market data from Fyers API and returns it in the
    shape expected by coordinator.generate_trading_plan().

    Parameters
    ----------
    api_config : APIConfig
        Must have fyers_app_id and fyers_access_token populated.
    watchlist : list[str], optional
        NSE tickers to fetch (bare symbols, e.g. "RELIANCE").
        Defaults to Nifty 50.
    history_days : int
        Number of calendar days of OHLCV history to fetch for
        indicator calculation (default 60 → enough for SMA-50).
    """

    def __init__(self, api_config, watchlist: Optional[List[str]] = None,
                 history_days: int = 60):
        self.api_config   = api_config
        self.history_days = history_days

        from config import NIFTY_50_STOCKS
        self.watchlist = watchlist or NIFTY_50_STOCKS

        # History cache: rebuilt once per calendar day, reused every 60s cycle
        self._history_cache: Dict[str, List[Dict]] = {}
        self._history_cache_date: Optional[date]   = None

        self._fyers = self._init_client()

    # ── Fyers client ─────────────────────────────────────────────────────────

    def _init_client(self):
        try:
            from fyers_apiv3 import fyersModel
        except ImportError:
            raise RuntimeError(
                "fyers-apiv3 not installed. Run: pip install fyers-apiv3"
            )
        client_id    = self.api_config.fyers_app_id or self.api_config.fyers_api_key
        access_token = self.api_config.fyers_access_token
        if not client_id or not access_token:
            raise RuntimeError(
                "FYERS_APP_ID and FYERS_ACCESS_TOKEN must be set in .env. "
                "Run fyers_login.py first."
            )
        fyers = fyersModel.FyersModel(
            client_id=client_id,
            token=access_token,
            log_path="logs",
            is_async=False,
        )
        logger.info(f"Fyers client initialised | app_id={client_id[:8]}...")
        return fyers

    # ── Public API ───────────────────────────────────────────────────────────

    def fetch_market_data(self) -> Dict[str, Any]:
        """
        Fetch all required data and return in coordinator schema.

        Fast path (every 60s cycle):
          - 1 quotes batch call  — LTP, OHLC, volume for all stocks + indices
          - 1 option-chain call  — PCR, OI walls, max pain

        Slow path (once per calendar day, cached):
          - 51 history calls     — 60+ days of daily OHLCV bars for
                                   SMA/ATR/RSI/ADX calculation
        """
        today = date.today()

        # ── Slow path: rebuild history cache once per day ─────────────────
        if self._history_cache_date != today or not self._history_cache:
            logger.info("Fetching OHLCV history (daily cache refresh)...")
            self._history_cache      = self._fetch_history_all()
            self._history_cache_date = today
            logger.info(f"History cached for {len(self._history_cache)} symbols")
        else:
            logger.debug("Using cached OHLCV history")

        ohlcv_history = self._history_cache

        # ── Fast path: fresh quotes every cycle ───────────────────────────
        logger.info("Fetching live quotes from Fyers...")
        quotes      = self._fetch_quotes()
        nifty_quote = quotes.get("NIFTY50", {})
        vix_quote   = quotes.get("INDIAVIX", {})

        nifty_price = nifty_quote.get("ltp", 22500.0)
        india_vix   = vix_quote.get("ltp", 15.0)

        # 3. Build per-stock price_data and indicators
        price_data = {}
        indicators = {}
        for sym in self.watchlist:
            q       = quotes.get(sym, {})
            candles = ohlcv_history.get(sym, [])
            closes  = [c["close"] for c in candles]

            close  = q.get("ltp", closes[-1] if closes else 0.0)
            open_  = q.get("open_price", close)
            high   = q.get("high_price",  close * 1.01)
            low    = q.get("low_price",   close * 0.99)
            volume = q.get("volume", 0)
            atr    = _atr(candles) if len(candles) > 2 else close * 0.015

            # Use last 30d avg volume as avg_volume
            avg_vol = (
                int(sum(c["volume"] for c in candles[-30:]) / 30)
                if len(candles) >= 30 else max(volume, 1)
            )

            price_data[sym] = {
                "close": close, "open": open_,
                "high": high,   "low": low,
                "volume": volume, "avg_volume": avg_vol, "atr": atr,
            }

            sma20  = _sma(closes, 20)
            sma50  = _sma(closes, 50)
            sma200 = _sma(closes, 200)
            rsi    = _rsi(closes)
            adx    = _adx_approx(candles)
            trend  = _trend(close, sma20, sma50, sma200)
            vol_ratio = volume / avg_vol if avg_vol > 0 else 1.0

            indicators[sym] = {
                "rsi": rsi, "sma20": sma20, "sma50": sma50, "sma200": sma200,
                "atr": atr, "adx": adx, "trend": trend,
                "volume_ratio": round(vol_ratio, 2),
            }

        # 4. Nifty 200-DMA from history
        nifty_candles = ohlcv_history.get("NIFTY50", [])
        nifty_closes  = [c["close"] for c in nifty_candles]
        nifty_200dma  = _sma(nifty_closes, 200)
        nifty_adx     = _adx_approx(nifty_candles)

        price_structure = (
            "higher_highs"  if nifty_price > nifty_200dma * 1.02 else
            "lower_lows"    if nifty_price < nifty_200dma * 0.98 else
            "neutral"
        )

        # 5. Derivatives data (PCR, OI walls)
        derivatives_data = self._fetch_derivatives(nifty_price, india_vix)

        # 6. Real FII/DII flow, Nifty PE, G-sec yield from MacroFetcher
        try:
            macro     = _get_macro_fetcher().fetch()
            flow_data = macro["flow_data"]
            nifty_pe  = macro["nifty_pe"]
            gsec_yield = macro["gsec_yield"]
        except Exception as e:
            logger.warning(f"MacroFetcher failed ({e}), using defaults")
            flow_data  = self._fetch_flow_data()
            nifty_pe   = 22.5
            gsec_yield = 7.0

        logger.info(
            f"Live data fetched | Nifty={nifty_price:.0f} | "
            f"VIX={india_vix:.1f} | stocks={len(price_data)} | "
            f"FII 5d={flow_data.get('fii_cash_5day', 0):+,.0f}Cr | "
            f"PE={nifty_pe:.1f} | yield={gsec_yield:.2f}%"
        )

        return {
            "nifty_price":      nifty_price,
            "nifty_200dma":     nifty_200dma if nifty_200dma > 0 else nifty_price * 0.95,
            "india_vix":        india_vix,
            "adx":              nifty_adx,
            "price_structure":  price_structure,
            "nifty_pe":         nifty_pe,
            "gsec_yield":       gsec_yield,
            "price_data":       price_data,
            "indicators":       indicators,
            "flow_data":        flow_data,
            "sentiment_data":   {"news": 50, "analyst": 50, "social": 50, "global": 50},
            "derivatives_data": derivatives_data,
            "fundamental_data": {},
            "event_data":       {"events": []},
            "ohlcv_history":    ohlcv_history,
        }

    # ── Fyers API calls ───────────────────────────────────────────────────────

    def _fetch_quotes(self) -> Dict[str, Dict]:
        """
        Fetch LTP + OHLC for all watchlist stocks plus Nifty/VIX indices.
        Returns dict keyed by bare symbol.
        """
        # Build symbol list: stocks + indices
        stock_symbols = [_eq(s) for s in self.watchlist]
        index_symbols = [INDEX_NIFTY, INDEX_VIX, INDEX_BANKNIFTY]
        all_symbols   = stock_symbols + index_symbols

        # Fyers quotes API accepts comma-separated symbols (max 50 per call)
        result = {}
        batch_size = 50
        for i in range(0, len(all_symbols), batch_size):
            batch = all_symbols[i:i + batch_size]
            try:
                resp = self._fyers.quotes({"symbols": ",".join(batch)})
                if resp.get("s") != "ok":
                    logger.warning(f"Quotes API error: {resp.get('message', resp)}")
                    continue
                for item in resp.get("d", []):
                    v   = item.get("v", {})
                    sym = item.get("n", "")
                    # strip exchange prefix and -EQ / -INDEX suffix
                    bare = sym.replace("NSE:", "").replace("BSE:", "")
                    bare = bare.replace("-EQ", "").replace("-INDEX", "")
                    result[bare] = {
                        "ltp":         v.get("lp",  v.get("close_price", 0)),
                        "open_price":  v.get("open_price",  0),
                        "high_price":  v.get("high_price",  0),
                        "low_price":   v.get("low_price",   0),
                        "volume":      v.get("volume", 0),
                        "prev_close":  v.get("prev_close_price", 0),
                        "change_pct":  v.get("ch", 0),
                    }
            except Exception as e:
                logger.error(f"Quote fetch error (batch {i//batch_size}): {e}")
            time.sleep(0.3)      # rate limit
        return result

    def _fetch_history_all(self) -> Dict[str, List[Dict]]:
        """
        Fetch daily OHLCV history for all stocks + Nifty index.
        Called once per calendar day; result is cached in memory.
        Returns {symbol: [{date,open,high,low,close,volume}, ...]}
        """
        end_date   = date.today()
        start_date = end_date - timedelta(days=self.history_days + 30)  # buffer for weekends

        ohlcv = {}
        symbols_to_fetch = self.watchlist + ["NIFTY50"]
        total = len(symbols_to_fetch)
        for i, sym in enumerate(symbols_to_fetch, 1):
            fyers_sym = INDEX_NIFTY if sym == "NIFTY50" else _eq(sym)
            candles   = self._fetch_candles(fyers_sym, start_date, end_date)
            if candles:
                ohlcv[sym] = candles
            if i % 10 == 0 or i == total:
                logger.info(f"  History progress: {i}/{total} symbols fetched")
            time.sleep(0.2)
        return ohlcv

    def _fetch_candles(self, fyers_symbol: str,
                       start: date, end: date) -> List[Dict]:
        """Fetch daily OHLCV candles for one symbol."""
        try:
            data = {
                "symbol":      fyers_symbol,
                "resolution":  "D",
                "date_format": "1",     # epoch timestamps
                "range_from":  start.strftime("%Y-%m-%d"),
                "range_to":    end.strftime("%Y-%m-%d"),
                "cont_flag":   "1",
            }
            resp = self._fyers.history(data)
            if resp.get("s") != "ok":
                logger.debug(f"History error for {fyers_symbol}: {resp.get('message')}")
                return []
            candles = []
            for bar in resp.get("candles", []):
                # bar = [epoch, open, high, low, close, volume]
                ts, o, h, l, c, v = bar
                candles.append({
                    "date":   datetime.fromtimestamp(ts).strftime("%Y-%m-%d"),
                    "open":   float(o), "high": float(h),
                    "low":    float(l), "close": float(c),
                    "volume": int(v),
                })
            return candles
        except Exception as e:
            logger.error(f"Candle fetch error ({fyers_symbol}): {e}")
            return []

    def _fetch_derivatives(self, nifty_price: float,
                           india_vix: float) -> Dict[str, Any]:
        """
        Fetch Nifty option chain for PCR, max pain, and OI walls.
        Falls back to sensible defaults if the endpoint is unavailable.
        """
        try:
            resp = self._fyers.optionchain({
                "symbol":      INDEX_NIFTY,
                "strikecount": 10,
                "timestamp":   "",
            })
            if resp.get("s") != "ok":
                raise ValueError(resp.get("message", "option chain error"))

            data   = resp.get("data", {})
            chain  = data.get("optionsChain", [])

            total_call_oi = 0; total_put_oi = 0
            call_oi_by_strike: Dict[float, int] = {}
            put_oi_by_strike:  Dict[float, int] = {}
            max_pain_map:      Dict[float, float] = {}

            atm = round(nifty_price / 50) * 50     # nearest 50-pt strike

            for row in chain:
                strike = float(row.get("strike_price", 0))
                c_oi   = int(row.get("call_oi", 0))
                p_oi   = int(row.get("put_oi",  0))
                total_call_oi += c_oi
                total_put_oi  += p_oi
                call_oi_by_strike[strike] = c_oi
                put_oi_by_strike[strike]  = p_oi

                # Max pain: sum of losses for both sides at each expiry strike
                call_loss = sum(
                    max(0, s - strike) * oi
                    for s, oi in call_oi_by_strike.items()
                )
                put_loss  = sum(
                    max(0, strike - s) * oi
                    for s, oi in put_oi_by_strike.items()
                )
                max_pain_map[strike] = call_loss + put_loss

            pcr = round(total_put_oi / max(total_call_oi, 1), 3)

            # OI walls: top 2 call strikes above ATM, top 2 put strikes below ATM
            call_walls = sorted(
                [{"strike": s, "oi": o} for s, o in call_oi_by_strike.items() if s >= atm],
                key=lambda x: x["oi"], reverse=True
            )[:2]
            put_walls = sorted(
                [{"strike": s, "oi": o} for s, o in put_oi_by_strike.items() if s <= atm],
                key=lambda x: x["oi"], reverse=True
            )[:2]

            max_pain_strike = min(max_pain_map, key=max_pain_map.get) if max_pain_map else atm

            # IV rank: approximate from VIX position (no historical VIX series available)
            iv_rank = min(100, max(0, int((india_vix - 10) / (30 - 10) * 100)))

            # PCR trend: compare with neutral 1.0
            pcr_trend = "rising" if pcr > 1.2 else ("falling" if pcr < 0.8 else "stable")

            return {
                "pcr":            pcr,
                "pcr_trend":      pcr_trend,
                "max_pain":       max_pain_strike,
                "india_vix":      india_vix,
                "iv_rank":        iv_rank,
                "call_oi_walls":  call_walls,
                "put_oi_walls":   put_walls,
                "total_call_oi":  total_call_oi,
                "total_put_oi":   total_put_oi,
            }

        except Exception as e:
            logger.warning(f"Option chain fetch failed ({e}), using defaults")
            # Graceful fallback so the engine still runs
            atm = round(nifty_price / 50) * 50
            return {
                "pcr":           1.0,
                "pcr_trend":     "stable",
                "max_pain":      atm,
                "india_vix":     india_vix,
                "iv_rank":       40,
                "call_oi_walls": [{"strike": atm + 100, "oi": 0},
                                  {"strike": atm + 200, "oi": 0}],
                "put_oi_walls":  [{"strike": atm - 100, "oi": 0},
                                  {"strike": atm - 200, "oi": 0}],
            }

    def _fetch_flow_data(self) -> Dict[str, float]:
        """
        FII/DII flow data. Fyers doesn't expose a direct FII/DII endpoint,
        so we return zero-defaults; the coordinator handles missing flow data
        gracefully (VESPER uses it but won't crash without it).

        If you have an NSE or third-party flow API, plug it in here.
        """
        return {
            "fii_cash_5day": 0.0,
            "dii_cash_5day": 0.0,
        }
