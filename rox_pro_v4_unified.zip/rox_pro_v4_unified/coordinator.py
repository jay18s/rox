"""
ROX Proven Edge Engine v4.0 Unified - Unified Coordinator
==========================================================
Merges v3.2 LeadCoordinator (8-agent swing engine) with
v4.0 F&O specialist agents (HERMES, THETA, DELTA).

Architecture
------------
LeadCoordinator  — orchestrates all 11 agents through the 11-tier pipeline,
                   generates DailyTradingPlans for swing trades.
FnoCoordinator   — lightweight wrapper that adds F&O portfolio management:
                   live Greeks monitoring (THETA), settlement compliance (DELTA),
                   and execution quality tracking (HERMES).
UnifiedCoordinator — top-level facade that composes both, offering a single
                     entry point for the full engine.
"""

from __future__ import annotations

import logging
import sys, os
import threading
from dataclasses import dataclass, field
from datetime import datetime, date
from typing import Dict, List, Optional, Any, Callable, Tuple
from enum import Enum

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import (
    TradeDirection, MarketRegime, ConvictionLevel, SystemConfig,
    DEFAULT_CONFIG, NIFTY_50_STOCKS, SECTOR_MAPPING, FnoRiskLimits,
    get_vix_regime,
)
from agents import (
    BaseAgent, AgentVerdict, AgentReport,
    OrionAgent, VesperAgent, KairoAgent,
    SentinelAgent, NexusAgent, PrudenceAgent, CatalystAgent, OptimusAgent,
    HermesAgent, ThetaAgent, DeltaAgent,
    Order, OrderStatus, OrderType, GreeksAlert, SettlementObligation,
)
from data.data_manager import DataManager, TradeRecord
from data.scorecard import AgentScorecard


# ---------------------------------------------------------------------------
# Shared data structures (carried over from v3.2 coordinator)
# ---------------------------------------------------------------------------

@dataclass
class ConsensusResult:
    direction: TradeDirection
    strength: str          # STRONG | MODERATE | WEAK | NO_CONSENSUS
    net_score: float
    weighted_votes: Dict[str, float]
    agreeing_agents: List[str]
    disagreeing_agents: List[str]
    contradictions: List[Dict]


@dataclass
class TradeSetup:
    stock: str
    direction: TradeDirection
    conviction: int
    conviction_level: ConvictionLevel
    entry_price: float
    entry_zone: Tuple[float, float]
    stop_loss: float
    target_1: float
    target_2: float
    risk_reward: float
    shares: int
    position_value: float
    position_percent: float
    risk_percent: float
    agent_votes: Dict[str, AgentVerdict]
    pattern_match: Dict
    historical_win_rate: float
    exit_strategy: str
    setup_time: datetime = field(default_factory=datetime.now)


@dataclass
class DailyTradingPlan:
    date: datetime
    market_regime: MarketRegime
    regime_confidence: float
    consensus: ConsensusResult
    top_setups: List[TradeSetup]
    portfolio_risk: Dict
    upcoming_events: List[Dict]
    action_items: List[str]
    agent_reports: Dict[str, AgentReport]
    # v4.0 additions
    portfolio_greeks: Dict = field(default_factory=dict)
    active_alerts: List[str] = field(default_factory=list)
    settlement_obligations: List[Dict] = field(default_factory=list)


# ---------------------------------------------------------------------------
# FnoCoordinator — manages HERMES, THETA, DELTA agents
# ---------------------------------------------------------------------------

class FnoCoordinator:
    """
    F&O Portfolio Coordinator (v4.0).

    Manages the three F&O specialist agents:
    - HERMES  : tracks order execution and slippage
    - THETA   : monitors portfolio Greeks and triggers hedging alerts
    - DELTA   : monitors physical settlement obligations and SEBI compliance
    """

    def __init__(self, config: SystemConfig):
        self.config  = config
        self.logger  = logging.getLogger("FnoCoordinator")
        self._lock   = threading.Lock()

        # Instrument + MWPL manager (lazy init to avoid startup errors)
        self._instrument_manager = None
        self._mwpl_monitor       = None

        # Initialise specialist agents
        self.hermes = HermesAgent()
        self.hermes.register_callback(self._on_order_update)

        self.theta  = ThetaAgent(config.fno_limits)
        self.theta.register_callback(self._on_greeks_alert)

        self.delta  = DeltaAgent(auto_exit_enabled=True)
        self.delta.register_callback(self._on_settlement_alert)

        self._active_alerts: List[str] = []

    # ------------------------------------------------------------------
    # Lazy property: instrument manager
    # ------------------------------------------------------------------
    @property
    def instrument_manager(self):
        if self._instrument_manager is None:
            try:
                from infrastructure.fno_instrument_manager import get_instrument_manager
                self._instrument_manager = get_instrument_manager()
                self.delta.instrument_manager = self._instrument_manager
            except Exception as e:
                self.logger.warning(f"FnoInstrumentManager unavailable: {e}")
        return self._instrument_manager

    @property
    def mwpl_monitor(self):
        if self._mwpl_monitor is None:
            try:
                from infrastructure.mwpl_monitor import get_mwpl_monitor
                self._mwpl_monitor = get_mwpl_monitor()
                self._mwpl_monitor.register_callback(self._on_mwpl_alert)
                self._mwpl_monitor.start_monitoring()
            except Exception as e:
                self.logger.warning(f"MWPLMonitor unavailable: {e}")
        return self._mwpl_monitor

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def get_portfolio_greeks(self) -> Dict:
        pg = self.theta.get_portfolio_greeks()
        return {
            "delta": round(pg.delta, 4),
            "gamma": round(pg.gamma, 6),
            "theta": round(pg.theta, 2),
            "vega":  round(pg.vega, 2),
            "num_positions": pg.num_positions,
        }

    def get_settlement_obligations(self) -> List[Dict]:
        return [
            {
                "symbol":           o.symbol,
                "obligation_type":  o.obligation_type,
                "days_to_expiry":   o.days_to_expiry,
                "obligation_value": o.obligation_value,
                "requires_action":  o.requires_action,
            }
            for o in self.delta.get_settlement_obligations()
            if o.requires_action
        ]

    def get_active_alerts(self) -> List[str]:
        with self._lock:
            return list(self._active_alerts)

    def place_order(
        self,
        symbol: str,
        transaction_type: str,
        quantity: int,
        order_type: OrderType = OrderType.MARKET,
        price: float = 0.0,
        strategy_id: Optional[str] = None,
    ) -> Order:
        return self.hermes.place_order(
            symbol=symbol,
            transaction_type=transaction_type,
            quantity=quantity,
            order_type=order_type,
            price=price,
            strategy_id=strategy_id,
        )

    def get_execution_report(self) -> Dict:
        return self.hermes.generate_execution_report()

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------
    def _on_order_update(self, order: Order):
        self.logger.info(f"Order update: {order.order_id} → {order.status.value}")

    def _on_greeks_alert(self, alert: GreeksAlert):
        msg = f"[GREEKS] {alert.alert_type.value} | {alert.recommendation}"
        self.logger.warning(msg)
        with self._lock:
            self._active_alerts.append(msg)

    def _on_settlement_alert(self, obligation: SettlementObligation):
        msg = f"[SETTLEMENT] {obligation.symbol} | {obligation.obligation_type}"
        self.logger.warning(msg)
        with self._lock:
            self._active_alerts.append(msg)

    def _on_mwpl_alert(self, alert: Dict):
        msg = f"[MWPL] {alert.get('message', '')}"
        self.logger.warning(msg)
        with self._lock:
            self._active_alerts.append(msg)


# ---------------------------------------------------------------------------
# LeadCoordinator — full v3.2 swing engine (retained verbatim, now 11 agents)
# ---------------------------------------------------------------------------

class LeadCoordinator:
    """
    Lead Coordinator — Master Orchestrator (v3.2, extended to 11 agents).

    Coordinates all agents through the 11-tier processing pipeline to
    generate DailyTradingPlans with full reasoning transparency.
    """

    def __init__(self, config: SystemConfig = None, portfolio_value: float = 1_000_000):
        self.config           = config or DEFAULT_CONFIG
        self.portfolio_value  = portfolio_value
        self.logger           = logging.getLogger("LeadCoordinator")

        # Core 8 swing agents
        self.agents: Dict[str, BaseAgent] = {
            "ORION":    OrionAgent(),
            "VESPER":   VesperAgent(),
            "KAIRO":    KairoAgent(),
            "SENTINEL": SentinelAgent(),
            "NEXUS":    NexusAgent(),
            "PRUDENCE": PrudenceAgent(),
            "CATALYST": CatalystAgent(),
            "OPTIMUS":  OptimusAgent(),
        }
        for name, agent in self.agents.items():
            if name in self.config.agents:
                agent.current_weight = self.config.agents[name].current_weight

        self.current_regime     = MarketRegime.CONSOLIDATION
        self.regime_confidence  = 50.0
        self.market_data: Dict  = {}
        self.agent_reports: Dict[str, AgentReport] = {}

        self.data_manager = DataManager()
        self.scorecard    = AgentScorecard(self.data_manager)
        try:
            from data.pattern_database import PatternDatabase
            self.pattern_db = PatternDatabase(self.data_manager)
        except Exception:
            self.pattern_db = None

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------
    def generate_trading_plan(
        self,
        market_data: Dict[str, Any],
        portfolio_status: Optional[Dict] = None,
        watchlist: Optional[List[str]] = None,
    ) -> DailyTradingPlan:
        self.market_data     = market_data
        watchlist            = watchlist or NIFTY_50_STOCKS[:20]
        portfolio_status     = portfolio_status or self._default_portfolio()

        self._tier_0_validate_data(market_data)
        self.current_regime, self.regime_confidence = self._tier_11_detect_regime(market_data)
        self._tier_1_adjust_weights(self.current_regime)
        self._run_all_agents(market_data, self.current_regime)
        consensus = self._tier_2_calculate_consensus()

        setups = [
            s for s in (self._analyze_stock(stock, market_data, portfolio_status)
                        for stock in watchlist)
            if s
        ]
        top_setups = self._tier_5_rank_setups(setups)
        self._log_setups_to_history(top_setups)
        self._log_agent_verdicts_to_scorecard(consensus)
        self.data_manager.update_regime_history(self.current_regime.value)

        return DailyTradingPlan(
            date=datetime.now(),
            market_regime=self.current_regime,
            regime_confidence=self.regime_confidence,
            consensus=consensus,
            top_setups=top_setups,
            portfolio_risk=self._calculate_portfolio_risk(portfolio_status),
            upcoming_events=self._extract_upcoming_events(market_data),
            action_items=self._generate_action_items(top_setups, consensus),
            agent_reports=self.agent_reports,
        )

    # ------------------------------------------------------------------
    # Tier implementations  (identical to v3.2, kept complete)
    # ------------------------------------------------------------------
    def _log_setups_to_history(self, setups):
        today = datetime.now().date().isoformat()

        # Build a set of (date, stock, direction) already logged today so we
        # don't duplicate across the 60-second live-mode cycles.
        if not hasattr(self, "_logged_today"):
            self._logged_today: set = set()
            self._logged_date: str = today
        if self._logged_date != today:          # midnight rollover — reset
            self._logged_today = set()
            self._logged_date = today

        recommending_agents = ",".join(self.agent_reports.keys())
        for setup in setups:
            if setup.direction == TradeDirection.NEUTRAL:
                continue
            dedup_key = (today, setup.stock, setup.direction.value)
            if dedup_key in self._logged_today:
                continue                        # already logged this calendar day
            try:
                record = TradeRecord(
                    date_recommended=today, stock=setup.stock,
                    direction=setup.direction.value,
                    entry_price=round(setup.entry_price, 2),
                    stop_loss=round(setup.stop_loss, 2),
                    target_price=round(setup.target_1, 2),
                    risk_reward_ratio=round(setup.risk_reward, 2),
                    recommending_agents=recommending_agents,
                    regime_at_entry=self.current_regime.value,
                    conviction_confidence=setup.conviction,
                )
                self.data_manager.log_trade(record)
                self.data_manager.save_pattern({
                    "stock": setup.stock, "direction": setup.direction.value,
                    "regime": self.current_regime.value, "conviction": setup.conviction,
                    "entry_price": setup.entry_price, "stop_loss": setup.stop_loss,
                    "target": setup.target_1, "risk_reward": setup.risk_reward,
                    "setup_type": f"{setup.direction.value}_swing",
                })
                self._logged_today.add(dedup_key)
            except Exception as e:
                self.logger.error(f"[HISTORY] Failed to log {setup.stock}: {e}")

    def _log_agent_verdicts_to_scorecard(self, consensus):
        regime = self.current_regime.value
        for agent_name, report in self.agent_reports.items():
            try:
                self.scorecard.record_prediction(
                    agent_name=agent_name,
                    prediction=report.verdict.direction.value,
                    conviction=report.verdict.conviction,
                    regime=regime,
                )
            except Exception:
                pass

    def _tier_0_validate_data(self, data):
        required = ["price_data","flow_data","sentiment_data",
                    "derivatives_data","fundamental_data","event_data"]
        missing = [k for k in required if not data.get(k)]
        return {"missing": missing, "status": "green" if len(missing) <= 2 else "yellow"}

    def _tier_11_detect_regime(self, data) -> Tuple[MarketRegime, float]:
        score = 0; fired = 0
        nifty = data.get("nifty_price", 0); dma200 = data.get("nifty_200dma", 0)
        if dma200 > 0:
            gap = (nifty - dma200) / dma200
            if gap > 0.05: score += 1; fired += 1
            elif gap > 0:  score += 0.5
            elif gap < -0.05: score -= 1; fired += 1
            else: score -= 0.5
        ps = data.get("price_structure", "neutral")
        if ps == "higher_highs": score += 1; fired += 1
        elif ps == "lower_lows": score -= 1; fired += 1
        adx = data.get("adx", 20); adx_strong = adx > 25
        fii = data.get("flow_data", {}).get("fii_cash_5day", 0)
        if fii > 3000: score += 1; fired += 1
        elif fii < -3000: score -= 1; fired += 1
        vix = data.get("india_vix", 15)
        if vix > 22: score -= 0.5
        elif vix < 13: score += 0.5; fired += 1

        if score >= 2:   regime = MarketRegime.BULL
        elif score >= 1: regime = MarketRegime.MILD_BULL
        elif score <= -2: regime = MarketRegime.BEAR
        elif score <= -1: regime = MarketRegime.MILD_BEAR
        else:            regime = MarketRegime.CONSOLIDATION

        abs_s = abs(score); base = 50 + abs_s * 10
        if abs_s >= 2 and adx_strong and fired >= 3:
            conf = min(90, base + fired * 3)
        elif abs_s >= 2:
            conf = min(75, base + fired * 2)
        elif abs_s >= 1:
            conf = min(65, base + fired * 2)
        else:
            conf = min(55, base)
        return regime, round(conf, 1)

    def _tier_1_adjust_weights(self, regime):
        adjustments = {
            MarketRegime.BULL:  {"ORION":0.03,"VESPER":0.02,"KAIRO":-0.03,"PRUDENCE":-0.02},
            MarketRegime.BEAR:  {"ORION":-0.03,"VESPER":0.02,"KAIRO":0.03,"SENTINEL":0.02,"NEXUS":0.01,"PRUDENCE":0.02},
            MarketRegime.CONSOLIDATION: {"VESPER":-0.02,"SENTINEL":0.03,"NEXUS":0.02,"CATALYST":0.01},
        }
        adj = adjustments.get(regime, {})
        for name, agent in self.agents.items():
            delta = adj.get(name, 0)
            agent.current_weight = max(0.05, min(0.30,
                self.config.agents[name].baseline_weight + delta))
        total = sum(a.current_weight for a in self.agents.values())
        for a in self.agents.values():
            a.current_weight /= total

    def _run_all_agents(self, data, regime):
        self.agent_reports = {}
        mapping = {
            "ORION":    self._prepare_orion_data(data),
            "VESPER":   self._prepare_vesper_data(data),
            "KAIRO":    self._prepare_kairo_data(data),
            "SENTINEL": self._prepare_sentinel_data(data),
            "NEXUS":    self._prepare_nexus_data(data),
            "PRUDENCE": self._prepare_prudence_data(data),
            "CATALYST": self._prepare_catalyst_data(data),
            "OPTIMUS":  self._prepare_optimus_data(data),
        }
        for name, agent in self.agents.items():
            try:
                self.agent_reports[name] = agent.analyze(mapping.get(name, {}), regime)
            except Exception as e:
                self.agent_reports[name] = AgentReport(
                    agent_name=name,
                    verdict=AgentVerdict(direction=TradeDirection.NEUTRAL, conviction=0,
                                        weight=agent.current_weight, reason=str(e)))

    def _tier_2_calculate_consensus(self) -> ConsensusResult:
        weighted_votes: Dict[str, float] = {}
        long_v, short_v = [], []
        for name, report in self.agent_reports.items():
            v = report.verdict
            weighted_votes[name] = v.weighted_vote
            if v.direction == TradeDirection.LONG: long_v.append(name)
            elif v.direction == TradeDirection.SHORT: short_v.append(name)
        net = sum(weighted_votes.values())
        if net > 0.25:
            direction = TradeDirection.LONG
            strength = "STRONG" if net > 0.4 else "MODERATE"
        elif net < -0.25:
            direction = TradeDirection.SHORT
            strength = "STRONG" if net < -0.4 else "MODERATE"
        else:
            direction = TradeDirection.NEUTRAL; strength = "NO_CONSENSUS"
        contradictions = []
        if long_v and short_v:
            contradictions.append({"type":"direction",
                                   "agents":{"long":long_v,"short":short_v},
                                   "resolution":f"Weighted vote favors {direction.value}"})
        return ConsensusResult(
            direction=direction, strength=strength, net_score=net,
            weighted_votes=weighted_votes,
            agreeing_agents=long_v if direction==TradeDirection.LONG else short_v,
            disagreeing_agents=short_v if direction==TradeDirection.LONG else long_v,
            contradictions=contradictions,
        )

    def _analyze_stock(self, stock, market_data, portfolio_status):
        stock_data = self._get_stock_data(stock, market_data)
        if not stock_data: return None
        orion_report = self.agents["ORION"].analyze(stock_data, self.current_regime)
        if orion_report.verdict.conviction < 50: return None
        entry_setup = orion_report.raw_data.get("entry_setup", {})
        if entry_setup.get("direction") == TradeDirection.NEUTRAL:
            vdir = orion_report.verdict.direction
            if vdir == TradeDirection.NEUTRAL: return None
            pd_ = stock_data.get("price_data", {}); ind = stock_data.get("indicators", {})
            sp = pd_.get("close", 0); atr = ind.get("atr", sp*0.02)
            sma20 = ind.get("sma20",0); sma50 = ind.get("sma50",0)
            sma200 = ind.get("sma200",0); rsi = ind.get("rsi",50)
            if sp <= 0: return None
            entry_setup = dict(entry_setup); entry_setup["direction"] = vdir
            min_rr = self.config.risk_limits.min_risk_reward_ratio
            if vdir == TradeDirection.LONG:
                stop = sma20*0.995 if sma20>0 and (sp-sma20)/sp<0.04 else sp-atr*1.5
                risk = sp - stop
                structural = [x for x in [sma50,sma200,round(sp*1.05/50)*50] if x>sp]
                t1 = min(structural) if structural else sp+atr*max(min_rr+0.5,2.0)
                t2 = min([c for c in structural if c>t1], default=t1*1.03)
                if risk>0 and (t1-sp)/risk<min_rr: return None
                entry_setup.update({"entry_zone":(sp*0.999,sp*1.003),
                                    "stop_loss":round(stop,2),
                                    "target_1":round(t1,2),"target_2":round(t2,2),
                                    "risk_reward":round((t1-sp)/risk,2) if risk>0 else 0})
            else:
                stop = sma20*1.005 if sma20>0 and (sma20-sp)/sp<0.04 else sp+atr*1.5
                risk = stop - sp
                structural = [x for x in [sma50,sma200,round(sp*0.95/50)*50] if x<sp]
                t1 = max(structural) if structural else sp-atr*max(min_rr+0.5,2.0)
                t2 = max([c for c in structural if c<t1], default=t1*0.97)
                if risk>0 and (sp-t1)/risk<min_rr: return None
                entry_setup.update({"entry_zone":(sp*0.997,sp*1.001),
                                    "stop_loss":round(stop,2),
                                    "target_1":round(t1,2),"target_2":round(t2,2),
                                    "risk_reward":round((sp-t1)/risk,2) if risk>0 else 0})

        sp2 = stock_data.get("price_data",{}).get("close",0)
        fund = stock_data.get("fundamentals",
               market_data.get("fundamental_data",{}).get(stock,{}))
        nexus_report = self.agents["NEXUS"].analyze(
            {**stock_data,"stock":stock,"nifty_pe":market_data.get("nifty_pe",22.5),
             "gsec_yield":market_data.get("gsec_yield",7.0),"fundamentals":fund},
            self.current_regime)
        has_fund = bool(fund)
        pru_report = self.agents["PRUDENCE"].analyze({
            "portfolio":portfolio_status,
            "trade_request":{"entry_price":entry_setup.get("entry_zone",(0,0))[0],
                             "stop_loss":entry_setup.get("stop_loss",0)},
            "stock":stock,"sector":self._get_stock_sector(stock),
            "conviction_level":self._get_conviction_level(
                orion_report.verdict.conviction).value,
        }, self.current_regime)
        if pru_report.analysis_details.get("verdict_type") == "VETO": return None

        stock_rpts = [orion_report, nexus_report, pru_report] if has_fund \
                     else [orion_report, pru_report]
        stock_conv = self._calculate_conviction(*stock_rpts)
        panel = [self.agent_reports.get(n) for n in
                 ["VESPER","KAIRO","SENTINEL","CATALYST","OPTIMUS"] if self.agent_reports.get(n)]
        if panel:
            panel_conv = self._calculate_conviction(*panel)
            conviction = int(stock_conv*0.70 + panel_conv*0.30)
        else:
            conviction = stock_conv
        if conviction < 55: return None

        sizing = pru_report.analysis_details.get("sizing", {})
        return TradeSetup(
            stock=stock,
            direction=entry_setup.get("direction", TradeDirection.NEUTRAL),
            conviction=conviction,
            conviction_level=self._get_conviction_level(conviction),
            entry_price=entry_setup.get("entry_zone",(0,0))[0],
            entry_zone=entry_setup.get("entry_zone",(0,0)),
            stop_loss=entry_setup.get("stop_loss",0),
            target_1=entry_setup.get("target_1",0),
            target_2=entry_setup.get("target_2",0),
            risk_reward=entry_setup.get("risk_reward",0),
            shares=sizing.get("shares",0),
            position_value=sizing.get("position_value",0),
            position_percent=sizing.get("position_percent",0),
            risk_percent=sizing.get("risk_percent",0),
            agent_votes={"ORION":orion_report.verdict,"NEXUS":nexus_report.verdict,
                         "PRUDENCE":pru_report.verdict},
            pattern_match=self._lookup_pattern_win_rate(
                entry_setup.get("direction",TradeDirection.NEUTRAL),
                entry_setup.get("setup_type","swing")),
            historical_win_rate=self._lookup_pattern_win_rate(
                entry_setup.get("direction",TradeDirection.NEUTRAL),
                entry_setup.get("setup_type","swing")).get("win_rate",50),
            exit_strategy=self._generate_exit_strategy(entry_setup),
        )

    def _tier_5_rank_setups(self, setups):
        if not setups: return []
        min_rr = self.config.risk_limits.min_risk_reward_ratio
        qualified = [s for s in setups if s.risk_reward >= min_rr] or \
                    sorted(setups, key=lambda s: s.risk_reward, reverse=True)[:3]
        def score(s):
            return s.conviction*0.70 + min(s.risk_reward,3.0)/3.0*100*0.30
        return sorted(qualified, key=score, reverse=True)[:5]

    def _calculate_conviction(self, *reports) -> int:
        dw = ds = 0.0; nc = 0
        for r in reports:
            w = r.verdict.weight or 0.10; c = r.verdict.conviction; d = r.verdict.direction
            if d == TradeDirection.LONG:   ds += w*c;       dw += w
            elif d == TradeDirection.SHORT: ds += w*(100-c); dw += w
            else:
                if c >= 50: nc += 1
        if dw == 0: return 50
        raw = ds / dw
        penalty = min(8, nc*4) + min(8, sum(len(r.verdict.risks or []) for r in reports)*2)
        return max(0, min(100, int(raw - penalty)))

    def _get_conviction_level(self, conviction) -> ConvictionLevel:
        if conviction >= 85: return ConvictionLevel.VERY_HIGH
        elif conviction >= 75: return ConvictionLevel.HIGH
        elif conviction >= 65: return ConvictionLevel.MEDIUM
        elif conviction >= 50: return ConvictionLevel.LOW
        return ConvictionLevel.SKIP

    def _get_stock_sector(self, stock):
        for sector, stocks in SECTOR_MAPPING.items():
            if stock in stocks: return sector
        return "Others"

    def _lookup_pattern_win_rate(self, direction, setup_type):
        try:
            if self.pattern_db is None: return {"match":False,"win_rate":50,"total_trades":0}
            stats = self.pattern_db.calculate_historical_win_rate(
                setup_type=f"{direction.value if hasattr(direction,'value') else direction}_{setup_type}".lower(),
                regime=self.current_regime.value if self.current_regime else None)
            total = stats.get("total_trades",0)
            if total >= 15:
                return {"match":True,"win_rate":round(stats.get("win_rate",0.5)*100,1),
                        "total_trades":total,"avg_return":stats.get("avg_return",0)}
            return {"match":False,"win_rate":50,"total_trades":total}
        except Exception:
            return {"match":False,"win_rate":50,"total_trades":0}

    def _generate_exit_strategy(self, es):
        parts = []
        if es.get("target_1"): parts.append(f"Take partial profits at {es['target_1']}")
        if es.get("target_2"): parts.append(f"Trail stop to breakeven after T1, exit at {es['target_2']}")
        if es.get("stop_loss"): parts.append(f"Stop loss at {es['stop_loss']}")
        return " | ".join(parts) or "Set stop loss and target based on technical levels"

    def _get_stock_data(self, stock, market_data):
        pd_ = market_data.get("price_data",{}).get(stock,{})
        ind = market_data.get("indicators",{}).get(stock,{})
        fund = market_data.get("fundamental_data",{}).get(stock,{})
        close = pd_.get("close",0)
        if not close: return None
        sma20=ind.get("sma20",0); sma50=ind.get("sma50",0); sma200=ind.get("sma200",0)
        trend=ind.get("trend","SIDEWAYS"); rsi=ind.get("rsi",50)
        volume=pd_.get("volume",0); avg_vol=pd_.get("avg_volume",volume or 1)
        atr=pd_.get("atr",close*0.015); vol_ratio=volume/avg_vol if avg_vol>0 else 1.0
        def sig(b,r): return "bullish" if b else ("bearish" if r else "neutral")
        enriched_price = dict(pd_)
        if sma50:  enriched_price["ma_50"]  = sma50
        if sma200: enriched_price["ma_200"] = sma200
        ohlcv = market_data.get("ohlcv_history",{}).get(stock,[])
        if ohlcv:
            enriched_price["highs"]  = [c["high"]  for c in ohlcv]
            enriched_price["lows"]   = [c["low"]   for c in ohlcv]
            enriched_price["closes"] = [c["close"] for c in ohlcv]
        return {
            "stock":stock, "price_data":enriched_price,
            "indicators":{**ind,"vol_ratio":round(vol_ratio,2)},
            "fundamentals":fund,
            "weekly_trend":    sig(trend=="UPTREND",   trend=="DOWNTREND"),
            "daily_trend":     sig(close>sma50>0,       close<sma50>0),
            "four_hour_trend": sig(close>sma20>0,       close<sma20>0),
            "one_hour_trend":  sig(sma20>sma50>0,       sma20<sma50>0),
        }

    def _default_portfolio(self):
        return {"total_capital":self.portfolio_value,"deployed_capital":0,
                "cash":self.portfolio_value,"portfolio_heat":0,
                "current_drawdown":0,"open_positions":[],"sector_exposure":{}}

    def _calculate_portfolio_risk(self, portfolio):
        cap = max(1, portfolio.get("total_capital",1))
        return {"capital":portfolio.get("total_capital",0),
                "deployed_percent":portfolio.get("deployed_capital",0)/cap*100,
                "cash_percent":portfolio.get("cash",0)/cap*100,
                "portfolio_heat":portfolio.get("portfolio_heat",0)*100,
                "drawdown":portfolio.get("current_drawdown",0)*100}

    def _extract_upcoming_events(self, market_data):
        return [{"name":e.get("name",""),"date":str(e.get("date","")),"impact":e.get("impact","LOW")}
                for e in market_data.get("event_data",{}).get("events",[])[:5]]

    def _generate_action_items(self, setups, consensus):
        items = []
        if setups:
            items += [f"Review top setup: {setups[0].stock} ({setups[0].direction.value})",
                      f"Set alerts for {len(setups)} trade setups"]
        else:
            items.append("No high-conviction setups — wait for better opportunities")
        items += ["Verify all stop losses before market open",
                  "Check overnight news affecting positions"]
        return items

    # ------------------------------------------------------------------
    # Data preparation helpers (same as v3.2 coordinator)
    # ------------------------------------------------------------------
    def _prepare_orion_data(self, data):
        nifty=data.get("nifty_price",22500); dma200=data.get("nifty_200dma",22000)
        vix=data.get("india_vix",15.0); ps=data.get("price_structure","neutral")
        adx=data.get("adx",25)
        sma20=nifty*0.99; sma50=nifty*0.975; sma200=dma200
        trend="UPTREND" if nifty>sma50>sma200 else ("DOWNTREND" if nifty<sma50<sma200 else "SIDEWAYS")
        def sg(b,r): return "bullish" if b else ("bearish" if r else "neutral")
        atr=nifty*(vix/100)*(1/16)
        return {"stock":"NIFTY",
                "price_data":{"open":nifty*0.998,"high":nifty*1.005,"low":nifty*0.993,
                              "close":nifty,"volume":500000,"avg_volume":450000,
                              "atr":atr,"ma_50":sma50,"ma_200":sma200},
                "indicators":{"rsi":55 if trend=="UPTREND" else 45,"atr":atr,
                              "atr_percent":(atr/nifty)*100,"adx":adx,
                              "sma20":sma20,"sma50":sma50,"sma200":sma200,
                              "trend":trend,"volume_ratio":1.05,"above_200dma":nifty>sma200},
                "weekly_trend":sg(trend=="UPTREND",trend=="DOWNTREND"),
                "daily_trend":sg(nifty>sma50,nifty<sma50),
                "four_hour_trend":sg(nifty>sma20,nifty<sma20),
                "one_hour_trend":sg(ps=="higher_highs",ps=="lower_lows")}

    def _prepare_vesper_data(self, data):
        return {"flow_data":data.get("flow_data",{}),"sector_flows":data.get("sector_flows",[]),
                "bulk_deals":data.get("bulk_deals",[])}

    def _prepare_kairo_data(self, data):
        live=data.get("live_sentiment",{}); static=data.get("sentiment_data",{})
        mi=live.get("market_impact_assessment",{}); d=mi.get("direction","neutral")
        off={"positive":20,"negative":-20,"cautious":-10,"neutral":0}.get(d,0)
        geo=live.get("geopolitical",{}).get("overall_sentiment",None)
        stk=live.get("stock_news",{}).get("overall_sentiment",None)
        ns=int(50+(geo*50)+off) if geo is not None else static.get("news",35)
        gs=int(50+(geo*50)) if geo is not None else static.get("global",30)
        ss=int(50+(stk*50)) if stk is not None else static.get("social",25)
        return {"news_sentiment":max(0,min(100,ns)),"analyst_sentiment":static.get("analyst",45),
                "social_sentiment":max(0,min(100,ss)),"corporate_sentiment":static.get("corporate",20),
                "global_sentiment":max(0,min(100,gs)),"vix":data.get("india_vix",15),
                "pcr":data.get("derivatives_data",{}).get("pcr",1)}

    def _prepare_sentinel_data(self, data):
        d=data.get("derivatives_data",{})
        return {"pcr":d.get("pcr",1),"pcr_trend":d.get("pcr_trend","stable"),
                "max_pain":d.get("max_pain",0),"current_price":data.get("nifty_price",0),
                "india_vix":data.get("india_vix",15),"iv_rank":d.get("iv_rank",50),
                "call_oi_walls":d.get("call_oi_walls",[]),"put_oi_walls":d.get("put_oi_walls",[]),
                "oi_change":d.get("oi_change",0),"price_change":d.get("price_change",0)}

    def _prepare_nexus_data(self, data):
        return {"stock":"MARKET","fundamentals":{},
                "nifty_pe":data.get("nifty_pe",22.5),"gsec_yield":data.get("gsec_yield",7.0)}

    def _prepare_prudence_data(self, data):
        np_=data.get("nifty_price",22500); atr=np_*0.01
        return {"portfolio":self._default_portfolio(),
                "trade_request":{"entry_price":np_,"stop_loss":np_-atr*1.5},
                "conviction_level":"MEDIUM"}

    def _prepare_catalyst_data(self, data):
        return {"events":data.get("event_data",{}).get("events",[]),
                "current_date":datetime.now(),"expiry_week":data.get("expiry_week",False)}

    def _prepare_optimus_data(self, data):
        d=data.get("derivatives_data",{})
        return {"symbol":data.get("symbol","NIFTY"),"weekly_expiry":d.get("weekly_expiry",""),
                "current_price":data.get("nifty_price",d.get("current_price",0)),
                "price_change":d.get("price_change",0),"pcr":d.get("pcr",1.0),
                "pcr_trend":d.get("pcr_trend","stable"),"max_pain":d.get("max_pain",0),
                "call_oi_walls":d.get("call_oi_walls",[]),"put_oi_walls":d.get("put_oi_walls",[]),
                "ce_oi_change_pct":d.get("ce_oi_change_pct",0),"pe_oi_change_pct":d.get("pe_oi_change_pct",0),
                "oi_signal":d.get("oi_signal","NEUTRAL"),"india_vix":data.get("india_vix",15),
                "iv_rank":d.get("iv_rank",50),"iv_skew":d.get("iv_skew",0),
                "futures_premium":d.get("futures_premium",0)}


# ---------------------------------------------------------------------------
# UnifiedCoordinator — top-level facade
# ---------------------------------------------------------------------------

class UnifiedCoordinator:
    """
    Unified Coordinator — single entry point for the full 11-agent engine.

    Composes LeadCoordinator (swing engine) with FnoCoordinator (F&O specialists)
    to produce an enriched DailyTradingPlan that includes:
    - All v3.2 swing trade setups
    - Live portfolio Greeks status
    - Active F&O alerts (MWPL, settlement, Greeks limits)
    - Execution quality metrics
    """

    def __init__(self, config: Optional[SystemConfig] = None, portfolio_value: float = 1_000_000):
        self.config          = config or DEFAULT_CONFIG
        self.portfolio_value = portfolio_value
        self.logger          = logging.getLogger("UnifiedCoordinator")

        self.lead  = LeadCoordinator(self.config, portfolio_value)
        self.fno   = FnoCoordinator(self.config)

    # ------------------------------------------------------------------
    # Main API
    # ------------------------------------------------------------------
    def generate_trading_plan(
        self,
        market_data: Dict[str, Any],
        portfolio_status: Optional[Dict] = None,
        watchlist: Optional[List[str]] = None,
    ) -> DailyTradingPlan:
        """Generate complete daily trading plan from all 11 agents."""
        # Generate swing plan from v3.2 engine
        plan = self.lead.generate_trading_plan(market_data, portfolio_status, watchlist)

        # Enrich with v4.0 F&O data
        plan.portfolio_greeks        = self.fno.get_portfolio_greeks()
        plan.active_alerts           = self.fno.get_active_alerts()
        plan.settlement_obligations  = self.fno.get_settlement_obligations()

        return plan

    def place_order(self, symbol, transaction_type, quantity,
                    order_type=OrderType.MARKET, price=0.0, strategy_id=None):
        """Route order through HERMES execution agent."""
        return self.fno.place_order(symbol, transaction_type, quantity,
                                    order_type, price, strategy_id)

    def get_fno_status(self) -> Dict:
        """Get F&O portfolio status from all three specialist agents."""
        return {
            "portfolio_greeks":       self.fno.get_portfolio_greeks(),
            "active_alerts":          self.fno.get_active_alerts(),
            "settlement_obligations": self.fno.get_settlement_obligations(),
            "execution_report":       self.fno.get_execution_report(),
        }

    def format_report(self, plan: DailyTradingPlan) -> str:
        """Format the complete trading plan as a human-readable report."""
        lines = []
        lines.append("=" * 65)
        lines.append("ROX PROVEN EDGE ENGINE v4.0 UNIFIED — DAILY TRADING PLAN")
        lines.append(f"Date: {plan.date.strftime('%Y-%m-%d %H:%M')} | "
                     f"Regime: {plan.market_regime.value} | "
                     f"Confidence: {plan.regime_confidence:.1f}%")
        lines.append("=" * 65)

        lines.append("\n11-AGENT CONSENSUS PANEL")
        for name, report in plan.agent_reports.items():
            v = report.verdict
            lines.append(f"  {name:10s}: {v.direction.value:7s} "
                         f"| conviction={v.conviction:.0f}% "
                         f"| weight={v.weight:.2f}")

        lines.append(f"\nCONSENSUS: {plan.consensus.direction.value} "
                     f"({plan.consensus.strength}) | net_score={plan.consensus.net_score:.3f}")

        lines.append("\nTOP SWING SETUPS")
        for i, s in enumerate(plan.top_setups, 1):
            lines.append(f"  #{i} {s.stock:12s} {s.direction.value:5s} | "
                         f"conviction={s.conviction} | "
                         f"entry={s.entry_price:.2f} | "
                         f"SL={s.stop_loss:.2f} | "
                         f"T1={s.target_1:.2f} | R:R={s.risk_reward:.2f}")

        lines.append("\nF&O PORTFOLIO STATUS (v4.0)")
        pg = plan.portfolio_greeks
        lines.append(f"  Greeks: delta={pg.get('delta',0):.4f} | "
                     f"gamma={pg.get('gamma',0):.6f} | "
                     f"theta={pg.get('theta',0):.2f} | "
                     f"vega={pg.get('vega',0):.2f} | "
                     f"positions={pg.get('num_positions',0)}")

        if plan.active_alerts:
            lines.append("\nACTIVE ALERTS")
            for alert in plan.active_alerts[-5:]:
                lines.append(f"  ⚠  {alert}")

        if plan.settlement_obligations:
            lines.append("\nSETTLEMENT OBLIGATIONS")
            for ob in plan.settlement_obligations:
                lines.append(f"  {ob['symbol']} | {ob['obligation_type']} | "
                             f"DTE={ob['days_to_expiry']} | "
                             f"₹{ob['obligation_value']:,.0f}")

        lines.append("\nACTION ITEMS")
        for item in plan.action_items:
            lines.append(f"  [ ] {item}")

        lines.append("=" * 65)
        return "\n".join(lines)
