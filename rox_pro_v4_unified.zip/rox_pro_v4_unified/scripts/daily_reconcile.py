#!/usr/bin/env python3
"""
ROX Proven Edge Engine v3.1 - Daily Reconciliation Script
=========================================================
Run this EVERY EVENING after market close (3:30 PM IST+).

What it does:
  1. Reads all open trades from Recommendation_Accuracy_Log.csv
  2. Fetches current/closing price for each stock (Fyers → yfinance fallback)
  3. Calculates unrealized P&L % and updates the CSV
  4. Marks trades as CLOSED if they hit target or stop loss
  5. Resolves pending agent scorecard predictions with WIN/LOSS/NEUTRAL outcomes
  6. Prints a summary dashboard to console

Usage:
  python scripts/daily_reconcile.py                   # run with defaults
  python scripts/daily_reconcile.py --dry-run         # preview without writing
  python scripts/daily_reconcile.py --verbose         # detailed output
  python scripts/daily_reconcile.py --force-close ADANIENT  # manually close a stock

Schedule (Windows Task Scheduler / cron):
  - Run daily at 15:45 IST on trading days
"""

import os
import sys
import csv
import json
import argparse
import logging
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Tuple

# ── Path setup ──────────────────────────────────────────────────────────────
SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)
sys.path.insert(0, PROJECT_ROOT)

from data.data_manager import DataManager, TradeRecord
from data.scorecard import AgentScorecard

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("DailyReconcile")


# ═══════════════════════════════════════════════════════════════════════════
# Price Fetcher — Fyers → yfinance fallback
# ═══════════════════════════════════════════════════════════════════════════

def fetch_closing_prices(symbols: List[str]) -> Dict[str, float]:
    """
    Fetch latest closing prices for a list of NSE symbols.
    Returns { symbol: price }  (only symbols successfully fetched).

    Priority:
      1. Fyers API  (if FYERS_ACCESS_TOKEN env var is set)
      2. yfinance   (free, 15-min delayed)
      3. Empty dict (caller handles missing symbols)
    """
    prices = {}

    # ── Source 1: Fyers ────────────────────────────────────────────────────
    fyers_token = os.environ.get("FYERS_ACCESS_TOKEN", "")
    fyers_app   = os.environ.get("FYERS_APP_ID", "")

    if fyers_token and fyers_app:
        try:
            from fyers_apiv3 import fyersModel
            fyers_client = fyersModel.FyersModel(
                client_id=fyers_app,
                token=fyers_token,
                log_path="logs",
                is_async=False,
            )
            fyers_symbols = [f"NSE:{s}-EQ" for s in symbols]
            resp = fyers_client.quotes({"symbols": ",".join(fyers_symbols)})

            if resp.get("code") == 200:
                for item in resp.get("d", []):
                    sym_raw = item.get("n", "")            # e.g. "NSE:ADANIENT-EQ"
                    sym     = sym_raw.split(":")[1].replace("-EQ", "") if ":" in sym_raw else sym_raw
                    ltp     = item.get("v", {}).get("lp", 0)
                    if ltp > 0:
                        prices[sym] = float(ltp)

                logger.info(f"[Fyers] Fetched {len(prices)}/{len(symbols)} prices")
                return prices
        except Exception as e:
            logger.warning(f"[Fyers] Price fetch failed: {e} — falling back to yfinance")

    # ── Source 2: yfinance ─────────────────────────────────────────────────
    try:
        import yfinance as yf
        import warnings
        warnings.filterwarnings("ignore")

        tickers = [f"{s}.NS" for s in symbols]
        end   = datetime.now()
        start = end - timedelta(days=5)           # last 5 days catches weekends

        raw = yf.download(
            tickers,
            start=start,
            end=end,
            interval="1d",
            progress=False,
            auto_adjust=True,
            group_by="ticker",
        )

        for sym, ticker in zip(symbols, tickers):
            try:
                if len(tickers) > 1:
                    df = raw[ticker] if ticker in raw.columns.get_level_values(0) else None
                else:
                    df = raw

                if df is None or df.empty:
                    continue
                price = float(df["Close"].dropna().iloc[-1])
                if price > 0:
                    prices[sym] = price
            except Exception:
                pass

        logger.info(f"[yfinance] Fetched {len(prices)}/{len(symbols)} prices")
        return prices

    except ImportError:
        logger.error("[yfinance] Not installed. Run: pip install yfinance")
    except Exception as e:
        logger.error(f"[yfinance] Error: {e}")

    return prices


# ═══════════════════════════════════════════════════════════════════════════
# Trade Status Checker
# ═══════════════════════════════════════════════════════════════════════════

def evaluate_trade(
    trade: Dict,
    current_price: float,
) -> Tuple[str, float, float]:
    """
    Given a trade row and current price, determine its status.

    Returns:
        (status, pnl_pct, r_multiple)
        status: "OPEN" | "HIT_TARGET" | "HIT_STOP" | "EXPIRED"
        pnl_pct: unrealised or realised P&L as percentage
        r_multiple: R multiple achieved (positive = win, negative = loss)
    """
    entry  = float(trade.get("entry_price", 0))
    sl     = float(trade.get("stop_loss", 0))
    target = float(trade.get("target_price", 0))
    direction = trade.get("direction", "LONG").upper()
    date_rec  = trade.get("date_recommended", "")

    if entry <= 0:
        return "OPEN", 0.0, 0.0

    # Calculate raw P&L
    if direction == "LONG":
        pnl_pct   = (current_price - entry) / entry * 100
        risk_pts  = entry - sl if sl > 0 else entry * 0.02
        reward_pts = current_price - entry
    else:  # SHORT
        pnl_pct   = (entry - current_price) / entry * 100
        risk_pts  = sl - entry if sl > 0 else entry * 0.02
        reward_pts = entry - current_price

    r_multiple = reward_pts / risk_pts if risk_pts > 0 else 0.0

    # Check expiry: swing trades expire after 10 trading days (~14 calendar days)
    try:
        rec_date  = date.fromisoformat(date_rec)
        age_days  = (date.today() - rec_date).days
        if age_days > 14:
            return "EXPIRED", round(pnl_pct, 3), round(r_multiple, 3)
    except ValueError:
        pass

    # Check if target or stop hit
    if direction == "LONG":
        if target > 0 and current_price >= target:
            return "HIT_TARGET", round(pnl_pct, 3), round(r_multiple, 3)
        if sl > 0 and current_price <= sl:
            return "HIT_STOP", round(pnl_pct, 3), round(r_multiple, 3)
    else:
        if target > 0 and current_price <= target:
            return "HIT_TARGET", round(pnl_pct, 3), round(r_multiple, 3)
        if sl > 0 and current_price >= sl:
            return "HIT_STOP", round(pnl_pct, 3), round(r_multiple, 3)

    return "OPEN", round(pnl_pct, 3), round(r_multiple, 3)


# ═══════════════════════════════════════════════════════════════════════════
# Main Reconciliation Logic
# ═══════════════════════════════════════════════════════════════════════════

def run_reconciliation(dry_run: bool = False, verbose: bool = False, force_close: List[str] = None):
    """
    Main reconciliation function.
    """
    force_close = force_close or []
    dm        = DataManager()
    scorecard = AgentScorecard(dm)
    csv_path  = os.path.join(dm.data_dir, "Recommendation_Accuracy_Log.csv")

    if not os.path.exists(csv_path):
        logger.warning(f"No trade log found at {csv_path}")
        logger.info("Run 'python main_production.py plan' first to generate trade recommendations.")
        return

    # ── Read CSV ────────────────────────────────────────────────────────────
    with open(csv_path, "r") as f:
        reader = csv.DictReader(f)
        all_trades = list(reader)

    open_trades  = [t for t in all_trades if not t.get("date_closed")]
    closed_count = len(all_trades) - len(open_trades)

    logger.info(f"Trade log: {len(all_trades)} total | {len(open_trades)} open | {closed_count} closed")

    if not open_trades:
        logger.info("No open trades to reconcile.")
        _print_summary(dm, scorecard)
        return

    # ── Fetch prices ────────────────────────────────────────────────────────
    symbols = list({t["stock"] for t in open_trades})
    logger.info(f"Fetching prices for: {', '.join(symbols)}")
    prices = fetch_closing_prices(symbols)

    missing = [s for s in symbols if s not in prices]
    if missing:
        logger.warning(f"Could not fetch prices for: {', '.join(missing)}")

    # ── Process each open trade ─────────────────────────────────────────────
    updates    = []   # (index_in_all_trades, updated_row)
    results    = []   # for summary

    for trade in open_trades:
        stock         = trade["stock"]
        current_price = prices.get(stock)

        # Manual force-close
        if stock in force_close and current_price:
            status = "FORCE_CLOSED"
            pnl_pct   = (current_price - float(trade["entry_price"])) / float(trade["entry_price"]) * 100
            r_multiple = 0.0
        elif current_price is None:
            logger.warning(f"  {stock}: no price available — skipping")
            continue
        else:
            status, pnl_pct, r_multiple = evaluate_trade(trade, current_price)

        should_close = status in ("HIT_TARGET", "HIT_STOP", "EXPIRED", "FORCE_CLOSED")

        if verbose or should_close:
            emoji = "✅" if pnl_pct > 0 else "🔴"
            logger.info(
                f"  {stock:15s} | {trade['direction']:5s} | Entry:{float(trade['entry_price']):>8.2f} "
                f"| Now:{current_price:>8.2f} | P&L:{pnl_pct:>+7.2f}% | R:{r_multiple:>+5.2f} "
                f"| {status} {emoji}"
            )
        else:
            logger.info(
                f"  {stock:15s} | {trade['direction']:5s} | P&L:{pnl_pct:>+7.2f}% | {status}"
            )

        # Prepare update row
        updated_trade = dict(trade)
        updated_trade["pnl_pct"] = round(pnl_pct, 3)

        if should_close and not dry_run:
            updated_trade["date_closed"] = date.today().isoformat()
            updated_trade["exit_price"]  = round(current_price, 2)

            # Resolve agent scorecard for this date
            outcome = "WIN" if pnl_pct > 0 else ("LOSS" if pnl_pct < 0 else "NEUTRAL")
            prediction_date = trade.get("date_recommended", "")
            agents_str      = trade.get("recommending_agents", "")
            agents          = [a.strip() for a in agents_str.split(",") if a.strip()]

            for agent_name in agents:
                try:
                    scorecard.resolve_prediction(
                        agent_name=agent_name,
                        prediction_date=prediction_date,
                        outcome=outcome,
                        r_multiple=r_multiple,
                    )
                except Exception as e:
                    logger.warning(f"  Scorecard resolve error ({agent_name}): {e}")

        results.append({
            "stock":      stock,
            "direction":  trade["direction"],
            "status":     status,
            "pnl_pct":    pnl_pct,
            "r_multiple": r_multiple,
            "closed":     should_close,
        })

        # Find position in all_trades and queue update
        for i, t in enumerate(all_trades):
            if (t["stock"] == stock and
                    t["date_recommended"] == trade["date_recommended"] and
                    not t.get("date_closed")):
                updates.append((i, updated_trade))
                break

    # ── Write updated CSV ────────────────────────────────────────────────────
    if updates and not dry_run:
        for idx, updated_row in updates:
            all_trades[idx] = updated_row

        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=DataManager.CSV_HEADERS)
            writer.writeheader()
            writer.writerows(all_trades)
        logger.info(f"Updated {len(updates)} trade row(s) in CSV")
    elif dry_run:
        logger.info(f"[DRY RUN] Would update {len(updates)} row(s) — no files written")

    # ── Save daily reconciliation report ────────────────────────────────────
    report = _build_report(results, prices)
    if not dry_run:
        week_num = date.today().isocalendar()[1]
        dm.save_weekly_reconciliation(week_num, report)

    # ── Print summary ────────────────────────────────────────────────────────
    _print_summary(dm, scorecard)
    print("\n" + report)


def _build_report(results: List[Dict], prices: Dict[str, float]) -> str:
    """Build a markdown reconciliation report."""
    today   = date.today().isoformat()
    lines   = []

    lines.append(f"# Daily Reconciliation — {today}\n")
    lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")

    lines.append("## Trade Status\n")
    lines.append("| Stock | Direction | Status | P&L% | R Multiple |")
    lines.append("|-------|-----------|--------|------|------------|")

    for r in results:
        pnl_str = f"{r['pnl_pct']:+.2f}%"
        r_str   = f"{r['r_multiple']:+.2f}"
        lines.append(f"| {r['stock']} | {r['direction']} | {r['status']} | {pnl_str} | {r_str} |")

    # Summary stats
    closed_results = [r for r in results if r["closed"]]
    wins   = [r for r in closed_results if r["pnl_pct"] > 0]
    losses = [r for r in closed_results if r["pnl_pct"] < 0]

    lines.append("\n## Session Summary\n")
    lines.append(f"- Trades reconciled: {len(results)}")
    lines.append(f"- Closed today: {len(closed_results)}")
    if closed_results:
        lines.append(f"- Wins: {len(wins)} | Losses: {len(losses)}")
        avg_pnl = sum(r["pnl_pct"] for r in closed_results) / len(closed_results)
        lines.append(f"- Average P&L on closed: {avg_pnl:+.2f}%")

    open_results = [r for r in results if not r["closed"]]
    if open_results:
        unrealised = sum(r["pnl_pct"] for r in open_results) / len(open_results)
        lines.append(f"\n- Open positions: {len(open_results)}")
        lines.append(f"- Average unrealised P&L: {unrealised:+.2f}%")

    return "\n".join(lines)


def _print_summary(dm: DataManager, scorecard: AgentScorecard):
    """Print overall portfolio stats and scorecard."""
    print("\n" + "=" * 65)
    print("PORTFOLIO PERFORMANCE SUMMARY (Last 30 days)")
    print("=" * 65)

    stats = dm.get_trading_statistics(days=30)
    print(f"Total recommendations : {stats.get('total', 0)}")
    print(f"Closed trades         : {stats.get('closed', 0)}")
    if stats.get("closed", 0) > 0:
        print(f"Win rate              : {stats.get('win_rate', 0)*100:.1f}%")
        print(f"Average return        : {stats.get('avg_return', 0):+.2f}%")
        print(f"Total return          : {stats.get('total_return', 0):+.2f}%")

    print()
    print(scorecard.get_summary_table())

    # Show weight recommendations if enough data
    weight_recs = scorecard.get_weights_recommendation()
    meaningful  = {k: v for k, v in weight_recs.items() if v is not None}
    if meaningful:
        print("\nSUGGESTED AGENT WEIGHT ADJUSTMENTS (based on live performance):")
        for agent, weight in meaningful.items():
            print(f"  {agent:<12} → {weight:.2%}")
    else:
        print("\nNote: Weight recommendations unlock after 10 resolved predictions per agent.")
    print("=" * 65)


# ═══════════════════════════════════════════════════════════════════════════
# CLI Entry Point
# ═══════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="ROX Daily Reconciliation — run every evening after 3:30 PM IST",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python scripts/daily_reconcile.py                       # standard nightly run
  python scripts/daily_reconcile.py --dry-run             # preview changes, write nothing
  python scripts/daily_reconcile.py --verbose             # print every open trade
  python scripts/daily_reconcile.py --force-close AXISBANK ADANIENT  # manually close positions
        """
    )
    parser.add_argument("--dry-run",    action="store_true", help="Preview without writing any files")
    parser.add_argument("--verbose",    action="store_true", help="Print details for all open trades")
    parser.add_argument("--force-close", nargs="+", default=[], metavar="SYMBOL",
                        help="Force-close specific stocks at current market price")

    args = parser.parse_args()

    print("=" * 65)
    print("ROX PROVEN EDGE ENGINE — DAILY RECONCILIATION")
    print(f"Run date : {date.today().isoformat()}")
    print(f"Run time : {datetime.now().strftime('%H:%M:%S')}")
    if args.dry_run:
        print("MODE     : DRY RUN (no files will be changed)")
    print("=" * 65 + "\n")

    run_reconciliation(
        dry_run=args.dry_run,
        verbose=args.verbose,
        force_close=args.force_close,
    )


if __name__ == "__main__":
    main()
