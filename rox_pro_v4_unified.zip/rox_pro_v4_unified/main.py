#!/usr/bin/env python3
"""
ROX Proven Edge Engine v4.0 Unified — Main Entry Point
=======================================================
Combines the v3.2 multi-agent swing engine with the v4.0 F&O specialist
agents (HERMES, THETA, DELTA) into a single production-ready system.

Modes
-----
  paper     — live market data, simulated orders  (default)
  live      — live market data, real order routing via broker API
  backtest  — historical simulation (start/end date required)
  demo      — quick sanity-check run with synthetic data, no data feeds needed

Usage
-----
  python main.py                          # paper mode
  python main.py --mode demo              # demo with synthetic data
  python main.py --mode live              # live trading
  python main.py --mode backtest --start-date 2024-01-01 --end-date 2024-12-31
"""

import argparse
import logging
import signal
import sys
import threading
import time
from datetime import datetime, date
from pathlib import Path
from typing import Optional, Dict, Any

# ── path setup ──────────────────────────────────────────────────────────────
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

# ── logging ─────────────────────────────────────────────────────────────────
try:
    from core import init_logging, get_logger
    init_logging()
    logger = get_logger("Main")
except Exception:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(PROJECT_ROOT / "logs" / "rox_unified.log",
                                encoding="utf-8"),
        ],
    )
    logger = logging.getLogger("Main")

# ── core imports ─────────────────────────────────────────────────────────────
from config import (
    SystemConfig, DEFAULT_CONFIG, TradeDirection, MarketRegime,
    ConvictionLevel, get_vix_regime, NIFTY_50_STOCKS, get_system_config,
)
from coordinator import UnifiedCoordinator, DailyTradingPlan
from agents import (
    HermesAgent, ThetaAgent, DeltaAgent,
    Order, OrderStatus, OrderType,
)


# ===========================================================================
# ROX Unified Engine
# ===========================================================================

class ROXUnifiedEngine:
    """
    ROX Proven Edge Engine v4.0 Unified.

    Single facade over UnifiedCoordinator + broker integration hooks.
    Supports paper, live, backtest, and demo modes.
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        mode: str = "paper",
        portfolio_value: float = 1_000_000,
    ):
        self.config = config or get_system_config()
        self.mode = mode
        self.config.portfolio_value = portfolio_value
        self.running = False
        self._shutdown_event = threading.Event()

        logger.info(
            f"Initialising ROX Unified Engine v4.0 | mode={mode.upper()} | "
            f"portfolio=₹{portfolio_value:,.0f}"
        )

        # Central coordinator (swing + F&O specialists)
        self.coordinator = UnifiedCoordinator(self.config, portfolio_value)

        # Infrastructure components (lazy — init only if needed)
        self._strategy_factory = None

        logger.info("Engine ready — 11 agents loaded")

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self):
        """Start the engine's background monitoring loop."""
        logger.info("Starting engine...")
        self.running = True
        self.coordinator.fno.mwpl_monitor          # trigger lazy MWPL init

        self._loop_thread = threading.Thread(
            target=self._main_loop, daemon=True, name="ROX-MainLoop"
        )
        self._loop_thread.start()
        logger.info("Engine started")

    def stop(self):
        """Graceful shutdown."""
        logger.info("Stopping engine...")
        self.running = False
        self._shutdown_event.set()
        if hasattr(self, "_loop_thread"):
            self._loop_thread.join(timeout=5)
        logger.info("Engine stopped")

    # ------------------------------------------------------------------
    # Main loop (paper / live modes)
    # ------------------------------------------------------------------

    def _main_loop(self):
        """60-second trading cycle loop."""
        logger.info("Main loop started")
        while self.running and not self._shutdown_event.is_set():
            try:
                self._trading_cycle()
            except Exception as exc:
                logger.error(f"Trading cycle error: {exc}", exc_info=True)
            self._shutdown_event.wait(60)
        logger.info("Main loop ended")

    def _trading_cycle(self):
        """One complete trading cycle."""
        # Attempt live data; track whether we fell back to synthetic
        using_synthetic = False
        try:
            market_data = self._fetch_live_data()
        except Exception as exc:
            logger.debug(f"Live data unavailable ({exc}), using synthetic fallback")
            market_data = self._build_demo_data()
            using_synthetic = True

        plan = self.coordinator.generate_trading_plan(market_data)

        # Print the full formatted report to stdout each cycle
        report = self.coordinator.format_report(plan)
        if using_synthetic:
            report = report.replace(
                "ROX PROVEN EDGE ENGINE",
                "ROX PROVEN EDGE ENGINE [⚠ SYNTHETIC DATA — no broker connected]",
            )
        print("\n" + report)

        # Structured log lines for monitoring / log aggregators
        for s in plan.top_setups[:3]:
            logger.info(
                f"  Setup: {s.stock} {s.direction.value} | "
                f"conviction={s.conviction} | R:R={s.risk_reward:.2f}"
            )
        for alert in plan.active_alerts[-3:]:
            logger.warning(f"  ALERT: {alert}")

    # ------------------------------------------------------------------
    # Demo / backtest run
    # ------------------------------------------------------------------

    def run_demo(self) -> DailyTradingPlan:
        """
        Run a single cycle with synthetic data and print full report.
        Useful for integration testing without live data feeds.
        """
        logger.info("Running demo cycle with synthetic data...")
        market_data = self._build_demo_data()
        plan = self.coordinator.generate_trading_plan(
            market_data,
            watchlist=NIFTY_50_STOCKS[:10],
        )
        print("\n" + self.coordinator.format_report(plan))
        return plan

    def run_backtest(
        self,
        start_date: str,
        end_date: str,
        watchlist: Optional[list] = None,
    ) -> Dict:
        """Run simplified backtest over date range (uses synthetic data per day)."""
        from datetime import date as dt_date, timedelta
        start = dt_date.fromisoformat(start_date)
        end   = dt_date.fromisoformat(end_date)
        watchlist = watchlist or NIFTY_50_STOCKS[:20]
        plans = []
        d = start
        while d <= end:
            if d.weekday() < 5:   # skip weekends
                data = self._build_demo_data(seed=d.toordinal())
                plan = self.coordinator.generate_trading_plan(data, watchlist=watchlist)
                plans.append(plan)
                logger.info(f"Backtest {d}: {len(plan.top_setups)} setups | "
                            f"regime={plan.market_regime.value}")
            d += timedelta(days=1)
        logger.info(f"Backtest complete: {len(plans)} trading days processed")
        return {"days": len(plans), "plans": plans}

    # ------------------------------------------------------------------
    # Strategy builder passthrough
    # ------------------------------------------------------------------

    @property
    def strategy_factory(self):
        if self._strategy_factory is None:
            from infrastructure.fno_strategy_builders import StrategyFactory
            from infrastructure.fno_instrument_manager import get_instrument_manager
            from infrastructure.greeks_calculator import GreeksCalculator
            self._strategy_factory = StrategyFactory(
                get_instrument_manager(), GreeksCalculator()
            )
        return self._strategy_factory

    def build_strategy(self, strategy_type, underlying, spot_price, vix, **kwargs):
        """Build an options strategy via HERMES/THETA infrastructure."""
        from infrastructure.fno_strategy_builders import StrategyType
        builder = self.strategy_factory.get_builder(strategy_type)
        if not builder:
            return {"error": f"Unknown strategy: {strategy_type}"}
        result = builder.build(underlying, spot_price, vix, **kwargs)
        return {
            "strategy":       result.strategy_type.value,
            "underlying":     result.underlying,
            "spot":           result.spot_price,
            "legs":           [{"type":l.option_type,"strike":l.strike,
                                "expiry":l.expiry.isoformat(),"position":l.position,
                                "quantity":l.quantity} for l in result.legs],
            "greeks":         {"delta":result.delta,"gamma":result.gamma,
                               "theta":result.theta,"vega":result.vega},
            "pnl":            {"max_profit":result.max_profit,"max_loss":result.max_loss,
                               "breakeven_low":result.breakeven_low,
                               "breakeven_high":result.breakeven_high,
                               "risk_reward":result.risk_reward_ratio},
            "margin_required": result.margin_required,
            "conviction":      result.conviction,
            "notes":           result.notes,
        }

    def get_fno_status(self) -> Dict:
        """Return live F&O portfolio status (Greeks, alerts, settlements)."""
        return self.coordinator.get_fno_status()

    # ------------------------------------------------------------------
    # Data helpers
    # ------------------------------------------------------------------

    def _fetch_market_data(self) -> Dict[str, Any]:
        """
        Fetch live market data.
        Tries live broker APIs → falls back to demo data.
        """
        try:
            return self._fetch_live_data()
        except Exception as exc:
            logger.debug(f"Live data unavailable ({exc}), using synthetic fallback")
            return self._build_demo_data()

    def _fetch_live_data(self) -> Dict[str, Any]:
        """Attempt live data fetch via configured broker."""
        if self.config.api.fyers_enabled:
            from data.fyers_fetcher import FyersFetcher
            return FyersFetcher(self.config.api).fetch_market_data()
        if self.config.api.zerodha_enabled:
            from data.zerodha_fetcher import ZerodhaFetcher
            return ZerodhaFetcher(self.config.api).fetch_market_data()
        raise RuntimeError("No live data source configured")

    def _build_demo_data(self, seed: int = 42) -> Dict[str, Any]:
        """Synthetic market data for demo/backtest runs."""
        rng = lambda base, pct: base * (1 + (((seed % 100) - 50) / 50) * pct)

        # Per-symbol hash using full name so different stocks get different prices
        def sym_hash(s: str) -> int:
            h = sum(ord(c) * (i + 1) for i, c in enumerate(s))
            return h % 4000

        nifty = rng(22500, 0.02)
        stocks = {
            s: {
                "close":      rng(800  + sym_hash(s), 0.03),
                "open":       rng(800  + sym_hash(s), 0.01),
                "high":       rng(800  + sym_hash(s), 0.04),
                "low":        rng(800  + sym_hash(s), 0.025),
                "volume":     int(rng(500_000 + sym_hash(s) * 100, 0.4)),
                "avg_volume": 450_000,
                "atr":        rng(800  + sym_hash(s), 0.015) * 0.018,
            }
            for s in NIFTY_50_STOCKS[:20]
        }
        # Indicators also vary per stock so RSI/ADX aren't all identical
        indicators = {
            s: {
                "rsi":          rng(45 + sym_hash(s) % 25, 0.12),
                "sma20":        v["close"] * rng(0.992, 0.005),
                "sma50":        v["close"] * rng(0.975, 0.008),
                "sma200":       v["close"] * rng(0.940, 0.010),
                "atr":          v["atr"],
                "adx":          rng(20 + sym_hash(s) % 20, 0.18),
                "trend":        "UPTREND" if sym_hash(s) % 3 != 0 else "SIDEWAYS",
                "volume_ratio": rng(0.9 + (sym_hash(s) % 10) / 20, 0.25),
            }
            for s, v in stocks.items()
        }

        call_wall_1 = round(nifty * 1.02 / 50) * 50
        call_wall_2 = round(nifty * 1.04 / 50) * 50
        put_wall_1  = round(nifty * 0.98 / 50) * 50
        put_wall_2  = round(nifty * 0.96 / 50) * 50

        return {
            "nifty_price":     nifty,
            "nifty_200dma":    nifty * 0.95,
            "india_vix":       rng(14, 0.3),
            "adx":             rng(28, 0.2),
            "price_structure": "higher_highs",
            "nifty_pe":        rng(22.5, 0.05),
            "gsec_yield":      rng(7.0, 0.02),
            "price_data":      stocks,
            "indicators":      indicators,
            "flow_data":       {"fii_cash_5day": rng(4500, 0.5), "dii_cash_5day": rng(2000, 0.4)},
            "sentiment_data":  {"news": 55, "analyst": 50, "social": 45, "global": 48},
            "derivatives_data": {
                "pcr":       rng(1.2, 0.2),
                "pcr_trend": "stable",
                "max_pain":  round(nifty / 100) * 100,
                "india_vix": rng(14, 0.3),
                "iv_rank":   45,
                # Walls as dicts so OPTIMUS can read strike + oi fields
                "call_oi_walls": [
                    {"strike": call_wall_1, "oi": int(rng(1_500_000, 0.3))},
                    {"strike": call_wall_2, "oi": int(rng(1_000_000, 0.3))},
                ],
                "put_oi_walls": [
                    {"strike": put_wall_1,  "oi": int(rng(1_200_000, 0.3))},
                    {"strike": put_wall_2,  "oi": int(rng(900_000,   0.3))},
                ],
            },
            "fundamental_data": {},
            "event_data":       {"events": []},
            "ohlcv_history":    {},
        }


# ===========================================================================
# CLI
# ===========================================================================

def parse_args():
    p = argparse.ArgumentParser(description="ROX Proven Edge Engine v4.0 Unified")
    p.add_argument("--mode", choices=["live","paper","backtest","demo"],
                   default="demo", help="Trading mode (default: demo)")
    p.add_argument("--portfolio-value", type=float, default=1_000_000,
                   help="Portfolio value in INR (default: 1000000)")
    p.add_argument("--start-date", type=str, help="Backtest start YYYY-MM-DD")
    p.add_argument("--end-date",   type=str, help="Backtest end YYYY-MM-DD")
    p.add_argument("--watchlist",  type=str, nargs="*",
                   help="Stocks to analyse (default: Nifty 50 top 20)")
    return p.parse_args()


def main():
    args = parse_args()
    config = get_system_config()
    engine = ROXUnifiedEngine(config, mode=args.mode,
                              portfolio_value=args.portfolio_value)

    def _shutdown(signum, frame):
        logger.info("Shutdown signal received")
        engine.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT,  _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    if args.mode == "demo":
        engine.run_demo()

    elif args.mode == "backtest":
        if not args.start_date or not args.end_date:
            logger.error("--start-date and --end-date required for backtest mode")
            sys.exit(1)
        engine.run_backtest(args.start_date, args.end_date,
                            watchlist=args.watchlist)

    else:   # paper / live
        engine.start()
        try:
            while engine.running:
                time.sleep(1)
        except KeyboardInterrupt:
            engine.stop()

    logger.info("ROX Unified Engine shutdown complete")


if __name__ == "__main__":
    main()
